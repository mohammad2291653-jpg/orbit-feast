import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import type {
  RoomInfo,
  Snapshot,
  ClientMessage,
  Rules,
} from "../../../packages/shared/types";
import { SKINS, COLORS } from "../../../packages/shared/types";
import { Arena, defaults, type Settings } from "./game";
import "./style.css";

const Arrow = () => (
  <svg
    className="ui-icon"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
    aria-hidden="true"
  >
    <path d="M5 19 19 5M5 5h14v14" />
  </svg>
);
const ChatMark = () => (
  <svg
    className="ui-icon"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
    aria-hidden="true"
  >
    <path d="M4 5v11h15m-5-5 5 5-5 5" />
  </svg>
);
const FullscreenIcon = () => (
  <svg
    className="ui-icon"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
    aria-hidden="true"
  >
    <path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5" />
  </svg>
);
type Chat = { id: string; name: string; text: string; time: number };
function stored<T>(key: string, fallback: T): T {
  try {
    return JSON.parse(localStorage.getItem(key) || "null") ?? fallback;
  } catch {
    return fallback;
  }
}
function App() {
  const canvas = useRef<HTMLCanvasElement>(null),
    game = useRef<Arena | null>(null),
    socket = useRef<WebSocket | null>(null),
    sequence = useRef(0),
    lastMass = useRef(0),
    latestSnapshot = useRef<Snapshot | null>(null),
    publishedSnapshot = useRef<Snapshot | null>(null),
    held = useRef({ fast: false, feed: false }),
    chatInput = useRef<HTMLInputElement>(null),
    alive = useRef(true),
    connection = useRef<{
      room: string;
      spectate: boolean;
      name: string;
      skin: string;
    } | null>(null),
    reconnect = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [settings, setSettings] = useState<Settings>(() => ({
    ...defaults,
    ...stored<Partial<Settings>>("orbit.settings", {}),
    bindings: {
      ...defaults.bindings,
      ...stored<Partial<Settings>>("orbit.settings", {}).bindings,
    },
  }));
  const [name, setName] = useState(() => stored<string>("orbit.name", "")),
    [skin, setSkin] = useState(() => stored<string>("orbit.skin", "orbit"));
  const [serverReachable, setServerReachable] = useState(false);
  const [rooms, setRooms] = useState<RoomInfo[]>([]),
    [room, setRoom] = useState(
      new URLSearchParams(location.search).get("room") || "feed-6",
    ),
    [playing, setPlaying] = useState(false),
    [spectating, setSpectating] = useState(false),
    [status, setStatus] = useState("offline"),
    [error, setError] = useState(""),
    [snapshot, setSnapshot] = useState<Snapshot | null>(null),
    [settingsOpen, setSettingsOpen] = useState(false),
    [helpOpen, setHelpOpen] = useState(false),
    [chatOpen, setChatOpen] = useState(false),
    [messages, setMessages] = useState<Chat[]>([]),
    [chat, setChat] = useState(""),
    [ping, setPing] = useState(0),
    [fps, setFps] = useState(60),
    [privateCode, setPrivateCode] = useState(""),
    [muted, setMuted] = useState<string[]>([]),
    [notice, setNotice] = useState(""),
    [free, setFree] = useState(false);
  const stateRef = useRef({ playing, chatOpen, settingsOpen, helpOpen });
  stateRef.current = { playing, chatOpen, settingsOpen, helpOpen };
  const ar = settings.lang === "ar";
  const t = (en: string, arabic: string) => (ar ? arabic : en);
  useEffect(() => {
    const g = new Arena(canvas.current!);
    game.current = g;
    return () => {
      alive.current = false;
      g.destroy();
      socket.current?.close();
      clearTimeout(reconnect.current);
    };
  }, []);
  useEffect(() => {
    if (game.current) game.current.settings = settings;
    localStorage.setItem("orbit.settings", JSON.stringify(settings));
    document.documentElement.lang = settings.lang;
    document.documentElement.dir = ar ? "rtl" : "ltr";
  }, [settings]);
  useEffect(() => {
    const fetchRooms = () =>
      fetch("/api/rooms")
        .then((r) => {
          if (!r.ok) throw Error("Server unavailable");
          return r.json();
        })
        .then((r) => {
          if (alive.current) {
            setServerReachable(true);
            setRooms((prev) => [
              ...(Array.isArray(r) ? r : r.rooms || []),
              ...prev.filter((v) => v.private),
            ]);
          }
        })
        .catch(() => {
          if (alive.current) setServerReachable(false);
        });
    fetchRooms();
    const initial = new URLSearchParams(location.search).get("room");
    if (initial && initial !== "feed-6" && initial !== "classic")
      fetch("/api/rooms/" + encodeURIComponent(initial))
        .then((r) => (r.ok ? r.json() : null))
        .then((r) => {
          if (r?.id)
            setRooms((prev) => [...prev.filter((v) => v.id !== r.id), r]);
        })
        .catch(() => {});
    const timer = setInterval(fetchRooms, 4000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    const timer = setInterval(() => {
      setFps(Math.round(game.current?.fps || 60));
      send({ type: "ping", time: Date.now() });
    }, 2000);
    return () => clearInterval(timer);
  }, []);
  const send = (msg: ClientMessage) => {
    if (socket.current?.readyState === WebSocket.OPEN)
      socket.current.send(JSON.stringify(msg));
  };
  const sendInput = () => {
    const g = game.current;
    if (!g || !stateRef.current.playing) return;
    const p = g.mouseActive
      ? g.worldTarget()
      : { x: g.camera.x, y: g.camera.y };
    send({
      type: "input",
      x: p.x,
      y: p.y,
      fast: held.current.fast,
      feed: held.current.feed,
      seq: ++sequence.current,
    });
  };
  useEffect(() => {
    const inputTimer = setInterval(sendInput, 50);
    const viewTimer = setInterval(() => {
      const g = game.current;
      if (g && stateRef.current.playing)
        send({
          type: "view",
          x: g.camera.x,
          y: g.camera.y,
          width: Math.min(16000, innerWidth / g.camera.zoom + 700),
          height: Math.min(16000, innerHeight / g.camera.zoom + 700),
        });
    }, 200);
    // Network state reaches the renderer immediately. Textual HUD updates need
    // only five refreshes per second and should not rebuild all React UI at 15Hz.
    const hudTimer = setInterval(() => {
      const next = latestSnapshot.current;
      if (next && next !== publishedSnapshot.current) {
        publishedSnapshot.current = next;
        setSnapshot(next);
      }
    }, 200);
    return () => {
      clearInterval(inputTimer);
      clearInterval(viewTimer);
      clearInterval(hudTimer);
    };
  }, []);
  function connectSession() {
    const c = connection.current;
    if (!c) return;
    setStatus("connecting");
    const token =
      sessionStorage.getItem(
        "orbit.token." + c.room + (c.spectate ? ".watch" : ".play"),
      ) || "";
    const ws = new WebSocket(
      `${location.protocol === "https:" ? "wss:" : "ws:"}//${location.host}/ws`,
    );
    socket.current = ws;
    let welcomed = false;
    ws.onopen = () =>
      ws.send(
        JSON.stringify({ type: "join", ...c, token: token || undefined }),
      );
    ws.onmessage = (ev) => {
      let m;
      try {
        m = JSON.parse(ev.data);
      } catch {
        return;
      }
      if (m.type === "welcome") {
        welcomed = true;
        sequence.current = Math.max(sequence.current, Number(m.ack) || 0);
        setStatus("online");
        sessionStorage.setItem(
          "orbit.token." + c.room + (c.spectate ? ".watch" : ".play"),
          m.token,
        );
        if (game.current) {
          game.current.me = m.id;
          game.current.spectate = c.spectate;
          game.current.active = true;
          game.current.rules = m.rules;
          game.current.clearEntities();
          game.current.mouseActive = false;
          game.current.pointer = { x: innerWidth / 2, y: innerHeight / 2 };
        }
        setSpectating(c.spectate);
      } else if (m.type === "snapshot") {
        game.current?.snapshot(m);
        if (m.me.alive) lastMass.current = m.me.mass;
        const previous = latestSnapshot.current;
        latestSnapshot.current = m;
        // A death, spawn or identity change must never wait for the HUD timer.
        if (
          !previous ||
          previous.me.id !== m.me.id ||
          previous.me.alive !== m.me.alive
        ) {
          publishedSnapshot.current = m;
          setSnapshot(m);
        }
      } else if (m.type === "chat") {
        setMessages((prev) => [...prev.slice(-79), m]);
      } else if (m.type === "pong") {
        setPing(Math.max(0, Date.now() - m.time));
      } else if (m.type === "error") {
        setError(m.message);
        if (!welcomed) {
          connection.current = null;
          setPlaying(false);
          setStatus("offline");
          if (game.current) game.current.active = false;
          ws.close();
        }
      } else if (m.type === "kicked") {
        setError(m.message || "Disconnected by the administrator");
        connection.current = null;
        ws.close();
        setStatus("offline");
      }
    };
    ws.onclose = () => {
      if (socket.current !== ws) return;
      held.current = { fast: false, feed: false };
      setStatus("offline");
      if (connection.current && alive.current)
        reconnect.current = setTimeout(connectSession, 1800);
    };
    ws.onerror = () => setStatus("offline");
  }
  function join(spectate = false) {
    if (socket.current) {
      connection.current = null;
      socket.current.close();
    }
    clearTimeout(reconnect.current);
    localStorage.setItem("orbit.name", JSON.stringify(name));
    localStorage.setItem("orbit.skin", JSON.stringify(skin));
    setError("");
    setMessages([]);
    latestSnapshot.current = null;
    publishedSnapshot.current = null;
    setSnapshot(null);
    setPlaying(true);
    setSpectating(spectate);
    connection.current = {
      room,
      name: name.trim() || "Wanderer",
      skin,
      spectate,
    };
    setSettingsOpen(false);
    setHelpOpen(false);
    connectSession();
  }
  function leave() {
    connection.current = null;
    clearTimeout(reconnect.current);
    socket.current?.close();
    socket.current = null;
    held.current = { fast: false, feed: false };
    setPlaying(false);
    setChatOpen(false);
    latestSnapshot.current = null;
    publishedSnapshot.current = null;
    setSnapshot(null);
    setStatus("offline");
    if (game.current) {
      game.current.active = false;
      game.current.clearEntities();
      game.current.clearKeys();
    }
  }
  const split = (count: 1 | 2 | 3 = 1) => {
    if (!stateRef.current.chatOpen && !stateRef.current.settingsOpen)
      send({ type: "split", count });
  };
  const stopInputs = () => {
    held.current = { fast: false, feed: false };
    game.current?.clearKeys();
    sendInput();
  };
  useEffect(() => {
    function down(e: KeyboardEvent) {
      const target = e.target as HTMLElement;
      const typing = ["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(
        target?.tagName,
      );
      if (e.code === "Escape") {
        setSettingsOpen(false);
        setHelpOpen(false);
        setChatOpen(false);
        chatInput.current?.blur();
        stopInputs();
        return;
      }
      if (typing) return;
      if (e.code === "Enter" && playing) {
        e.preventDefault();
        setChatOpen(true);
        stopInputs();
        setTimeout(() => chatInput.current?.focus(), 20);
        return;
      }
      if (
        !playing ||
        stateRef.current.settingsOpen ||
        stateRef.current.helpOpen ||
        stateRef.current.chatOpen
      )
        return;
      if (e.code === "Space") {
        e.preventDefault();
        if (!e.repeat) split();
      }
      if (e.code === "KeyW") {
        e.preventDefault();
        held.current.feed = true;
        sendInput();
      }
      if (e.code === "KeyF") {
        e.preventDefault();
        held.current.fast = true;
        sendInput();
      }
      if (e.repeat) return;
      game.current?.setKey(e.code, true);
      if (e.code === settings.bindings.spectatorToggle && spectating) {
        setFree((v) => {
          if (game.current) game.current.free = !v;
          return !v;
        });
      }
      if (e.code === settings.bindings.double) split(2);
      if (e.code === settings.bindings.multi) split(3);
      if (e.code === settings.bindings.mass)
        setSettings((s) => ({ ...s, mass: !s.mass }));
      if (e.code === settings.bindings.grid)
        setSettings((s) => ({ ...s, grid: !s.grid }));
      if (e.code === settings.bindings.focus)
        setSettings((s) => ({ ...s, performance: !s.performance }));
    }
    function up(e: KeyboardEvent) {
      game.current?.setKey(e.code, false);
      if (e.code === "KeyF") held.current.fast = false;
      if (e.code === "KeyW") held.current.feed = false;
      sendInput();
    }
    function move(e: PointerEvent) {
      if (e.pointerType === "mouse")
        game.current?.setPointer(e.clientX, e.clientY);
    }
    function wheel(e: WheelEvent) {
      if (!playing || settingsOpen) return;
      e.preventDefault();
      if (game.current)
        game.current.zoomFactor = Math.max(
          0.35,
          Math.min(2.5, game.current.zoomFactor * (e.deltaY > 0 ? 0.92 : 1.08)),
        );
    }
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("pointermove", move);
    window.addEventListener("blur", stopInputs);
    window.addEventListener("wheel", wheel, { passive: false });
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("blur", stopInputs);
      window.removeEventListener("wheel", wheel);
    };
  }, [playing, spectating, settings.bindings, settingsOpen]);
  async function createPrivate() {
    try {
      const response = await fetch("/api/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: (name || "Private") + " · orbit" }),
      });
      const created = await response.json();
      if (!response.ok) throw Error(created.error || "Could not create room");
      setRooms((r) => [...r, created]);
      setRoom(created.id);
      setPrivateCode(created.code || created.id);
      setNotice("Private room ready. Share the invite link with friends.");
    } catch (e) {
      setError(String(e));
    }
  }
  async function resolveInvite() {
    if (!privateCode.trim()) return;
    try {
      const response = await fetch(
        "/api/rooms/" + encodeURIComponent(privateCode.trim()),
      );
      if (!response.ok) throw Error("Room not found");
      const result = await response.json();
      setRoom(result.id);
      setRooms((prev) => [...prev.filter((v) => v.id !== result.id), result]);
      setNotice("Room " + result.id + " selected");
    } catch (e) {
      setError(String(e));
    }
  }
  function share() {
    const link = new URL(location.href);
    link.searchParams.set("room", room);
    navigator.clipboard
      ?.writeText(link.toString())
      .then(() => setNotice(t("Invite link copied", "تم نسخ رابط الدعوة")))
      .catch(() => setNotice(link.toString()));
    setNotice(link.toString());
  }
  function postChat(e: React.FormEvent) {
    e.preventDefault();
    if (chat.trim()) send({ type: "chat", text: chat.trim().slice(0, 180) });
    setChat("");
    setChatOpen(false);
    chatInput.current?.blur();
  }
  const setOption = (key: keyof Settings) =>
    setSettings((s) => ({ ...s, [key]: !s[key] }));
  const selected = rooms.find((r) => r.id === room);
  const dead = playing && !spectating && snapshot && !snapshot.me.alive;
  return (
    <main
      className={`app${playing ? " in-game" : ""}${settings.performance ? " performance-mode" : ""}`}
    >
      <canvas
        ref={canvas}
        className="arena"
        aria-label={t("Multiplayer cell arena", "ساحة الخلايا متعددة اللاعبين")}
        data-testid="arena"
      />
      {!playing ? (
        <div className="menu-shell">
          <header className="masthead">
            <a className="brand" href="/" aria-label="Orbit Feast home">
              <span className="brand-mark">◉</span>
              <span>
                ORBIT<span className="brand-light">FEAST</span>
                <small>MULTIPLAYER CELL ARENA</small>
              </span>
            </a>
            <nav>
              <span className="live-pill">
                <i
                  style={{
                    background: serverReachable ? "#b8edcf" : "#b98a60",
                  }}
                />
                {serverReachable
                  ? t("ARENA ONLINE", "الساحة متاحة")
                  : t("SERVER OFFLINE", "الخادم غير متصل")}
              </span>
              <button
                className="language"
                onClick={() =>
                  setSettings((s) => ({ ...s, lang: ar ? "en" : "ar" }))
                }
              >
                {ar ? "EN" : "العربية"} <span>⌄</span>
              </button>
              <button
                className="icon-btn"
                aria-label="Settings"
                onClick={() => setSettingsOpen(true)}
              >
                ⚙
              </button>
            </nav>
          </header>
          <section className="lobby-layout">
            <div className="hero">
              <div className="eyebrow">
                <span />{" "}
                {t(
                  "SMALL CELL. BIG POSSIBILITIES.",
                  "خلية صغيرة. احتمالات كبيرة.",
                )}
              </div>
              <h1>
                {t("Find your", "جد مدارك")}
                <br />
                <em>{t("orbit.", "الخاص.")}</em>
              </h1>
              <p className="hero-copy">
                {t(
                  "Drift in. Grow bold. Take the arena.",
                  "انطلق، انمُ، وسيطر على الساحة.",
                )}
                <br />
                {t(
                  "A world of tiny rivals and oversized ambition.",
                  "عالم من المنافسين الصغار والطموحات الكبيرة.",
                )}
              </p>
              <div className="hero-orbs" aria-hidden="true">
                <div className="orbit-ring" />
                <div className="hero-cell large">
                  <span>◒</span>
                  <small>you, but bigger</small>
                </div>
                <div className="hero-cell small">✦</div>
                <div className="pellet p1" />
                <div className="pellet p2" />
                <div className="pellet p3" />
                <div className="floating-label">
                  <Arrow />{" "}
                  {t("EVERY CELL STARTS SOMEWHERE", "كل خلية تبدأ من مكان")}
                </div>
              </div>
              <div className="hero-footer">
                <span className="tiny-cross">✳</span>
                <span>
                  {t(
                    "Real players. Shared world. Your next move.",
                    "لاعبون حقيقيون. عالم مشترك. خطوتك التالية.",
                  )}
                </span>
              </div>
            </div>
            <div className="join-card">
              <div className="card-top">
                <span className="eyebrow">
                  01 / {t("ENTER THE ARENA", "ادخل الساحة")}
                </span>
                <span className="card-spark">✳</span>
              </div>
              <h2>{t("Make a little space.", "اصنع لك مساحة.")}</h2>
              <p className="muted">
                {t(
                  "Your next big thing starts small.",
                  "خطوتك الكبيرة تبدأ صغيرة.",
                )}
              </p>
              <label className="field-label" htmlFor="nickname">
                {t("NICKNAME", "الاسم المستعار")}
              </label>
              <div className="nickname-field">
                <span>⌁</span>
                <input
                  id="nickname"
                  data-testid="nickname"
                  maxLength={20}
                  placeholder={t("What should we call you?", "بماذا نناديك؟")}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") join();
                  }}
                />
                <span className="field-limit">{name.length}/20</span>
              </div>
              <div className="label-row">
                <label className="field-label">
                  {t("PICK YOUR ORBIT", "اختر مظهرك")}
                </label>
                <span className="small-muted">{skin.toUpperCase()}</span>
              </div>
              <div className="skins" role="group" aria-label="Skin selector">
                {SKINS.map((s, i) => (
                  <button
                    aria-label={"Skin " + s}
                    aria-pressed={skin === s}
                    className={"skin " + (skin === s ? "selected" : "")}
                    key={s}
                    onClick={() => setSkin(s)}
                  >
                    <span style={{ background: COLORS[i] }}>
                      {["◒", "☀", "◔", "✥", "✦", "❋"][i]}
                    </span>
                    {skin === s && <b>✓</b>}
                  </button>
                ))}
              </div>
              <div className="label-row server-title">
                <label className="field-label">
                  {t("CHOOSE A SERVER", "اختر الخادم")}
                </label>
                <span className="small-muted">
                  {serverReachable
                    ? `${rooms.reduce((n, r) => n + r.humans, 0)} ${t("humans online", "لاعب متصل")}`
                    : t("server unavailable", "الخادم غير متاح")}
                </span>
              </div>
              <div
                className="server-list"
                role="group"
                aria-label="Server selection"
              >
                {rooms
                  .filter((r) => !r.private || r.id === room)
                  .map((r) => (
                    <button
                      className={"server " + (room === r.id ? "selected" : "")}
                      key={r.id}
                      onClick={() => setRoom(r.id)}
                      aria-pressed={room === r.id}
                      data-testid={"server-" + r.id}
                    >
                      <span className="server-icon">
                        {r.private ? "⌑" : r.id === "classic" ? "◎" : "✳"}
                      </span>
                      <span className="server-name">
                        {r.name}
                        <small>
                          {r.id === "feed-6"
                            ? t(
                                "Fast feed · fluid splits",
                                "تغذية سريعة · انقسام سلس",
                              )
                            : r.private
                              ? t("Invite-only arena", "ساحة خاصة بالدعوة")
                              : t(
                                  "The original survival loop",
                                  "تنافس البقاء الكلاسيكي",
                                )}
                        </small>
                      </span>
                      <span className="server-meta">
                        <span className="server-count">
                          <i
                            style={{
                              background: serverReachable
                                ? "#b8edcf"
                                : "#b98a60",
                            }}
                          />
                          {serverReachable
                            ? `${r.humans}/${r.maxPlayers}`
                            : t("offline", "غير متصل")}
                        </span>
                        <small>
                          {r.bots} {t("bots", "بوت")}
                        </small>
                      </span>
                      <span className="radio-dot" />
                    </button>
                  ))}
                {!rooms.length && (
                  <div className="server-empty">
                    {t(
                      "Connecting to the game server…",
                      "جار الاتصال بخادم اللعبة…",
                    )}
                  </div>
                )}
              </div>
              <div className="private-row">
                <button className="text-btn" onClick={createPrivate}>
                  ＋ {t("Private room", "غرفة خاصة")}
                </button>
                <input
                  aria-label="Room invitation code"
                  placeholder={t("Invite code", "رمز الدعوة")}
                  value={privateCode}
                  onChange={(e) => setPrivateCode(e.target.value)}
                  maxLength={40}
                />
                <button className="text-btn" onClick={resolveInvite}>
                  {t("Join", "انضم")} <Arrow />
                </button>
              </div>
              <button
                className="play-button"
                data-testid="play"
                onClick={() => join(false)}
              >
                {t("Play now", "العب الآن")}{" "}
                <span>
                  <Arrow />
                </span>
              </button>
              <button
                className="spectate-button"
                data-testid="spectate"
                onClick={() => join(true)}
              >
                ◎ {t("Just looking? Spectate", "تريد المشاهدة؟ راقب الساحة")}
              </button>
              <div className="card-bottom">
                <span>
                  ◌ {t("No account. Just play.", "بدون حساب. ابدأ اللعب.")}
                </span>
                <button onClick={() => setHelpOpen(true)}>
                  {t("How to play", "طريقة اللعب")} <Arrow />
                </button>
              </div>
            </div>
          </section>
          <footer className="lobby-footer">
            <span>
              © 2026 ORBIT FEAST <b>·</b>{" "}
              {t("A little friendly competition.", "منافسة ودية صغيرة.")}
            </span>
            <div>
              <button onClick={() => setHelpOpen(true)}>
                {t("Controls", "التحكم")}
              </button>
              <button onClick={() => setSettingsOpen(true)}>
                {t("Settings", "الإعدادات")}
              </button>
              <span className="version">EARLY ORBIT / 1.0</span>
            </div>
          </footer>
        </div>
      ) : (
        <>
          <div className="hud-top">
            <div className="hud-brand">
              <span className="brand-mark">◉</span>
              <div>
                ORBIT FEAST<small>{selected?.name || room}</small>
              </div>
            </div>
            <div className="hud-stats">
              <span>
                <i className={"connection-dot " + status} />
                {t(
                  status === "online"
                    ? "Connected"
                    : status === "connecting"
                      ? "Connecting"
                      : "Reconnecting",
                  status === "online"
                    ? "متصل"
                    : status === "connecting"
                      ? "جار الاتصال"
                      : "إعادة اتصال",
                )}
              </span>
              <span>{ping} ms</span>
              <span>{fps} FPS</span>
              <button
                className="icon-btn"
                onClick={() => {
                  stopInputs();
                  setSettingsOpen(true);
                }}
                aria-label="Settings"
              >
                ⚙
              </button>
              <button
                className="icon-btn"
                onClick={leave}
                aria-label="Return to menu"
              >
                ⌂
              </button>
            </div>
          </div>
          <aside className="leaderboard panel">
            <div className="panel-heading">
              <span>
                <Arrow /> {t("LEADERBOARD", "المتصدرون")}
              </span>
              <span className="small-muted">TOP 10</span>
            </div>
            {snapshot?.leaderboard.slice(0, 10).map((r, i) => (
              <div
                className={"rank-row " + (r.id === snapshot.me.id ? "you" : "")}
                key={r.id}
              >
                <span className="rank-number">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="rank-name">
                  {r.name}
                  {r.bot && <small> BOT</small>}
                </span>
                <b>{Math.round(r.mass).toLocaleString()}</b>
              </div>
            ))}
            <div className="leaderboard-footer">
              {snapshot?.humans || 0} {t("humans", "لاعب")} <span>·</span>{" "}
              {snapshot?.bots || 0} {t("bots", "بوت")}
            </div>
          </aside>
          <div
            className="mass-card panel"
            data-testid="player-stats"
            data-player-id={snapshot?.me.id}
          >
            <span className="eyebrow">
              {spectating ? t("SPECTATING", "مشاهدة") : name || "Wanderer"}
            </span>
            <div className="mass-number" data-testid="mass">
              {spectating
                ? "◎"
                : Math.round(snapshot?.me.mass || 0).toLocaleString()}
              <small>
                {spectating ? t("observer", "مراقب") : t("mass", "كتلة")}
              </small>
            </div>
            <div className="mass-meta">
              {spectating ? (
                <button
                  className="text-btn"
                  onClick={() => {
                    setFree((v) => {
                      if (game.current) game.current.free = !v;
                      return !v;
                    });
                  }}
                >
                  {free
                    ? t("Free camera", "كاميرا حرة")
                    : t("Follow leader", "تتبع المتصدر")}{" "}
                  · {settings.bindings.spectatorToggle.replace("Key", "")}
                </button>
              ) : (
                <>
                  <span>
                    {t("RANK", "الترتيب")} <b>#{snapshot?.me.rank || "—"}</b>
                  </span>
                  <span>
                    {t("BEST", "الأفضل")}{" "}
                    <b>{Math.round(snapshot?.me.peak || 0)}</b>
                  </span>
                </>
              )}
            </div>
          </div>
          <div className={"chat-panel " + (chatOpen ? "chat-active" : "")}>
            <div className="chat-messages" aria-live="polite">
              {messages
                .filter((m) => !muted.includes(m.name))
                .slice(-5)
                .map((m, i) => (
                  <div key={m.time + "-" + i}>
                    <button
                      title="Mute this player"
                      onClick={() => setMuted((v) => [...v, m.name])}
                    >
                      {m.name}
                    </button>
                    <span>{m.text}</span>
                  </div>
                ))}
            </div>
            <form onSubmit={postChat}>
              <span>
                <ChatMark />
              </span>
              <input
                data-testid="chat-input"
                ref={chatInput}
                aria-label="Room chat"
                value={chat}
                onChange={(e) => setChat(e.target.value)}
                maxLength={180}
                onFocus={() => {
                  setChatOpen(true);
                  stopInputs();
                }}
                onBlur={() => setChatOpen(false)}
                placeholder={t(
                  "Enter to chat · click a name to mute",
                  "Enter للدردشة · اضغط الاسم للكتم",
                )}
              />
              {chatOpen && (
                <button type="submit" aria-label="Send chat">
                  <Arrow />
                </button>
              )}
            </form>
            {muted.length > 0 && (
              <button className="unmute text-btn" onClick={() => setMuted([])}>
                {t("Unmute all", "إلغاء كتم الجميع")} ({muted.length})
              </button>
            )}
          </div>
          <div className="controls-dock">
            <span>
              <kbd>SPACE</kbd> {t("split", "انقسام")}
            </span>
            <span>
              <kbd>W</kbd> {t("feed", "تغذية")}
            </span>
            <span>
              <kbd>F</kbd> {t("fast feed", "تغذية سريعة")}
            </span>
            <button aria-label="Help" onClick={() => setHelpOpen(true)}>
              ?
            </button>
            <button aria-label="Copy room invite" onClick={share}>
              <Arrow />
            </button>
          </div>
          <div className="mobile-controls">
            <div
              className="joystick"
              aria-label="Touch joystick"
              data-testid="joystick"
              onPointerDown={(e) => {
                e.currentTarget.setPointerCapture(e.pointerId);
                const b = e.currentTarget.getBoundingClientRect();
                game.current?.setPointer(
                  innerWidth / 2 + (e.clientX - b.left - b.width / 2) * 5,
                  innerHeight / 2 + (e.clientY - b.top - b.height / 2) * 5,
                );
                sendInput();
              }}
              onPointerMove={(e) => {
                if (e.buttons) {
                  const b = e.currentTarget.getBoundingClientRect();
                  game.current?.setPointer(
                    innerWidth / 2 + (e.clientX - b.left - b.width / 2) * 5,
                    innerHeight / 2 + (e.clientY - b.top - b.height / 2) * 5,
                  );
                }
              }}
              onPointerUp={() =>
                game.current?.setPointer(innerWidth / 2, innerHeight / 2)
              }
              onPointerCancel={() =>
                game.current?.setPointer(innerWidth / 2, innerHeight / 2)
              }
            >
              <span />
            </div>
            <div className="touch-actions">
              <button
                data-testid="touch-split"
                onPointerDown={(e) => {
                  e.preventDefault();
                  split();
                }}
              >
                {t("Split", "انقسام")}
              </button>
              <button
                data-testid="touch-feed"
                onPointerDown={(e) => {
                  e.currentTarget.setPointerCapture(e.pointerId);
                  held.current.feed = true;
                  sendInput();
                }}
                onPointerUp={() => {
                  held.current.feed = false;
                  sendInput();
                }}
                onPointerCancel={() => {
                  held.current.feed = false;
                  sendInput();
                }}
              >
                {t("Feed", "غذّ")}
              </button>
              <button
                data-testid="touch-fast"
                onPointerDown={(e) => {
                  e.currentTarget.setPointerCapture(e.pointerId);
                  held.current.fast = true;
                  sendInput();
                }}
                onPointerUp={() => {
                  held.current.fast = false;
                  sendInput();
                }}
                onPointerCancel={() => {
                  held.current.fast = false;
                  sendInput();
                }}
              >
                {t("Fast", "سريع")}
              </button>
            </div>
          </div>
          {dead && (
            <div className="modal-backdrop">
              <section className="dialog death-dialog" data-testid="death">
                <div className="death-symbol">◌</div>
                <span className="eyebrow">
                  {t("EVERY ORBIT COMES AROUND", "كل نهاية بداية جديدة")}
                </span>
                <h2>{t("A good little run.", "جولة جميلة.")}</h2>
                <p className="muted">
                  {t(
                    "There is always room for another beginning.",
                    "هناك دائماً مكان لبداية جديدة.",
                  )}
                </p>
                <div className="death-stats">
                  <div>
                    <span>{t("FINAL SCORE", "النتيجة النهائية")}</span>
                    <b>{Math.round(lastMass.current)}</b>
                  </div>
                  <div>
                    <span>{t("PEAK MASS", "أعلى كتلة")}</span>
                    <b>{Math.round(snapshot.me.peak)}</b>
                  </div>
                  <div>
                    <span>{t("SURVIVED", "المدة")}</span>
                    <b>{Math.floor(snapshot.me.survival)}s</b>
                  </div>
                  <div>
                    <span>{t("CONSUMED", "التهامات")}</span>
                    <b>{snapshot.me.kills}</b>
                  </div>
                </div>
                <button
                  className="play-button"
                  data-testid="respawn"
                  onClick={() => send({ type: "respawn" })}
                >
                  {t("One more orbit", "جولة أخرى")} <Arrow />
                </button>
                <button className="spectate-button" onClick={leave}>
                  {t("Return to menu", "العودة للقائمة")}
                </button>
              </section>
            </div>
          )}
        </>
      )}
      {(settingsOpen || helpOpen) && (
        <div
          className="modal-backdrop"
          onClick={() => {
            setSettingsOpen(false);
            setHelpOpen(false);
          }}
        >
          <section
            className="dialog settings-dialog"
            role="dialog"
            aria-modal="true"
            aria-label={settingsOpen ? "Settings" : "Controls"}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="dialog-close"
              aria-label="Close dialog"
              onClick={() => {
                setSettingsOpen(false);
                setHelpOpen(false);
              }}
            >
              ×
            </button>
            <span className="eyebrow">
              ORBIT / {settingsOpen ? "PREFERENCES" : "FLIGHT MANUAL"}
            </span>
            <h2>
              {settingsOpen
                ? t("Your kind of space.", "مساحتك كما تحب.")
                : t("A few small moves.", "حركات بسيطة.")}
            </h2>
            {settingsOpen ? (
              <>
                <div className="setting-row">
                  <label htmlFor="language-setting">
                    {t("Language", "اللغة")}
                  </label>
                  <select
                    id="language-setting"
                    value={settings.lang}
                    onChange={(e) =>
                      setSettings((s) => ({
                        ...s,
                        lang: e.target.value as "en" | "ar",
                      }))
                    }
                  >
                    <option value="en">English</option>
                    <option value="ar">العربية</option>
                  </select>
                </div>
                {(
                  [
                    ["names", "Player names", "أسماء اللاعبين"],
                    ["mass", "Cell mass", "كتلة الخلية"],
                    ["skins", "Original skins", "المظاهر"],
                    ["grid", "Arena grid", "شبكة الساحة"],
                    ["dark", "Dark arena", "ساحة داكنة"],
                    ["borders", "Cell borders", "حدود الخلايا"],
                    ["animation", "Smooth animations", "حركة سلسة"],
                    ["minimap", "Minimap", "خريطة مصغرة"],
                    [
                      "performance",
                      "Focus / performance mode",
                      "وضع التركيز والأداء",
                    ],
                  ] as const
                ).map(([key, en, arabic]) => (
                  <label className="setting-row" key={key}>
                    {t(en, arabic)}
                    <input
                      type="checkbox"
                      checked={settings[key]}
                      onChange={() => setOption(key)}
                    />
                  </label>
                ))}
                <div className="binding-title">
                  {t(
                    "KEY BINDINGS · click to reassign",
                    "اختصارات · اضغط للتغيير",
                  )}
                </div>
                {(
                  [
                    ["double", "Double split", "انقسام مزدوج"],
                    ["multi", "Multi split", "انقسام متعدد"],
                    ["mass", "Toggle mass", "تبديل الكتلة"],
                    ["grid", "Toggle grid", "تبديل الشبكة"],
                    ["focus", "Focus mode", "وضع التركيز"],
                    [
                      "spectatorToggle",
                      "Spectator free camera",
                      "كاميرا المشاهدة الحرة",
                    ],
                    ["freeUp", "Spectator up", "مشاهدة للأعلى"],
                    ["freeDown", "Spectator down", "مشاهدة للأسفل"],
                    ["freeLeft", "Spectator left", "مشاهدة لليسار"],
                    ["freeRight", "Spectator right", "مشاهدة لليمين"],
                  ] as const
                ).map(([key, en, arabic]) => (
                  <div className="setting-row" key={key}>
                    <label htmlFor={"binding-" + key}>{t(en, arabic)}</label>
                    <input
                      className="binding-input"
                      id={"binding-" + key}
                      aria-label={en + " binding"}
                      value={settings.bindings[key].replace("Key", "")}
                      readOnly
                      onKeyDown={(e) => {
                        e.preventDefault();
                        if (e.code === "Escape") return;
                        setSettings((s) => ({
                          ...s,
                          bindings: { ...s.bindings, [key]: e.code },
                        }));
                        e.currentTarget.blur();
                      }}
                    />
                  </div>
                ))}
                <div className="settings-actions">
                  <button
                    className="outline-button"
                    onClick={() =>
                      document.fullscreenElement
                        ? document.exitFullscreen()
                        : document.documentElement.requestFullscreen?.()
                    }
                  >
                    {t("Fullscreen", "ملء الشاشة")} <FullscreenIcon />
                  </button>
                  <button
                    className="text-btn"
                    onClick={() => setSettings(defaults)}
                  >
                    {t("Reset settings", "استعادة الإعدادات")}
                  </button>
                </div>
              </>
            ) : (
              <>
                <p className="muted">
                  {t(
                    "Eat small. Avoid big. Grow into your own.",
                    "كُل الأصغر، وتجنب الأكبر، وواصل النمو.",
                  )}
                </p>
                <div className="help-controls">
                  {[
                    ["MOUSE", "Move toward your cursor", "تحرك باتجاه المؤشر"],
                    ["SPACE", "Split toward cursor", "انقسم باتجاه المؤشر"],
                    ["W", "Eject mass", "إخراج كتلة"],
                    [
                      "F",
                      "Hold for fast feed",
                      "اضغط باستمرار للتغذية السريعة",
                    ],
                    [
                      settings.bindings.spectatorToggle.replace("Key", ""),
                      "Free spectator camera",
                      "كاميرا مشاهدة حرة",
                    ],
                    ["ENTER", "Open / send chat", "فتح وإرسال الدردشة"],
                    ["ESC", "Close menus and chat", "إغلاق القوائم والدردشة"],
                    ["SCROLL", "Camera zoom", "تقريب الكاميرا"],
                  ].map(([key, en, arabic]) => (
                    <div key={key}>
                      <kbd>{key}</kbd>
                      <span>{t(en, arabic)}</span>
                    </div>
                  ))}
                </div>
                <p className="help-note">
                  {t(
                    "Split cells reunite after the merge timer. Feed your own cells to transfer mass, with a small loss. Green viruses break large cells apart. All results are decided by the server.",
                    "تندمج الخلايا بعد انتهاء المؤقت. غذّ خلاياك لنقل الكتلة مع خسارة بسيطة. الفيروسات الخضراء تفجّر الخلايا الكبيرة. يحدد الخادم جميع النتائج.",
                  )}
                </p>
                <button
                  className="outline-button"
                  onClick={() => {
                    setHelpOpen(false);
                    setSettingsOpen(true);
                  }}
                >
                  {t("Customize controls", "تخصيص التحكم")} <Arrow />
                </button>
              </>
            )}
          </section>
        </div>
      )}
      {error && (
        <div className="toast error" role="alert">
          {error}
          <button aria-label="Dismiss error" onClick={() => setError("")}>
            ×
          </button>
        </div>
      )}
      {notice && (
        <div className="toast" role="status">
          {notice}
          <button aria-label="Dismiss notice" onClick={() => setNotice("")}>
            ×
          </button>
        </div>
      )}
    </main>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
