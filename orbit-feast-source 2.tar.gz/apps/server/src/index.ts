import Fastify from "fastify";
import fastifyStatic from "@fastify/static";
import { WebSocketServer, WebSocket } from "ws";
import { randomBytes, timingSafeEqual } from "node:crypto";
import { resolve } from "node:path";
import { existsSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { performance } from "node:perf_hooks";
import { z } from "zod";
import { presets, validateRules } from "../../../packages/shared/config";
import {
  radius,
  type Entity,
  type EntityPatch,
  type RoomInfo,
  type Rules,
  type Snapshot,
} from "../../../packages/shared/types";
import { World } from "./simulation";

const finite = z.number().finite();
const schema = z.discriminatedUnion("type", [
  z
    .object({
      type: z.literal("join"),
      room: z.string().min(1).max(40),
      name: z.string().max(24),
      skin: z.string().max(20),
      token: z.string().max(100).optional(),
      spectate: z.boolean().optional(),
    })
    .strict(),
  z
    .object({
      type: z.literal("input"),
      x: finite,
      y: finite,
      fast: z.boolean(),
      feed: z.boolean(),
      seq: z.number().int().min(0).max(2147483647),
    })
    .strict(),
  z
    .object({
      type: z.literal("split"),
      count: z.union([z.literal(1), z.literal(2), z.literal(3)]),
    })
    .strict(),
  z.object({ type: z.literal("respawn") }).strict(),
  z
    .object({ type: z.literal("chat"), text: z.string().min(1).max(180) })
    .strict(),
  z.object({ type: z.literal("ping"), time: finite }).strict(),
  z
    .object({
      type: z.literal("view"),
      x: finite,
      y: finite,
      width: finite.min(100).max(16000),
      height: finite.min(100).max(16000),
    })
    .strict(),
]);
const clean = (s: string, n = 24) =>
  s
    .replace(/[<>\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g, "")
    .trim()
    .slice(0, n);
interface Session {
  token: string;
  id: string;
  room: Room;
  socket?: WebSocket;
  spectate: boolean;
  expires: number;
  ip: string;
  muted: boolean;
}
interface Connection {
  session?: Session;
  seen: Map<string, string>;
  view?: { x: number; y: number; width: number; height: number };
  lastInput: number;
  lastChat: number;
  lastRespawn: number;
  budget: number;
  window: number;
  alive: boolean;
  splitQueue: number;
  nextSplit: number;
  joined: boolean;
  violations: number;
  created: number;
}
interface PackedEntity {
  entity: Entity;
  stamp: string;
  delta: EntityPatch;
  source: Entity;
  x: number; y: number; mass: number; vx: number; vy: number;
}
interface Room {
  id: string;
  name: string;
  private: boolean;
  world: World;
  last: number;
  accumulator: number;
  snapshots: number;
  snapshotAt: number;
  created: number;
  boardAt: number;
  board: ReturnType<World["leaderboard"]>;
  packed: Map<string, PackedEntity>;
}
export async function createApp(
  options: { bots?: number; test?: boolean } = {},
) {
  const app = Fastify({
    logger: !options.test,
    bodyLimit: 8192,
    trustProxy: false,
  });
  const rooms = new Map<string, Room>();
  const sessions = new Map<string, Session>();
  const peers = new Map<WebSocket, Connection>();
  const banned = new Set<string>();
  const ipCounts = new Map<string, number>();
  const tickCosts: number[] = [];
  let snapshotBytes = 0;
  let messages = 0;
  let dropped = 0;
  let packedEntityUpdates = 0;
  const roomInfo = (r: Room): RoomInfo => ({
    id: r.id,
    name: r.name,
    mode: r.world.rules.name,
    humans: [...sessions.values()].filter(
      (s) => s.room === r && s.socket && !s.spectate,
    ).length,
    bots: [...r.world.players.values()].filter((p) => p.bot).length,
    maxPlayers: r.world.rules.maxPlayers,
    status: "online",
    private: r.private,
    ...(r.private ? { code: r.id } : {}),
  });
  function makeRoom(
    id: string,
    name: string,
    preset: string,
    isPrivate = false,
  ) {
    const envBots =
      process.env.BOTS === undefined ? undefined : Number(process.env.BOTS);
    const botCount =
      options.bots ??
      (Number.isInteger(envBots) && envBots! >= 0 && envBots! <= 50
        ? envBots
        : undefined);
    const rules = validateRules({
      ...presets[preset],
      ...(botCount !== undefined ? { bots: botCount } : {}),
    });
    const world = new World(rules);
    for (let i = 0; i < rules.bots; i++)
      world.addPlayer(
        "bot-" + randomBytes(6).toString("hex"),
        "Drifter " + (i + 1),
        ["orbit", "solar", "lunar", "mint", "nova", "ember"][i % 6],
        true,
      );
    const r: Room = {
      id,
      name,
      private: isPrivate,
      world,
      last: performance.now(),
      accumulator: 0,
      snapshots: 0,
      snapshotAt: 0,
      created: Date.now(),
      boardAt: 0,
      board: [],
      packed: new Map(),
    };
    rooms.set(id, r);
    return r;
  }
  makeRoom("feed-6", "New Feed 6 Inspired", "new-feed-6-inspired");
  makeRoom("classic", "Classic FFA", "classic");
  if (options.test)
    app.decorate(
      "testWorlds",
      new Map([...rooms].map(([id, r]) => [id, r.world])),
    );
  function send(ws: WebSocket | undefined, data: unknown) {
    if (ws && ws.readyState === WebSocket.OPEN && ws.bufferedAmount < 512_000) {
      const json = JSON.stringify(data);
      snapshotBytes += Buffer.byteLength(json);
      ws.send(json);
    }
  }
  const error = (ws: WebSocket, message: string) =>
    send(ws, { type: "error", message });
  function removeSession(s: Session) {
    s.room.world.removePlayer(s.id);
    sessions.delete(s.token);
  }
  function welcome(ws: WebSocket, s: Session) {
    send(ws, {
      type: "welcome",
      id: s.id,
      token: s.token,
      room: roomInfo(s.room),
      rules: s.room.world.rules,
      spectate: s.spectate,
      ack: s.room.world.players.get(s.id)?.input.seq || 0,
    });
  }
  const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
    .split(",")
    .filter(Boolean);
  const wss = new WebSocketServer({
    noServer: true,
    maxPayload: 4096,
    perMessageDeflate: false,
  });
  app.server.on("upgrade", (req, socket, head) => {
    const ip = req.socket.remoteAddress || "unknown";
    const origin = req.headers.origin;
    // Same-origin by default; an explicit allowlist supports independently hosted frontends.
    let originOK = !origin;
    if (origin) {
      try {
        const u = new URL(origin);
        originOK = allowedOrigins.length
          ? allowedOrigins.includes(origin)
          : u.host === req.headers.host;
      } catch {
        originOK = false;
      }
    }
    if (
      req.url !== "/ws" ||
      banned.has(ip) ||
      !originOK ||
      (ipCounts.get(ip) || 0) >=
        Number(process.env.MAX_CONNECTIONS_PER_IP || 100)
    ) {
      socket.write("HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n");
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) =>
      wss.emit("connection", ws, req),
    );
  });
  wss.on("connection", (ws, req) => {
    const ip = req.socket.remoteAddress || "unknown";
    ipCounts.set(ip, (ipCounts.get(ip) || 0) + 1);
    const c: Connection = {
      seen: new Map(),
      lastInput: Date.now(),
      lastChat: 0,
      lastRespawn: 0,
      budget: 0,
      window: Date.now(),
      alive: true,
      splitQueue: 0,
      nextSplit: 0,
      joined: false,
      violations: 0,
      created: Date.now(),
    };
    peers.set(ws, c);
    ws.on("pong", () => {
      c.alive = true;
    });
    ws.on("error", () => {});
    ws.on("message", (raw) => {
      const now = Date.now();
      messages++;
      if (now - c.window >= 1000) {
        c.window = now;
        c.budget = 0;
      }
      if (++c.budget > 100) {
        dropped++;
        if (c.budget > 200) ws.close(1008, "Rate limit");
        return;
      }
      let decoded: unknown;
      try {
        decoded = JSON.parse(raw.toString());
      } catch {
        if (++c.violations > 5) ws.close(1008, "Invalid JSON");
        return;
      }
      const parsed = schema.safeParse(decoded);
      if (!parsed.success) {
        error(ws, "Invalid message");
        if (++c.violations > 10) ws.close(1008, "Invalid message");
        return;
      }
      const m = parsed.data;
      if (m.type === "ping") {
        send(ws, { type: "pong", time: m.time });
        return;
      }
      if (m.type === "join") {
        if (c.joined) {
          error(ws, "Already joined");
          return;
        }
        const room = rooms.get(m.room);
        if (!room) {
          error(ws, "Room not found");
          return;
        }
        const old = m.token ? sessions.get(m.token) : undefined;
        if (old && old.room === room && old.spectate === !!m.spectate) {
          if (old.socket && old.socket !== ws) {
            const prev = peers.get(old.socket);
            if (prev) prev.session = undefined;
            send(old.socket, {
              type: "kicked",
              message: "Session resumed elsewhere",
            });
            old.socket.close(4001, "Session resumed elsewhere");
          }
          old.socket = ws;
          old.ip = ip;
          old.expires = Infinity;
          c.session = old;
          c.joined = true;
          c.seen.clear();
          welcome(ws, old);
          return;
        }
        if (
          [...room.world.players.values()].filter((p) => !p.bot).length >=
            room.world.rules.maxPlayers &&
          !m.spectate
        ) {
          error(ws, "Room full");
          return;
        }
        if (
          [...sessions.values()].filter((s) => s.room === room && s.spectate)
            .length >= 100 &&
          m.spectate
        ) {
          error(ws, "Spectator capacity reached");
          return;
        }
        const id = randomBytes(9).toString("hex"),
          token = randomBytes(32).toString("hex");
        const s: Session = {
          id,
          token,
          room,
          socket: ws,
          spectate: !!m.spectate,
          expires: Infinity,
          ip,
          muted: false,
        };
        sessions.set(token, s);
        c.session = s;
        c.joined = true;
        if (!s.spectate)
          room.world.addPlayer(
            id,
            clean(m.name) || "Wanderer",
            ["orbit", "solar", "lunar", "mint", "nova", "ember"].includes(
              m.skin,
            )
              ? m.skin
              : "orbit",
          );
        welcome(ws, s);
        return;
      }
      const s = c.session;
      if (!s) return;
      const world = s.room.world,
        p = world.players.get(s.id);
      if (m.type === "view") {
        c.view = {
          x: Math.max(0, Math.min(world.rules.width, m.x)),
          y: Math.max(0, Math.min(world.rules.height, m.y)),
          width: m.width,
          height: m.height,
        };
        return;
      }
      if (m.type === "chat") {
        if (now - c.lastChat < 1000 || s.muted) return;
        c.lastChat = now;
        const text = clean(m.text, 180);
        if (!text) return;
        for (const [other, conn] of peers)
          if (conn.session?.room === s.room)
            send(other, {
              type: "chat",
              id: s.id,
              name: p?.name || "Spectator",
              text,
              time: now,
            });
        return;
      }
      if (s.spectate || !p) return;
      if (m.type === "input") {
        if (m.seq < p.input.seq) return;
        c.lastInput = now;
        const tapFeed = m.feed && !p.input.feed;
        world.setInput(s.id, {
          x: Math.max(0, Math.min(world.rules.width, m.x)),
          y: Math.max(0, Math.min(world.rules.height, m.y)),
          fast: m.fast,
          feed: m.feed,
          seq: m.seq,
        });
        if (tapFeed) world.eject(s.id, false);
      }
      if (
        m.type === "split" &&
        p.cells.length &&
        c.splitQueue === 0 &&
        world.now >= c.nextSplit
      ) {
        c.splitQueue = m.count;
      }
      if (
        m.type === "respawn" &&
        !p.cells.length &&
        now - c.lastRespawn > 1000
      ) {
        world.spawn(p);
        c.lastRespawn = now;
        c.seen.clear();
        c.splitQueue = 0;
      }
    });
    ws.on("close", () => {
      ipCounts.set(ip, Math.max(0, (ipCounts.get(ip) || 1) - 1));
      peers.delete(ws);
      if (c.session?.socket === ws) {
        const s = c.session;
        s.socket = undefined;
        s.expires = Date.now() + 15_000;
        const p = s.room.world.players.get(s.id);
        if (p) {
          p.input.fast = false;
          p.input.feed = false;
        }
      }
    });
  });
  function snapshot(
    ws: WebSocket,
    c: Connection,
    r: Room,
    packedEntities: Map<
      string,
      { entity: Entity; stamp: string; delta: EntityPatch }
    >,
  ) {
    const s = c.session!;
    const w = r.world,
      p = w.players.get(s.id);
    const mine =
      p?.cells
        .map((id) => w.entities.get(id))
        .filter((e): e is Entity => !!e) || [];
    const mass = w.mass(s.id);
    let cx = w.rules.width / 2,
      cy = w.rules.height / 2;
    if (mine.length && mass) {
      cx = mine.reduce((v, e) => v + e.x * e.mass, 0) / mass;
      cy = mine.reduce((v, e) => v + e.y * e.mass, 0) / mass;
    }
    if (s.spectate && c.view) {
      cx = c.view.x;
      cy = c.view.y;
    }
    const vw = Math.max(c.view?.width || 2200, 1200),
      vh = Math.max(c.view?.height || 1400, 900);
    const next = new Map<string, string>(),
      changed: EntityPatch[] = [];
    const full = c.seen.size === 0 || r.snapshots % 150 === 0;
    for (const { entity: e, stamp, delta } of packedEntities.values()) {
      const rad = radius(e.mass, w.rules.radiusScale);
      if (
        e.owner !== s.id &&
        !(s.spectate && e.owner === r.board[0]?.id) &&
        (Math.abs(e.x - cx) > vw / 2 + rad + 150 ||
          Math.abs(e.y - cy) > vh / 2 + rad + 150)
      )
        continue;
      next.set(e.id, stamp);
      if (full || !c.seen.has(e.id)) changed.push(e);
      else if (c.seen.get(e.id) !== stamp) changed.push(delta);
    }
    const removed = full
      ? []
      : [...c.seen.keys()].filter((id) => !next.has(id));
    const board = r.board;
    const rank = board.findIndex((e) => e.id === s.id) + 1;
    const data: Snapshot = {
      type: "snapshot",
      time: w.now,
      tick: w.tick,
      ack: p?.input.seq || 0,
      entities: changed,
      removed,
      full,
      leaderboard: board.slice(0, 10),
      me: {
        id: s.id,
        mass,
        peak: p?.peak || 0,
        kills: p?.kills || 0,
        rank,
        alive: mine.length > 0,
        survival: p ? ((p.deadAt ?? w.now) - p.joined) / 1000 : 0,
      },
      humans: roomInfo(r).humans,
      bots: roomInfo(r).bots,
      rules: {
        width: w.rules.width,
        height: w.rules.height,
        radiusScale: w.rules.radiusScale,
        zoomMin: w.rules.zoomMin,
        zoomMax: w.rules.zoomMax,
        spectatorSpeed: w.rules.spectatorSpeed,
      },
    };
    if (ws.readyState === WebSocket.OPEN && ws.bufferedAmount < 512_000) {
      send(ws, data);
      c.seen = next;
    } else c.seen.clear();
  }
  const timer = setInterval(() => {
    const at = performance.now();
    const subscribers = new Map<Room, Array<[WebSocket, Connection]>>();
    for (const [ws, connection] of peers) {
      if (!connection.session) continue;
      const room = connection.session.room;
      const list = subscribers.get(room);
      if (list) list.push([ws, connection]);
      else subscribers.set(room, [[ws, connection]]);
    }
    for (const r of rooms.values()) {
      const clients = subscribers.get(r);
      if (!clients?.length) {
        // No observer: pause this arena and discard idle elapsed time.
        r.last = at;
        r.accumulator = 0;
        continue;
      }
      const elapsed = Math.min((at - r.last) / 1000, 0.25);
      r.last = at;
      r.accumulator += elapsed;
      const dt = 1 / r.world.rules.tickRate;
      let steps = 0;
      while (r.accumulator >= dt && steps++ < 8) {
        for (const [, c] of clients)
          if (c.session) {
            const p = r.world.players.get(c.session.id);
            if (p && Date.now() - c.lastInput > 500) {
              p.input.fast = false;
              p.input.feed = false;
            }
            if (c.splitQueue && r.world.now >= c.nextSplit) {
              r.world.split(c.session.id, 1);
              c.splitQueue--;
              c.nextSplit = r.world.now + r.world.rules.splitCooldown;
            }
          }
        r.world.step(dt);
        r.accumulator -= dt;
      }
      if (r.world.now - r.boardAt >= r.world.rules.leaderboardInterval) {
        r.board = r.world.leaderboard();
        r.boardAt = r.world.now;
      }
      const snapshotPeriod = 1000 / r.world.rules.snapshotRate;
      if (r.world.now - r.snapshotAt + 1e-6 >= snapshotPeriod) {
        // Keep the send clock in phase across fractional ticks and live rate changes.
        r.snapshotAt += Math.max(1, Math.floor((r.world.now - r.snapshotAt + 1e-6) / snapshotPeriod)) * snapshotPeriod;
        r.snapshots++;
        // Static food is packed once and shared by every client. Mutable entities
        // invalidate their cached wire form only when authoritative fields change.
        for (const id of r.packed.keys())
          if (!r.world.entities.has(id)) r.packed.delete(id);
        for (const e of r.world.entities.values()) {
          const previous = r.packed.get(e.id);
          if (previous?.source === e && previous.x === e.x && previous.y === e.y &&
              previous.mass === e.mass && previous.vx === e.vx && previous.vy === e.vy)
            continue;
          const entity: Entity = {
            ...e,
            x: Math.round(e.x * 10) / 10,
            y: Math.round(e.y * 10) / 10,
            vx: Math.round(e.vx), vy: Math.round(e.vy),
            mass: Math.round(e.mass * 100) / 100,
          };
          const delta: EntityPatch = {
            id: e.id, kind: e.kind, x: entity.x, y: entity.y,
            mass: entity.mass, vx: entity.vx, vy: entity.vy,
            ...(e.owner ? { owner: e.owner } : {}),
          };
          r.packed.set(e.id, {
            entity, stamp: JSON.stringify(entity), delta, source: e,
            x: e.x, y: e.y, mass: e.mass, vx: e.vx, vy: e.vy,
          });
          packedEntityUpdates++;
        }
        for (const [ws, c] of clients) snapshot(ws, c, r, r.packed);
      }
    }
    tickCosts.push(performance.now() - at);
    if (tickCosts.length > 1000) tickCosts.shift();
  }, 1000 / 60);
  const housekeeping = setInterval(() => {
    for (const [ws, c] of peers) {
      if (!c.alive || (!c.joined && Date.now() - c.created > 10000)) {
        ws.terminate();
        continue;
      }
      c.alive = false;
      ws.ping();
    }
    for (const s of sessions.values())
      if (!s.socket && s.expires < Date.now()) removeSession(s);
    for (const [id, r] of rooms)
      if (
        r.private &&
        Date.now() - r.created > 15 * 60_000 &&
        ![...sessions.values()].some((s) => s.room === r)
      )
        rooms.delete(id);
  }, 5000);
  const health = () => {
    const sorted = [...tickCosts].sort((a, b) => a - b);
    return {
      status: "ok",
      uptime: process.uptime(),
      connections: peers.size,
      rooms: rooms.size,
      entities: [...rooms.values()].reduce(
        (s, r) => s + r.world.entities.size,
        0,
      ),
      loopMsP50: sorted[Math.floor(sorted.length * 0.5)] || 0,
      loopMsP95: sorted[Math.floor(sorted.length * 0.95)] || 0,
      messages,
      snapshotBytes,
      dropped,
      packedEntityUpdates,
      roomTicks: [...rooms.values()].map((r) => ({ id:r.id, tick:r.world.tick, tickRate:r.world.rules.tickRate })),
      rssMB: process.memoryUsage().rss / 1024 / 1024,
    };
  };
  app.get("/health", async () => health());
  app.get("/api/rooms", async () =>
    [...rooms.values()].filter((r) => !r.private).map(roomInfo),
  );
  const creationBudget = new Map<string, number>();
  app.post("/api/rooms", async (req, reply) => {
    if (rooms.size >= 25)
      return reply.code(429).send({ error: "Room capacity reached" });
    const now = Date.now();
    if (now - (creationBudget.get(req.ip) || 0) < 5000)
      return reply
        .code(429)
        .send({ error: "Please wait before creating another room" });
    creationBudget.set(req.ip, now);
    const parsed = z
      .object({ name: z.string().max(32).optional() })
      .strict()
      .safeParse(req.body || {});
    if (!parsed.success) return reply.code(400).send({ error: "Invalid room" });
    const code = randomBytes(4).toString("hex").toUpperCase();
    return roomInfo(
      makeRoom(
        code,
        clean(parsed.data.name || "Private Room", 32),
        "new-feed-6-inspired",
        true,
      ),
    );
  });
  app.get<{ Params: { id: string } }>("/api/rooms/:id", async (req, reply) => {
    const r = rooms.get(req.params.id);
    return r ? roomInfo(r) : reply.code(404).send({ error: "Room not found" });
  });
  function authorized(header: string | undefined) {
    const token = process.env.ADMIN_TOKEN;
    if (!token || token.length < 24) return false;
    const supplied = header?.startsWith("Bearer ") ? header.slice(7) : "";
    return (
      supplied.length === token.length &&
      timingSafeEqual(Buffer.from(supplied), Buffer.from(token))
    );
  }
  app.addHook("preHandler", async (req, reply) => {
    if (
      req.url.startsWith("/api/admin") &&
      !authorized(req.headers.authorization)
    )
      return reply.code(401).send({ error: "Unauthorized" });
  });
  app.get("/api/admin", async () => ({
    health: health(),
    rooms: [...rooms.values()].map((r) => ({
      ...roomInfo(r),
      rules: r.world.rules,
      players: [...r.world.players.values()].map((p) => ({
        id: p.id,
        name: p.name,
        bot: p.bot,
        mass: r.world.mass(p.id),
      })),
    })),
  }));
  app.post("/api/admin/action", async (req, reply) => {
    const parsed = z
      .object({
        room: z.string().max(40),
        action: z.enum(["restart", "rules", "bots", "kick", "ban", "mute"]),
        player: z.string().max(40).optional(),
        count: z.number().int().min(0).max(50).optional(),
        rules: z.record(z.string(), z.unknown()).optional(),
      })
      .strict()
      .safeParse(req.body);
    if (!parsed.success)
      return reply.code(400).send({ error: "Invalid action" });
    const m = parsed.data,
      r = rooms.get(m.room);
    if (!r) return reply.code(404).send({ error: "Unknown room" });
    if (m.action === "rules") {
      const changes = m.rules || {};
      const next = { ...r.world.rules };
      for (const [k, v] of Object.entries(changes)) {
        if (!(k in next) || typeof v !== typeof next[k as keyof Rules])
          return reply
            .code(400)
            .send({ error: "Unknown rule or invalid type" });
        (next as unknown as Record<string, unknown>)[k] = v;
      }
      // Runtime limits protect memory and ensure finite, playable room configuration.
      try {
        validateRules(next);
        if (
          next.foodCount > 10000 ||
          next.virusMax > 200 ||
          next.bots > 50 ||
          next.maxPlayers > 100 ||
          next.width > 30000 ||
          next.height > 30000
        )
          throw new Error("Limit");
      } catch {
        return reply.code(400).send({ error: "Unsafe rules" });
      }
      r.world.updateRules(next);
      r.packed.clear();
      r.snapshotAt = 0;
      for (const c of peers.values()) if (c.session?.room === r) c.seen.clear();
    }
    if (m.action === "bots") {
      const desired = m.count ?? 0;
      const bots = [...r.world.players.values()].filter((p) => p.bot);
      for (const p of bots.slice(desired)) r.world.removePlayer(p.id);
      for (let i = bots.length; i < desired; i++)
        r.world.addPlayer(
          "bot-" + randomBytes(6).toString("hex"),
          "Drifter " + (i + 1),
          "orbit",
          true,
        );
      r.world.rules.bots = desired;
    }
    if (m.action === "restart") {
      r.world.restart();
      r.packed.clear();
      for (const c of peers.values()) if (c.session?.room === r) c.seen.clear();
    }
    if (["kick", "ban", "mute"].includes(m.action)) {
      for (const s of sessions.values())
        if (s.room === r && s.id === m.player) {
          if (m.action === "mute") {
            s.muted = true;
            continue;
          }
          if (m.action === "ban") banned.add(s.ip);
          send(s.socket!, {
            type: "kicked",
            message:
              m.action === "ban"
                ? "Banned by administrator"
                : "Removed by administrator",
          });
          s.socket?.close(4003, "Moderation");
          removeSession(s);
        }
      const p = m.player ? r.world.players.get(m.player) : undefined;
      if (p?.bot) r.world.removePlayer(p.id);
    }
    return { ok: true };
  });
  const clientDist = resolve("dist/client");
  if (existsSync(clientDist))
    await app.register(fastifyStatic, { root: clientDist });
  app.addHook("onClose", async () => {
    clearInterval(timer);
    clearInterval(housekeeping);
    for (const ws of peers.keys()) ws.terminate();
    wss.close();
  });
  return app;
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  const app = await createApp();
  await app.listen({
    port: Number(process.env.PORT || 3001),
    host: process.env.HOST || "0.0.0.0",
  });
  const shutdown = async () => {
    await app.close();
    process.exit(0);
  };
  process.once("SIGTERM", shutdown);
  process.once("SIGINT", shutdown);
}
