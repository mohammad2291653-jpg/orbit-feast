# Local and VPS deployment

Requires Node.js 22.12+ (tested version is recorded in DEVELOPMENT_STATUS.md), npm, and a modern browser. No paid service, account, or database is required.

## Development

```sh
npm ci
npm run dev
```

Frontend: http://localhost:5173. Backend: http://localhost:3001. WebSocket: ws://localhost:3001/ws. Vite proxies `/api`, `/health` and `/ws` to the backend. To play from a second device, use the computer's LAN IP on port 5173 and include its exact frontend origin in `ALLOWED_ORIGINS`. Both clients must reach the same backend.

## Production without Docker

```sh
npm ci
npm run build
HOST=0.0.0.0 PORT=3001 NODE_ENV=production npm start
```

The backend serves the compiled frontend from `dist/client`, JSON API and WebSocket on the same port. Keep a persistent Node process with systemd or another service manager; static-only hosting cannot run this authoritative WebSocket server. Changing configuration requires rebuilding or using the authenticated live admin API. Guest sessions, rooms and bans are held in process memory and reset when the process restarts.

Supply environment variables through your service manager or Docker Compose. `.env.example` documents names; a plain `npm run dev` does not automatically load `.env` into the server. Shell example: `ADMIN_TOKEN='a-long-random-secret' ALLOWED_ORIGINS='https://game.example.com' npm start`. Keep the token outside client code and source control. Generate one with a password manager or `openssl rand -hex 32`.

## Docker

```sh
cp .env.example .env
# Edit .env before public hosting.
docker compose up --build -d
```

Open http://localhost:3001. Compose loads `.env` for variable interpolation. The Docker build runs the same TypeScript/production bundle checks as `npm run build`; tests should be run separately before shipping.

## VPS with HTTPS/WSS

Point a domain to the VPS, allow inbound 80/443, install Node or Docker, deploy this directory, and run the production service on loopback or a private Docker network. Use a reverse proxy with a trusted TLS certificate. Example Caddyfile:

```caddyfile
game.example.com {
    reverse_proxy 127.0.0.1:3001
}
```

Caddy handles WebSocket upgrades and HTTPS certificates. Set `ALLOWED_ORIGINS=https://game.example.com`. Browser networking selects WSS when the site uses HTTPS.

Equivalent nginx location (inside your TLS-enabled server):

```nginx
location / {
    proxy_pass http://127.0.0.1:3001;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 90s;
}
```

Configure certificates using your normal ACME tooling. Bind backend ports to loopback when running behind a proxy. Check `/health`, then join from two browsers on the public hostname. Do not put the admin token in a URL or expose the admin API through untrusted clients.

The default server does not trust forwarded client-IP headers. Behind a reverse proxy its per-IP limits and bans therefore see the proxy address. Token/player moderation remains available; configure a narrowly trusted proxy/IP policy in the server before relying on individual public-client IP bans.

One process owns its rooms. Multi-instance deployments need sticky room routing and a shared room directory; they are not implemented. A process restart intentionally resets the arena. This release provides in-memory private invitation codes, not durable secret-password rooms.

## Railway

The root `railway.json` selects the Dockerfile and `/health` readiness check. Deploy the project root as one Railway service with **one replica**: all rooms currently live in one process. Generate a public domain after deployment. The server honors Railway's `PORT` and binds `0.0.0.0`; the browser automatically uses WSS with HTTPS.

Leave `ALLOWED_ORIGINS` unset for the default same-origin check, or set it to the exact generated HTTPS origin. Do not copy the localhost allowlist from `.env.example` into production. Leave `ADMIN_TOKEN` unset unless administration is needed; set `BOTS=0` for human-only rooms. Account access and any required hosting plan must be established before a public deployment can be completed.

## Render

The root `render.yaml` defines one Docker web service on the free plan with `/health` readiness checks and four optional bots. Connect the source repository through Render and create a Blueprint from this file, or select Docker when creating a Web Service. No paid plan is selected by the supplied configuration. Availability and account eligibility for the free plan are determined by Render; do not upgrade without reviewing the cost.

Render supplies `PORT`; do not override it with the localhost example. Leave `ALLOWED_ORIGINS` unset for same-origin access, or set it to the exact generated HTTPS origin. Keep one instance because rooms live in memory. The generated HTTPS domain supports the browser's automatic WSS connections.

Free services can suspend when idle and have resource limits. A restart resets rooms and guest sessions. This is suitable for initial testing; competitive capacity on Render's free resources has not been benchmarked. A connected Render account and source access are still required before actual public deployment.
