export type EntityKind = "cell" | "food" | "eject" | "virus";
export interface Entity {
  id: string;
  kind: EntityKind;
  x: number;
  y: number;
  mass: number;
  vx: number;
  vy: number;
  owner?: string;
  color: string;
  name?: string;
  skin?: string;
  mergeAt?: number;
  born: number;
  source?: string;
  feeds?: number;
}
export interface Input {
  x: number;
  y: number;
  fast: boolean;
  feed: boolean;
  seq: number;
}
export interface Player {
  id: string;
  name: string;
  color: string;
  skin: string;
  bot: boolean;
  cells: string[];
  input: Input;
  joined: number;
  peak: number;
  kills: number;
  lastFeed: number;
  lastFast: number;
  lastSplit: number;
  protectedUntil: number;
  deadAt?: number;
  difficulty?: "easy" | "normal" | "hard";
}
export interface Rules {
  id: string;
  name: string;
  width: number;
  height: number;
  tickRate: number;
  snapshotRate: number;
  maxPlayers: number;
  initialMass: number;
  foodCount: number;
  foodMass: number;
  foodRespawnPerSecond: number;
  decay: number;
  maxMass: number;
  radiusScale: number;
  baseSpeed: number;
  speedExponent: number;
  acceleration: number;
  splitMin: number;
  maxCells: number;
  splitVelocity: number;
  splitDecay: number;
  splitCooldown: number;
  mergeDelay: number;
  mergeMassFactor: number;
  instantMerge: boolean;
  feedInterval: number;
  fastFeedInterval: number;
  ejectMass: number;
  ejectCost: number;
  ejectSpeed: number;
  ejectDecay: number;
  ejectLifetime: number;
  ejectMin: number;
  ejectSpread: number;
  selfFeed: boolean;
  selfFeedDelay: number;
  alternativeSelfFeed: boolean;
  virusCount: number;
  virusMass: number;
  virusFeedCount: number;
  virusLaunchSpeed: number;
  virusMax: number;
  eatRatio: number;
  eatOverlap: number;
  protection: number;
  leaderboardInterval: number;
  zoomMin: number;
  zoomMax: number;
  spectatorSpeed: number;
  bots: number;
  botDifficulty: "easy" | "normal" | "hard";
}
export interface RoomInfo {
  id: string;
  name: string;
  mode: string;
  humans: number;
  bots: number;
  maxPlayers: number;
  status: "online";
  private: boolean;
  code?: string;
}
export interface Rank {
  id: string;
  name: string;
  mass: number;
  bot: boolean;
}
export type EntityPatch = Pick<
  Entity,
  "id" | "kind" | "x" | "y" | "mass" | "vx" | "vy"
> &
  Partial<Entity>;
export interface Snapshot {
  type: "snapshot";
  time: number;
  tick: number;
  ack: number;
  entities: EntityPatch[];
  removed: string[];
  full: boolean;
  leaderboard: Rank[];
  me: {
    id: string;
    mass: number;
    peak: number;
    kills: number;
    rank: number;
    alive: boolean;
    survival: number;
  };
  humans: number;
  bots: number;
  rules: Pick<
    Rules,
    | "width"
    | "height"
    | "radiusScale"
    | "zoomMin"
    | "zoomMax"
    | "spectatorSpeed"
  >;
}
export type ClientMessage =
  | {
      type: "join";
      room: string;
      name: string;
      skin: string;
      token?: string;
      spectate?: boolean;
    }
  | {
      type: "input";
      x: number;
      y: number;
      fast: boolean;
      feed: boolean;
      seq: number;
    }
  | { type: "split"; count: 1 | 2 | 3 }
  | { type: "respawn" }
  | { type: "chat"; text: string }
  | { type: "ping"; time: number }
  | { type: "view"; x: number; y: number; width: number; height: number };
export const SKINS = [
  "orbit",
  "solar",
  "lunar",
  "mint",
  "nova",
  "ember",
] as const;
export const COLORS = [
  "#74e5bf",
  "#a895ff",
  "#ffbc66",
  "#6ccaff",
  "#ff80af",
  "#d4ed77",
];
export const radius = (mass: number, scale = 4) =>
  Math.sqrt(Math.max(0, mass)) * scale;
