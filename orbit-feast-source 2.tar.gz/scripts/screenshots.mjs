import { chromium } from "@playwright/test";
import { mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined),
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
try {
  await mkdir("docs/screenshots", { recursive: true });
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1000 },
  });
  page.on("pageerror", (error) => {
    console.error("Browser error:", error);
    process.exitCode = 1;
  });
  await page.goto("http://127.0.0.1:5173");
  await page.getByTestId("server-feed-6").waitFor();
  await page.screenshot({ path: "docs/screenshots/menu.png", fullPage: true });
  await page.getByTestId("nickname").fill("Orbit Pilot");
  await page.getByTestId("play").click();
  await page.getByText("Connected", { exact: true }).waitFor();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: "docs/screenshots/arena.png" });
  console.log(
    "Browser gameplay HUD",
    await page.getByTestId("player-stats").innerText(),
  );
  await page.getByRole("button", { name: "Return to menu" }).click();
  await page.getByRole("button", { name: "العربية ⌄" }).click();
  await page.screenshot({
    path: "docs/screenshots/arabic.png",
    fullPage: true,
  });
  console.log(
    "Arabic direction",
    await page.locator("html").getAttribute("dir"),
  );
  console.log("Saved menu, gameplay and Arabic screenshots.");
} finally {
  await browser.close();
}
