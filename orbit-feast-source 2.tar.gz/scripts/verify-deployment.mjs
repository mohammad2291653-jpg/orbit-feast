import assert from "node:assert/strict";
import http from "node:http";
import https from "node:https";
import tls from "node:tls";
import WebSocket from "ws";

const base = new URL(process.argv[2] || "https://orbit-feast.onrender.com");
base.pathname = "/";
base.search = "";
base.hash = "";
const began = Date.now();
const deadline = began + 45_000;
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const remaining = () => Math.max(1, deadline - Date.now());
const peers = [];
const report = { target: base.origin, checks: [], snapshots: 0 };

// ws does not automatically use HTTPS_PROXY. This standard CONNECT agent keeps
// public WSS checks on the inherited proxy and retains normal TLS/CA validation.
class ConnectAgent extends https.Agent {
  constructor(proxy) {
    super({ keepAlive: false });
    this.proxy = new URL(proxy);
  }
  createConnection(options, callback) {
    const destination = `${options.host}:${options.port || 443}`;
    const headers = { Host: destination };
    if (this.proxy.username || this.proxy.password) {
      headers["Proxy-Authorization"] = "Basic " + Buffer.from(
        `${decodeURIComponent(this.proxy.username)}:${decodeURIComponent(this.proxy.password)}`,
      ).toString("base64");
    }
    const transport = this.proxy.protocol === "https:" ? https : http;
    const req = transport.request(this.proxy, {
      method: "CONNECT",
      path: destination,
      headers,
      agent: false,
    });
    let completed = false;
    const finish = (error, socket) => {
      if (completed) return;
      completed = true;
      callback(error, socket);
    };
    req.setTimeout(Math.min(12_000, remaining()), () => req.destroy(Error("Proxy CONNECT timeout")));
    req.once("error", (error) => finish(error));
    req.once("connect", (response, socket, head) => {
      if (response.statusCode !== 200) {
        socket.destroy();
        finish(Error(`Proxy CONNECT returned ${response.statusCode}`));
        return;
      }
      if (head.length) socket.unshift(head);
      const secure = tls.connect({
        socket,
        servername: options.servername || options.host,
        rejectUnauthorized: true,
      });
      secure.once("secureConnect", () => finish(null, secure));
      secure.once("error", (error) => finish(error));
    });
    req.end();
    return undefined;
  }
}
const local = ["localhost", "127.0.0.1", "[::1]"].includes(base.hostname);
const proxy = !local && base.protocol === "https:" && (process.env.HTTPS_PROXY || process.env.https_proxy);
const wsAgent = proxy ? new ConnectAgent(proxy) : undefined;

class Peer {
  constructor(label, token) {
    this.label = label;
    this.entities = new Map();
    this.messages = [];
    this.ejected = new Set();
    this.seq = 0;
    this.fast = false;
    this.feed = false;
    this.expectedClose = false;
    this.closed = false;
    const endpoint = new URL("ws", base);
    endpoint.protocol = base.protocol === "https:" ? "wss:" : "ws:";
    this.ws = new WebSocket(endpoint, {
      origin: base.origin,
      agent: wsAgent,
      handshakeTimeout: Math.min(12_000, remaining()),
    });
    peers.push(this);
    this.ws.on("error", (error) => { this.error = error; });
    this.ws.on("close", () => { this.closed = true; });
    this.ws.on("open", () => this.send({
      type: "join", room: "feed-6", name: label, skin: "orbit", ...(token ? { token } : {}),
    }));
    this.ws.on("message", (raw) => {
      const message = JSON.parse(raw.toString());
      this.messages.push(message);
      if (this.messages.length > 300) this.messages.shift();
      if (message.type === "welcome") {
        this.welcome = message;
        this.seq = Math.max(this.seq, message.ack || 0);
        this.send({ type: "view", x: message.rules.width / 2, y: message.rules.height / 2, width: 16000, height: 16000 });
      }
      if (message.type === "error") this.error = Error(`${this.label}: ${message.message}`);
      if (message.type !== "snapshot") return;
      report.snapshots++;
      this.snapshot = message;
      if (message.full) this.entities.clear();
      for (const id of message.removed) this.entities.delete(id);
      for (const update of message.entities) {
        const entity = { ...this.entities.get(update.id), ...update };
        this.entities.set(update.id, entity);
        if (entity.kind === "eject" && entity.source === this.welcome?.id) this.ejected.add(entity.id);
      }
    });
  }
  send(message) {
    if (this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(message));
  }
  input() {
    if (!this.goal || !this.welcome) return this.seq;
    this.send({ type: "input", ...this.goal, fast: this.fast, feed: this.feed, seq: ++this.seq });
    return this.seq;
  }
  start() { this.timer = setInterval(() => this.input(), 50); }
  own() { return [...this.entities.values()].filter((e) => e.kind === "cell" && e.owner === this.welcome?.id); }
  async wait(predicate, description, timeout = 7000) {
    const until = Math.min(deadline, Date.now() + timeout);
    while (Date.now() < until) {
      if (this.error) throw this.error;
      if (this.closed && !this.expectedClose) throw Error(`${this.label} disconnected unexpectedly`);
      const value = predicate();
      if (value) return value;
      await pause(20);
    }
    throw Error(`Timed out: ${description}`);
  }
  stop() { clearInterval(this.timer); this.expectedClose = true; }
}

async function get(path) {
  const response = await fetch(new URL(path, base), { signal: AbortSignal.timeout(Math.min(15_000, remaining())) });
  assert.equal(response.status, 200, `${path} must return 200`);
  return response;
}
function passed(check) { report.checks.push(check); console.log("PASS", check); }

try {
  const root = await get("/");
  assert.match(await root.text(), /Orbit|root/i);
  const health = await (await get("/health")).json();
  assert.equal(health.status, "ok");
  const rooms = await (await get("/api/rooms")).json();
  assert.ok(rooms.some((r) => r.id === "feed-6"));
  assert.ok(rooms.some((r) => r.id === "classic"));
  passed("HTTPS frontend, health and server browser");

  const a = new Peer("Deploy QA-A"), b = new Peer("Deploy QA-B");
  await Promise.all([
    a.wait(() => a.welcome && a.snapshot?.me.alive && a.own().length, "A join", 15000),
    b.wait(() => b.welcome && b.snapshot?.me.alive && b.own().length, "B join", 15000),
  ]);
  assert.notEqual(a.welcome.id, b.welcome.id);
  assert.notEqual(a.welcome.token, b.welcome.token);
  passed("Two independent players over origin-checked WSS");

  const firstA = { ...a.own()[0] }, firstB = { ...b.own()[0] };
  const rules = a.welcome.rules;
  const dx = firstA.x < rules.width / 2 ? 350 : -350;
  const dy = firstB.y < rules.height / 2 ? 350 : -350;
  a.goal = { x: firstA.x + dx, y: firstA.y };
  b.goal = { x: firstB.x, y: firstB.y + dy };
  a.start(); b.start();
  await Promise.all([
    a.wait(() => Math.abs((a.entities.get(firstA.id)?.x ?? firstA.x) - firstA.x) > 3 && Math.abs((a.entities.get(firstB.id)?.y ?? firstB.y) - firstB.y) > 3, "A sees both movements"),
    b.wait(() => Math.abs((b.entities.get(firstA.id)?.x ?? firstA.x) - firstA.x) > 3 && Math.abs((b.entities.get(firstB.id)?.y ?? firstB.y) - firstB.y) > 3, "B sees both movements"),
  ]);
  passed("Independent authoritative movement visible to both clients");

  const chatKey = `deploy-check-${Date.now()}`;
  a.send({ type: "chat", text: chatKey + " <check>" });
  const chat = await b.wait(() => b.messages.find((m) => m.type === "chat" && m.id === a.welcome.id && m.text.includes(chatKey)), "synchronized room chat");
  assert.ok(!chat.text.includes("<") && !chat.text.includes(">"));
  passed("Synchronized sanitized room chat");

  const beforeFeed = a.ejected.size;
  a.feed = true; a.input();
  a.feed = false; const releaseW = a.input();
  await a.wait(() => a.snapshot?.ack >= releaseW && a.ejected.size > beforeFeed, "quick W ejection");
  passed("Quick normal feed creates a server-owned particle");

  const beforeFast = a.ejected.size;
  a.fast = true; a.input();
  await a.wait(() => a.ejected.size >= beforeFast + 4, "repeated fast feed");
  a.fast = false; const releaseF = a.input();
  await a.wait(() => a.snapshot?.ack >= releaseF, "fast feed release acknowledgement");
  const afterRelease = a.ejected.size;
  await pause(220);
  assert.equal(a.ejected.size, afterRelease, "No new shots after acknowledged F release");
  passed("Held fast feed emits repeatedly and stops after release");

  const beforeSplit = a.own().length;
  a.send({ type: "split", count: 1 });
  await a.wait(() => a.own().length > beforeSplit, "directional split");
  passed("Server-authoritative split creates independent owned cells");


  const oldId = b.welcome.id, oldCells = b.own().map((e) => e.id).sort();
  b.stop();
  const resumed = new Peer("Deploy QA-B", b.welcome.token);
  await resumed.wait(() => resumed.welcome && resumed.snapshot?.me.alive && resumed.own().length, "reconnect", 12000);
  assert.equal(resumed.welcome.id, oldId);
  assert.deepEqual(resumed.own().map((e) => e.id).sort(), oldCells);
  await b.wait(() => b.closed || b.messages.some((m) => m.type === "kicked"), "old connection eviction");
  passed("Reconnection retains identity/cells and evicts the duplicate socket");

  report.elapsedMs = Date.now() - began;
  report.status = "passed";
  console.log(JSON.stringify(report, null, 2));
} catch (error) {
  report.elapsedMs = Date.now() - began;
  report.status = "failed";
  report.error = error.message;
  console.error(JSON.stringify(report, null, 2));
  process.exitCode = 1;
} finally {
  for (const peer of peers) {
    peer.stop();
    if (peer.ws.readyState === WebSocket.OPEN) peer.ws.close(1000, "Deployment verification complete");
    else if (peer.ws.readyState !== WebSocket.CLOSED) peer.ws.terminate();
  }
  await pause(300);
  for (const peer of peers) if (peer.ws.readyState !== WebSocket.CLOSED) peer.ws.terminate();
  wsAgent?.destroy();
}
