import { afterEach, beforeEach, describe, expect, it } from "vitest";
import WebSocket from "ws";
import { createApp } from "../apps/server/src/index";
import type { FastifyInstance } from "fastify";
import type { World } from "../apps/server/src/simulation";

type Message = Record<string, any>;
class Peer {
  ws: WebSocket;
  messages: Message[] = [];
  constructor(url: string) {
    this.ws = new WebSocket(url);
    this.ws.on("message", (raw) =>
      this.messages.push(JSON.parse(raw.toString())),
    );
  }
  async open() {
    if (this.ws.readyState === WebSocket.OPEN) return;
    await new Promise<void>((resolve, reject) => {
      this.ws.once("open", () => resolve());
      this.ws.once("error", reject);
    });
  }
  send(message: Message) {
    this.ws.send(JSON.stringify(message));
  }
  async wait(predicate: (m: Message) => boolean, since = 0): Promise<Message> {
    const start = Date.now();
    while (Date.now() - start < 6000) {
      const found = this.messages.slice(since).find(predicate);
      if (found) return found;
      await new Promise((r) => setTimeout(r, 20));
    }
    throw new Error(
      "Timed out waiting for message; received " +
        this.messages
          .slice(-4)
          .map((x) => x.type)
          .join(","),
    );
  }
  async join(name: string, token?: string, room = "feed-6") {
    await this.open();
    this.send({ type: "join", room, name, skin: "orbit", token });
    return this.wait((m) => m.type === "welcome");
  }
  close() {
    this.ws.terminate();
  }
}
let app: FastifyInstance;
let peers: Peer[] = [];
let url = "";
const peer = () => {
  const p = new Peer(url);
  peers.push(p);
  return p;
};
beforeEach(async () => {
  app = await createApp({ bots: 0, test: true });
  await app.listen({ host: "127.0.0.1", port: 0 });
  const a = app.server.address();
  if (!a || typeof a === "string") throw Error("No address");
  url = `ws://127.0.0.1:${a.port}/ws`;
});
afterEach(async () => {
  peers.forEach((p) => p.close());
  peers = [];
  await app.close();
});

describe("authoritative real WebSocket multiplayer", () => {
  it("lists truthful human/bot counts and isolates a shareable private room", async () => {
    const initial = (await app.inject("/api/rooms")).json();
    expect(initial.find((r: Message) => r.id === "feed-6").humans).toBe(0);
    expect(initial.find((r: Message) => r.id === "feed-6").bots).toBe(0);
    const created = await app.inject({
      method: "POST",
      url: "/api/rooms",
      payload: { name: "Friends" },
    });
    expect(created.statusCode).toBe(200);
    const room = created.json();
    expect(room.private).toBe(true);
    expect(room.code).toBeTruthy();
    const a = peer();
    await a.join("Private guest", undefined, room.id);
    const rooms = (await app.inject("/api/rooms")).json();
    expect(rooms.find((r: Message) => r.id === "feed-6").humans).toBe(0);
  });
  it("connects independent players and broadcasts their authoritative movement and rankings", async () => {
    const a = peer(),
      b = peer();
    const wa = await a.join("Alpha"),
      wb = await b.join("Beta");
    expect(wa.id).not.toBe(wb.id);
    const world = (app as any).testWorlds.get("feed-6") as World;
    const ca = world.entities.get(world.players.get(wa.id)!.cells[0])!,
      cb = world.entities.get(world.players.get(wb.id)!.cells[0])!;
    ca.x = 2000;
    ca.y = 2000;
    cb.x = 2250;
    cb.y = 2000;
    const x = ca.x,
      bx = cb.x;
    const since = b.messages.length;
    a.send({
      type: "input",
      x: 3000,
      y: 2000,
      fast: false,
      feed: false,
      seq: 1,
    });
    b.send({
      type: "input",
      x: 1500,
      y: 2000,
      fast: false,
      feed: false,
      seq: 1,
    });
    a.send({ type: "view", x: 2200, y: 2000, width: 2000, height: 2000 });
    b.send({ type: "view", x: 2200, y: 2000, width: 2000, height: 2000 });
    await b.wait(
      (m) =>
        m.type === "snapshot" &&
        m.entities.some((e: Message) => e.owner === wa.id && e.x > x + 10),
      since,
    );
    expect(ca.x).toBeGreaterThan(x);
    expect(cb.x).toBeLessThan(bx);
    const snap = await a.wait(
      (m) =>
        m.type === "snapshot" &&
        m.leaderboard.some((r: Message) => r.id === wa.id),
    );
    expect(snap.me.id).toBe(wa.id);
  });
  it("synchronizes sanitized chat and rejects invalid game-state commands", async () => {
    const a = peer(),
      b = peer();
    await a.join("Talker");
    await b.join("Reader");
    a.send({ type: "chat", text: "Hello <script>alert(1)</script>" });
    const chat = await b.wait((m) => m.type === "chat" && m.name === "Talker");
    expect(chat.text).toContain("Hello");
    expect(chat.text).not.toContain("<");
    const since = a.messages.length;
    a.send({
      type: "input",
      x: "NaN",
      y: 10,
      fast: false,
      feed: false,
      seq: 1,
    });
    await a.wait((m) => m.type === "error", since);
  });
  it("consumes enemies, updates rank, reports death and accepts a respawn", async () => {
    const a = peer(),
      b = peer();
    const wa = await a.join("Hunter"),
      wb = await b.join("Prey");
    const world = (app as any).testWorlds.get("feed-6") as World;
    const pa = world.players.get(wa.id)!,
      pb = world.players.get(wb.id)!;
    const ca = world.entities.get(pa.cells[0])!,
      cb = world.entities.get(pb.cells[0])!;
    pa.protectedUntil = 0;
    pb.protectedUntil = 0;
    ca.mass = 700;
    cb.mass = 40;
    ca.x = cb.x = 3000;
    ca.y = cb.y = 3000;
    a.send({ type: "view", x: 3000, y: 3000, width: 1500, height: 1500 });
    b.send({ type: "view", x: 3000, y: 3000, width: 1500, height: 1500 });
    const death = await b.wait((m) => m.type === "snapshot" && !m.me.alive);
    expect(death.me.mass).toBe(0);
    const win = await a.wait((m) => m.type === "snapshot" && m.me.kills >= 1);
    expect(win.me.mass).toBeGreaterThan(700);
    const since = b.messages.length;
    b.send({ type: "respawn" });
    await b.wait((m) => m.type === "snapshot" && m.me.alive, since);
    expect(world.players.get(wb.id)!.cells.length).toBe(1);
  });
  it("reconnects the same guest without duplicating cells or mass and evicts the old socket", async () => {
    const a = peer();
    const wa = await a.join("Reconnect");
    const world = (app as any).testWorlds.get("feed-6") as World;
    const ids = [...world.players.get(wa.id)!.cells];
    const b = peer();
    const wb = await b.join("Reconnect", wa.token);
    expect(wb.id).toBe(wa.id);
    expect(world.players.get(wa.id)!.cells).toEqual(ids);
    expect([...world.players.values()].filter((p) => !p.bot)).toHaveLength(1);
    await a.wait((m) => m.type === "kicked");
  });
  it("honors a quick W tap, held fast-feed cooldowns and release", async () => {
    const a = peer();
    const wa = await a.join("Feeder");
    const world = (app as any).testWorlds.get("feed-6") as World;
    const player = world.players.get(wa.id)!;
    const cell = world.entities.get(player.cells[0])!;
    cell.mass = 1000;
    cell.x = cell.y = 3000;
    world.rules.foodCount = 0;
    world.rules.virusCount = 0;
    world.rules.decay = 0;
    for (const [id, e] of world.entities)
      if (e.kind !== "cell") world.entities.delete(id);
    const before = world.mass(wa.id);
    a.send({
      type: "input",
      x: 5000,
      y: 3000,
      fast: false,
      feed: true,
      seq: 1,
    });
    a.send({
      type: "input",
      x: 5000,
      y: 3000,
      fast: false,
      feed: false,
      seq: 2,
    });
    await a.wait(
      (m) =>
        m.type === "snapshot" && m.ack >= 2 && m.me.mass < before - world.rules.ejectCost + 1,
    );
    expect(
      [...world.entities.values()].some(
        (e) => e.kind === "eject" && e.source === wa.id,
      ),
    ).toBe(true);
    a.send({
      type: "input",
      x: 5000,
      y: 3000,
      fast: true,
      feed: false,
      seq: 3,
    });
    await a.wait((m) => m.type === "snapshot" && m.ack >= 3);
    await new Promise((r) => setTimeout(r, 350));
    a.send({
      type: "input",
      x: 5000,
      y: 3000,
      fast: false,
      feed: false,
      seq: 4,
    });
    await a.wait((m) => m.type === "snapshot" && m.ack >= 4);
    const shots = player.lastFast;
    await new Promise((r) => setTimeout(r, 150));
    expect(player.lastFast).toBe(shots);
    expect(world.mass(wa.id)).toBeLessThan(before - world.rules.ejectCost * 3);
  });
  it("authenticates administration, validates transfer rules and restarts playable cells", async () => {
    const previous = process.env.ADMIN_TOKEN;
    const token = "integration-test-secret-longer-than-24";
    process.env.ADMIN_TOKEN = token;
    try {
      const a = peer();
      const wa = await a.join("Admin subject");
      const headers = { authorization: "Bearer " + token };
      const unsafe = await app.inject({
        method: "POST",
        url: "/api/admin/action",
        headers,
        payload: {
          room: "feed-6",
          action: "rules",
          rules: { ejectMass: 100, ejectCost: 1 },
        },
      });
      expect(unsafe.statusCode).toBe(400);
      const bots = await app.inject({
        method: "POST",
        url: "/api/admin/action",
        headers,
        payload: { room: "feed-6", action: "bots", count: 2 },
      });
      expect(bots.statusCode).toBe(200);
      const world = (app as any).testWorlds.get("feed-6") as World;
      expect([...world.players.values()].filter((p) => p.bot)).toHaveLength(2);
      const restarted = await app.inject({
        method: "POST",
        url: "/api/admin/action",
        headers,
        payload: { room: "feed-6", action: "restart" },
      });
      expect(restarted.statusCode).toBe(200);
      const cells = world.players.get(wa.id)!.cells;
      expect(cells).toHaveLength(1);
      expect(world.entities.has(cells[0])).toBe(true);
      const inspection = await app.inject({ url: "/api/admin", headers });
      expect(inspection.statusCode).toBe(200);
    } finally {
      if (previous === undefined) delete process.env.ADMIN_TOKEN;
      else process.env.ADMIN_TOKEN = previous;
    }
  });
  it("keeps administrative actions behind authentication", async () => {
    const response = await app.inject("/api/admin");
    expect([401, 403, 404, 503]).toContain(response.statusCode);
  });
});
