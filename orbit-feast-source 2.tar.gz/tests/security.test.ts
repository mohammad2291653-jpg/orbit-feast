import { afterEach, beforeEach, expect, it } from "vitest";
import WebSocket from "ws";
import { createApp } from "../apps/server/src/index";
import type { FastifyInstance } from "fastify";
import type { World } from "../apps/server/src/simulation";
let app: FastifyInstance, url: string, world: World;
const sockets: WebSocket[] = [];
beforeEach(async () => {
  app = await createApp({ test: true, bots: 0 });
  await app.listen({ host: "127.0.0.1", port: 0 });
  const address = app.server.address() as { port: number };
  url = `ws://127.0.0.1:${address.port}/ws`;
  world = (app as any).testWorlds.get("feed-6");
});
afterEach(async () => {
  sockets.splice(0).forEach((s) => s.terminate());
  await app.close();
});
async function connect() {
  const ws = new WebSocket(url);
  sockets.push(ws);
  await new Promise<void>((resolve, reject) => {
    ws.once("open", resolve);
    ws.once("error", reject);
  });
  return ws;
}
function next(ws: WebSocket, type: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      ws.off("message", handler);
      reject(Error("Missing " + type));
    }, 3000);
    const handler = (raw: WebSocket.RawData) => {
      const m = JSON.parse(raw.toString());
      if (m.type === type) {
        clearTimeout(timer);
        ws.off("message", handler);
        resolve(m);
      }
    };
    ws.on("message", handler);
  });
}
async function join(ws: WebSocket, token?: string) {
  const pending = next(ws, "welcome");
  ws.send(
    JSON.stringify({
      type: "join",
      room: "feed-6",
      name: "Guard test",
      skin: "orbit",
      token,
    }),
  );
  return pending;
}
it("rejects untrusted browser WebSocket origins before upgrading", async () => {
  const ws = new WebSocket(url, { origin: "https://untrusted.example" });
  sockets.push(ws);
  const code = await new Promise<number>((resolve, reject) => {
    ws.once("unexpected-response", (_req, res) => {
      resolve(res.statusCode!);
      res.resume();
      ws.terminate();
    });
    ws.once("open", () => reject(Error("Untrusted origin connected")));
    ws.on("error", () => {});
  });
  expect(code).toBe(403);
});
it("rejects client mass mutation, duplicate joins, and bounds intended movement", async () => {
  const ws = await connect(),
    welcome = await join(ws);
  const p = world.players.get(welcome.id)!;
  const cell = world.entities.get(p.cells[0])!;
  const start = { x: cell.x, y: cell.y };
  let pending = next(ws, "error");
  ws.send(
    JSON.stringify({
      type: "input",
      x: 0,
      y: 0,
      fast: false,
      feed: false,
      seq: 1,
      mass: 999999,
    }),
  );
  await pending;
  expect(cell.mass).toBeLessThan(200);
  pending = next(ws, "error");
  ws.send(
    JSON.stringify({
      type: "join",
      room: "feed-6",
      name: "Duplicate",
      skin: "orbit",
    }),
  );
  await pending;
  expect([...world.players.values()].filter((p) => !p.bot)).toHaveLength(1);
  ws.send(
    JSON.stringify({
      type: "input",
      x: 1e12,
      y: -1e12,
      fast: false,
      feed: false,
      seq: 2,
    }),
  );
  await next(ws, "snapshot");
  expect(p.input.x).toBe(world.rules.width);
  expect(p.input.y).toBe(0);
  expect(Math.hypot(cell.x - start.x, cell.y - start.y)).toBeLessThan(100);
});
it("resumes input acknowledgements and clears stale held-feed intentions", async () => {
  const ws = await connect(),
    welcome = await join(ws);
  ws.send(
    JSON.stringify({
      type: "input",
      x: 3000,
      y: 3000,
      fast: true,
      feed: false,
      seq: 500,
    }),
  );
  await next(ws, "snapshot");
  const resumed = await connect();
  const again = await join(resumed, welcome.token);
  expect(again.id).toBe(welcome.id);
  expect(again.ack).toBe(500);
  await new Promise((r) => setTimeout(r, 620));
  expect(world.players.get(welcome.id)!.input.fast).toBe(false);
  expect([...world.players.values()].filter((p) => !p.bot)).toHaveLength(1);
});
