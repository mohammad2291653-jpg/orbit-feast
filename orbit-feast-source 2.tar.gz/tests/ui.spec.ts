import { expect, test } from "@playwright/test";

test("menu, real joining, independent browser identities and synchronized chat", async ({
  browser,
}) => {
  const a = await browser.newContext(),
    b = await browser.newContext();
  const first = await a.newPage(),
    second = await b.newPage();
  await Promise.all([first.goto("/"), second.goto("/")]);
  for (const [page, name] of [
    [first, "Browser Alpha"],
    [second, "Browser Beta"],
  ] as const) {
    await expect(page.getByTestId("server-feed-6")).toBeVisible();
    await page.getByTestId("nickname").fill(name);
    await page.getByTestId("play").click();
    await expect(page.getByTestId("player-stats")).toHaveAttribute(
      "data-player-id",
      /.+/,
    );
    await expect(page.getByText("Connected", { exact: true })).toBeVisible();
  }
  const firstId = await first
    .getByTestId("player-stats")
    .getAttribute("data-player-id");
  const secondId = await second
    .getByTestId("player-stats")
    .getAttribute("data-player-id");
  expect(firstId).not.toBe(secondId);
  await expect(first.getByTestId("arena")).toBeVisible();
  await first.keyboard.press("Enter");
  await expect(first.getByTestId("chat-input")).toBeFocused();
  await first.getByTestId("chat-input").fill("Hello from browser alpha");
  await first.keyboard.press("Enter");
  await expect(
    second.getByText("Hello from browser alpha", { exact: true }),
  ).toBeVisible();
  await a.close();
  await b.close();
});

test("Space, W and held F send distinct intended actions and stop on release", async ({
  page,
}) => {
  const frames: any[] = [];
  page.on("websocket", (ws) =>
    ws.on("framesent", (frame) => {
      try {
        frames.push(JSON.parse(String(frame.payload)));
      } catch {}
    }),
  );
  await page.goto("/");
  await page.getByTestId("nickname").fill("Keyboard test");
  await page.getByTestId("play").click();
  await expect(page.getByText("Connected", { exact: true })).toBeVisible();
  await page.mouse.move(1000, 400);
  await page.keyboard.press("Space");
  await expect
    .poll(() => frames.some((m) => m.type === "split" && m.count === 1))
    .toBeTruthy();
  await page.keyboard.down("KeyW");
  await expect
    .poll(() => frames.some((m) => m.type === "input" && m.feed))
    .toBeTruthy();
  await page.keyboard.up("KeyW");
  await page.keyboard.down("KeyF");
  await expect
    .poll(() => frames.filter((m) => m.type === "input" && m.fast).length)
    .toBeGreaterThan(2);
  await page.keyboard.up("KeyF");
  await expect
    .poll(() => frames.filter((m) => m.type === "input").at(-1)?.fast)
    .toBe(false);
  await page.keyboard.press("Enter");
  await page.getByTestId("chat-input").fill("F W Space");
  const splitCount = frames.filter((m) => m.type === "split").length;
  await page.keyboard.press("Space");
  expect(frames.filter((m) => m.type === "split").length).toBe(splitCount);
  await page.keyboard.press("Escape");
});

test("settings persist, Arabic sets RTL, and server selection changes mode", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Settings", exact: true })
    .first()
    .click();
  const dialog = page.getByRole("dialog", { name: "Settings" });
  await expect(dialog).toBeVisible();
  await page.locator("#language-setting").selectOption("ar");
  await expect(page.locator("html")).toHaveAttribute("dir", "rtl");
  await expect(
    dialog.getByText("أسماء اللاعبين", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Close dialog" }).click();
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("lang", "ar");
  await page.getByTestId("server-classic").click();
  await expect(page.getByTestId("server-classic")).toHaveAttribute(
    "aria-pressed",
    "true",
  );
  await page.getByTestId("nickname").fill("لاعب عربي");
  await page.getByTestId("play").click();
  await expect(page.getByTestId("player-stats")).toHaveAttribute(
    "data-player-id",
    /.+/,
  );
  await expect(page.getByTestId("player-stats")).toContainText("لاعب عربي");
});

test("mobile joystick and touch split/feed/fast controls emit input", async ({
  browser,
}) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    hasTouch: true,
    isMobile: true,
  });
  const page = await context.newPage();
  const frames: any[] = [];
  page.on("websocket", (ws) =>
    ws.on("framesent", (frame) => {
      try {
        frames.push(JSON.parse(String(frame.payload)));
      } catch {}
    }),
  );
  await page.goto("/");
  await page.getByTestId("nickname").fill("Touch player");
  await page.getByTestId("play").tap();
  await expect(page.getByTestId("player-stats")).toHaveAttribute(
    "data-player-id",
    /.+/,
  );
  await expect(page.getByTestId("joystick")).toBeVisible();
  await page.getByTestId("touch-split").tap();
  await expect.poll(() => frames.some((m) => m.type === "split")).toBeTruthy();
  const cdp = await context.newCDPSession(page);
  const press = async (id: string) => {
    const box = await page.getByTestId(id).boundingBox();
    if (!box) throw Error("Missing touch target");
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchStart",
      touchPoints: [{ x: box.x + box.width / 2, y: box.y + box.height / 2 }],
    });
  };
  const release = () =>
    cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  await press("touch-feed");
  await expect
    .poll(() => frames.some((m) => m.type === "input" && m.feed))
    .toBeTruthy();
  await release();
  await press("touch-fast");
  await expect
    .poll(() => frames.filter((m) => m.type === "input" && m.fast).length)
    .toBeGreaterThan(2);
  await release();
  await expect
    .poll(() => frames.filter((m) => m.type === "input").at(-1)?.fast)
    .toBe(false);
  await context.close();
});
