# Development status

Verification date: 2026-10-28. This is a working local multiplayer implementation, with the limits below. It is not a claim of measured New Feed 6 parity or production capacity.

## Implemented

- React/TypeScript/Vite client and Node/Fastify/WebSocket server with shared types/configuration.
- Authoritative movement, spatial hashing, food/growth, directionally integrated split bursts, timed merging, ejection, held fast feed, lossy sibling self-feed, viruses, enemy consumption, death and respawn.
- New Feed 6-inspired and Classic presets; optional bots with separate counts; isolated invitation-code rooms; per-tab guest reconnection and duplicate-session eviction.
- Original skins, English/Arabic RTL, main menu/server browser, HUD, real rankings, chat/mute, settings/remapping, minimap, spectator follow/free camera and touch controls.
- Validated/rate-limited intention messages, heartbeat, stale-held-input expiry, bounded particle lifetime, origin checks and bearer-protected administration.
- Development/production scripts, lockfile, Docker build, Compose and VPS HTTPS/WSS guidance.

## Executed verification

| Check                          | Result                                                                                                                     |
| ------------------------------ | -------------------------------------------------------------------------------------------------------------------------- |
| Dependency installation        | Passed; package-lock.json generated                                                                                        |
| `npm run typecheck`            | Passed                                                                                                                     |
| `npm run build`                | Passed: TypeScript, Vite client and bundled Node server                                                                    |
| `npm test`                     | **37/37 passed** under Vitest 5.0.5: 26 physics/configuration, 8 real WebSocket integration and 3 security tests           |
| `npm run test:e2e`             | **4/4 passed** in Chromium, final run 44.6 seconds (overlapped the Docker build)                                                                         |
| `npm audit`                    | **0 reported vulnerabilities**, including development dependencies, at verification time                                   |
| Production `npm start` smoke   | Passed on port 3002 with BOTS=0: frontend/health/rooms HTTP 200 and an origin-checked WebSocket welcome plus live snapshot |
| Docker image build and runtime | Passed: non-root image, frontend/health/rooms HTTP 200 and an actual live WebSocket snapshot                               |

Physics tests cover speed versus mass, boundaries, split direction/conservation/limits, merge timing/conservation, feed accounting and rate limits, sibling self-feed and no unintended mass gain, viruses, eating/contact, protection, respawn, food replenishment, configuration transactions and particle expiry.

WebSocket tests use two real network clients and verify distinct identities, mutually visible independent movement, rankings, sanitized synchronized chat, quick normal-feed taps, held fast-feed release, enemy consumption/death/respawn, private room isolation, duplicate-session reconnection, and authenticated administration including restart. The test-only World handle stages collision positions in process; there is no public HTTP test-control endpoint.

Security tests exercise origin restrictions, rejected mass mutation/duplicate joins, authoritative movement bounds, resume input sequence and stale fast-feed expiry.

Browser tests exercise actual React UI joining with two isolated browser contexts, different identities, synchronized chat, Space/W/held-F intentions and release, typing isolation, persistent settings, Arabic language/RTL, Classic selection and mobile touch actions. Arabic DOM content and direction were verified; native-speaker visual review is still useful. A Playwright run passed after the development servers were stable. Desktop menu, arena and Arabic screenshots were captured under `docs/screenshots/` and visually reviewed; Arabic letter shaping appeared correct.

## Performance measurements

The final benchmark used the production Docker image on port 3005, with bots disabled in both rooms and **40 real WebSocket clients** running independent movement, splitting, feeding, respawning and ping probes. It completed successfully with exit code 0. Raw results are in `docs/load-results.json`.

| Final measured result | Value |
|---|---|
| Clients joined | **40/40** |
| Protocol errors / unexpected disconnects / server message drops | **0 / 0 / 0** |
| Duration including connection ramp | 22.53 s |
| Received snapshots | 11,971; configured publication rate 15 Hz |
| Total client traffic received | 90.06 MiB |
| Average traffic per client | 102.33 KiB/s |
| Loopback RTT p50 / p95 / maximum | 4 / **21** / 31 ms |
| Server loop duration p50 / p95 | 1.63 / **35.72** ms |
| Server RSS after run | 263.98 MiB |

The environment had a shared container quota of **2 CPU cores and 8 GiB RAM**, on an Intel Xeon Platinum 8573C host. The development server remained running in the background; this was not a pristine dedicated host. The load generator ran Node v24.19.0. The benchmark checks networking/simulation behavior, not browser frame rate or Internet latency.

The p95 loop duration **exceeds the 33.3 ms budget for 30 Hz**. This supports a playable initial 40-client loopback result, but does not establish a consistently met tick budget under that workload. JSON snapshot traffic remains substantial; visibility checks, serialization, collision work and allocation should be profiled before increasing capacity. No 50-player production or universal 60 FPS claim is made.

Earlier measurements are retained for transparency:

- `docs/load-development-results.json`: development run overlapping browser tests; p95 loop 95.41 ms and RTT 114 ms.
- `docs/load-before-optimization.json`: production before per-room packing/partial entity updates; p95 loop 52.00 ms, RTT 84 ms and 126.35 KiB/client/s.
- `docs/load-optimized-first.json`: first optimized run before the snapshot-cadence floating-point correction; p95 loop 20.43 ms and RTT 29 ms. Its effective publication rate was lower, so its loop timings are not directly comparable to the final corrected 15 Hz run.

## Remaining scope and practical limits

- New Feed 6 numerical rules, live server behavior and exact feel remain unverified; see REFERENCE_GAPS.md. The preset is configurable engineering work, not a confirmed clone.
- Guest sessions, rooms, chat moderation and bans are in memory; process restart resets them. No persistent accounts, OAuth, database, durable scores or clan/team chat.
- One backend process owns rooms. No distributed room routing, multi-region orchestration or reconnect persistence across restart.
- Private rooms use invitation codes and are omitted from public listings; they have no password-based authorization. Empty private rooms expire after 15 minutes.
- Original skins are procedural vector artwork. No uploads, external skin catalogue or reference graphics. Player name-label colors are fixed; there is no separate name-color selector.
- Prediction/interpolation smooth presentation and reconcile to server updates, but are not full input-history replay or lag-compensated collision detection. WAN latency and fairness need real-network playtesting.
- Chat has basic rate limiting, length limits and mute controls, without an audit dashboard or advanced automated abuse moderation. IP bans can affect people sharing an address.
- Canvas2D and large JSON snapshots can bottleneck crowded arenas. No universal 60 FPS, long-duration soak, 50-client production capacity or mobile-device performance claim has been verified.
- External production hosting, certificates, domain routing and multi-device Internet play have not been provisioned. No paid service is needed to run locally.

See docs/DEPLOYMENT.md for persistent hosting and HTTPS/WSS. Docker image/runtime and the final 40-client benchmark were executed successfully. Development frontend/backend and the final Docker HTTP endpoints also returned HTTP 200 at final verification.
