# Orbit Feast · مدار

Play online: **https://orbit-feast.onrender.com**. The free Render test deployment has no bots enabled; share the link and select the same server to play with friends. See [public deployment verification](docs/PUBLIC_DEPLOYMENT.md).

An original, playable server-authoritative multiplayer cell arena. Split toward the cursor, grow by recapturing feed, consume rivals and compete with friends. The current custom presets have no ambient food or viruses and no passive mass decay. Arabic RTL and English guest play require no account.

The `new-feed-6-inspired` preset is an engineering approximation with configurable mechanics. Reference-advertised controls were researched; New Feed 6 physics were **not verified**. See [REFERENCE_GAPS.md](REFERENCE_GAPS.md).

## Run locally

Requires Node.js 22.12+ and npm. This workspace was developed with Node 24.

```sh
npm ci
npm run dev
```

Open **http://localhost:5173**. Backend: **http://localhost:3001**; authoritative WebSocket: **ws://localhost:3001/ws**. Open another tab or browser to play as a second person. Guest reconnection tokens are kept per tab in session storage, while name, skin selection, your compressed custom photo and preferences persist locally. Human and bot counts are displayed separately. Private room codes and links select isolated worlds.

```sh
npm run typecheck
npm test
npm run test:e2e
npm run build
npm start
```

Production serves frontend, API and WebSocket together on port 3001. Playwright uses `/usr/bin/chromium` when available, or its bundled browser otherwise. Run `npx playwright install chromium` if needed. Set `CHROMIUM_PATH` to override the executable. If npm cannot write its cache in a restricted workspace, use `npm ci --cache /tmp/orbit-npm-cache`.

## Controls

| Input               | Action                    |
| ------------------- | ------------------------- |
| Mouse               | Move toward cursor        |
| Space               | Split                     |
| W                   | Eject mass                |
| Hold F              | Fast feed; release stops  |
| Q in spectator mode | Toggle free camera        |
| Enter               | Open/send chat            |
| Esc                 | Close chat/menu           |
| Wheel               | Zoom within server limits |

Additional split/toggle bindings are shown and remappable in settings. Unexplained E/R/T/P/F2 reference shortcuts are not claimed as established rules. Mobile has a joystick and split/feed/held fast-feed controls.

## Architecture

- `apps/client`: React/TypeScript UI, Vite, Canvas2D renderer. Canvas2D keeps circles, original procedural skins, cached custom photos, text, grid and visibility culling simple and portable without a large rendering dependency. Performance mode reduces effects.
- `apps/server`: Fastify HTTP, `ws`, fixed-step authoritative simulation, spatial partitioning, bots, rooms and authenticated administration.
- `packages/shared`: protocol types, radius relationship and configuration validation.
- `config`: Classic and inspired gameplay presets; timers use milliseconds, speeds use world units/second, decay is per second.
- `tests`: physics, real WebSocket integration, real-browser UI tests.
- `scripts/load.ts`: approximately 30–50 simulated-client benchmark; results written to `docs/load-results.json`.

Clients submit intentions. The server alone controls positions, mass, consumption, splits, feed cooldowns and rankings. Network snapshots send only visible entities and changed values; clients interpolate and reconcile display state. Disconnects retain a guest for 15 seconds. Resuming a token replaces the old session rather than creating extra cells.

## Tune gameplay

Edit `config/new-feed-6-inspired.json` or `config/classic.json`, then restart development or rebuild production. Every configurable field is declared in `packages/shared/types.ts`. See [docs/CONFIGURATION.md](docs/CONFIGURATION.md) for field groups and units.

The current presets use the owner-requested alternative self-feed mode: each particle is worth 1.5 times its source deduction (main: 21 received / 14 spent; comparison: 24 / 16). This creates mass intentionally when feed is recovered. Non-alternative configurations still reject particle value above cost. Both presets disable ambient food, viruses and passive decay; merge timers are one quarter of the earlier values, with four-times convergence strength. The Classic preset name is retained for room-link compatibility, but its current custom rules are not unmodified Classic FFA or verified New Feed 6 rules. See [the custom gameplay update](docs/CUSTOM_GAMEPLAY_UPDATE.md). Bots are optional and identified separately from human players; the public free deployment uses zero bots.

## Administration

Set `ADMIN_TOKEN` to a random secret of at least 24 characters. Without a token admin access is disabled. Send it only in an `Authorization: Bearer …` header over HTTPS. Keep it out of client builds and source control.

`GET /api/admin` returns room rules, connected identities and health. `POST /api/admin/action` accepts a JSON object with `room` and `action`:

| Action                | Extra fields                                              |
| --------------------- | --------------------------------------------------------- |
| `restart`             | none                                                      |
| `rules`               | `rules`: partial rule object, e.g. `{ "maxPlayers": 40 }` |
| `bots`                | `count`: integer 0–50                                     |
| `kick`, `ban`, `mute` | `player`: player ID                                       |

Rules are validated before mutation. Bans are IP based and in memory. They can affect multiple people behind one shared IP; behind an untrusted reverse proxy they target the proxy address (see deployment guidance). The admin API is intentionally absent from ordinary player UI. Public chat escapes rendering and server text strips markup delimiters; spam and message lengths are limited. Client-side mute and server admin mute are supported.

## Benchmark

With the backend running:

```sh
CLIENTS=40 DURATION=20 npm run load
```

Final measured production-container run: **40/40 clients joined, zero errors/disconnects, 21 ms p95 loopback RTT**, with a **35.72 ms p95 server loop** on a shared 2-CPU quota. The loop p95 exceeds the 33.3 ms budget for 30 Hz; this is an initial measured result, not a capacity guarantee. Full measurements and limitations are in DEVELOPMENT_STATUS.md.

This runs real local WebSocket clients with independent movement, splits, feeding, respawning and RTT probes. It reports actual joined clients, snapshots, traffic, latency, server loop cost and memory. A loopback result is not a production capacity guarantee or a 60 FPS browser benchmark. Measured results and remaining limitations are recorded in [DEVELOPMENT_STATUS.md](DEVELOPMENT_STATUS.md).

## Deploy

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) for production build, Docker Compose, persistent VPS process, HTTPS/WSS, Caddy/nginx and origin configuration. A static host alone cannot run the backend. No paid service is necessary. State is currently held in memory; process restarts reset rooms and guest sessions.
