# Reference research and tuning record

Research date: 2026-10-28. This game is an original implementation; no reference source code, images, skins, branding, or private servers were copied.

## What could be verified

The public browser search tool opened both [Arabic entry](https://agar-ar.com/?lang=ar) and [alternate Arabic route](https://agar-ar.com/ar), but their extracted pages contained only an iframe. The initial shell request failed under the restricted execution network. After an explicit network grant, the Arabic entry returned HTTP 200 with approximately 153 KB of HTML. The static HTML contained the Arabic title and a fallback script-error banner hidden by CSS; this does not establish a runtime failure or a message shown to users. No server list, arena, or live mechanics were established from that static response; no New Feed 6 entry was found. A playable rendered reference session was not obtained.

Indexed text from the official [Arabic entry](https://agar-ar.com/?lang=ar), [Arabic route](https://agar-ar.com/ar), and [English route](https://agar-ar.com/en) provided these **advertised interface facts**, not measurements of live gameplay:

- Mouse movement, Space split, W eject, F fast feed, Q free spectator movement.
- E/R/T/P/F2 are listed without explanations.
- Play/watch buttons, skins, account login, leaderboard, room chat and clan chat.
- A focus mode is advertised to reduce lag.
- Indexed server selector examples include FFA+ and FFA+4. Historical indexed counts were not used as live player counts.

No accessible text established the current New Feed 6 server list entry or its rules. No timing, distance, speed, mass, physics formula, or feed exploit was measured.

## General mechanics supported by primary public documentation

Miniclip's [How to start playing Agar.io](https://support.miniclip.com/hc/en-us/articles/4404685562641-How-to-start-playing-Agar-io) describes growing by eating smaller cells and food, avoiding larger cells, splitting into multiple cells, mouse movement, W ejecting mass and Space splitting. It also describes touch movement and split/shoot buttons. [Party Mode](https://support.miniclip.com/hc/en-us/articles/5894310665745-Party-Mode-in-Agar-io) describes a shareable party code.

These sources support the broad genre mechanics only. The collision ratios, virus rules, speed curves and merge formulas here are engineering choices, not verified official numerical rules.

## New Feed 6 details that remain unknown

| Area        | Unverified details                                                                                | Implementation tuning point                                                             |
| ----------- | ------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------- |
| Arena/start | Dimensions, start mass, food density, decay                                                       | width/height, initialMass, foodCount/foodMass, decay                                    |
| Movement    | Speed curve, acceleration, drag, maximum mass                                                     | baseSpeed, speedExponent, acceleration, maxMass                                         |
| Split       | Minimum mass, impulse, drag, cooldown, cell limit                                                 | splitMin, splitVelocity, splitDecay, splitCooldown, maxCells                            |
| Merge       | Timers, mass dependence, instant merge                                                            | mergeDelay, mergeMassFactor, mergeSpeedMultiplier, instantMerge                                               |
| Feed        | W/F intervals, cost/value, spread, launch/drag                                                    | feedInterval, fastFeedInterval, ejectCost/ejectMass, ejectSpread, ejectSpeed/ejectDecay |
| Self-feed   | Whether source or sibling cells can recapture and at what delay; whether special mass gain exists | selfFeed, selfFeedDelay, alternativeSelfFeed                                            |
| Viruses     | Count, mass, feed threshold, launch behavior, max-cell interaction                                | virusCount, virusMass, virusFeedCount, virusLaunchSpeed, virusMax                       |
| Contact     | Eat ratio, overlap threshold, protection                                                          | eatRatio, eatOverlap, protection                                                        |
| Camera      | Zoom limits, spectator speed                                                                      | zoomMin/zoomMax, spectatorSpeed                                                         |
| UI          | Exact settings, other keys, skins, chat permissions                                               | Local settings and remappable bindings                                                  |

## Selected engineering defaults

`config/new-feed-6-inspired.json` is a **tunable inspired preset, not a reproduction claim**. Its original starting choices included 180 mass, a 6000×6000 map, 16 cells, a 55 ms fast-feed interval, 14 mass cost for a 12-mass particle, and an 8-second merge base plus a mass term. The current owner-requested custom rules remove ambient food and viruses, disable passive decay, use a 21-mass particle for a 14-mass cost, and shorten merging to a 2-second base plus 1.25 ms per mass. Eligible-cell convergence uses a multiplier of 4. The comparison preset also uses the custom environment and 1.5-value transfer, while keeping its smaller start, slower feeding and longer merge baseline. All values live centrally in JSON.

The owner explicitly requested positive self-feed. Both current presets therefore enable the alternative mode, with each particle worth 1.5 times its source deduction; a fully recovered shot produces a net gain of half the deducted amount. The original lossy guard still applies to non-alternative configurations. This custom rule and the faster merging are user choices; no New Feed 6 mass-gain or merge behavior was verified.

To tune: record a timestamped video with visible mass and key presses; measure start mass, split distance at fixed mass, W/F shots over ten seconds, merge eligibility after consecutive splits, self-feed recovery, virus launch threshold and camera behavior. Add observations with source URL/date, distinguish visual estimates from direct numeric readouts, change JSON, then rerun physics and multiplayer tests. Never describe a tuned estimate as a confirmed reference rule.
