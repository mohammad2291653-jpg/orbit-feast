import type { Entity, Snapshot, Rules } from "../../../packages/shared/types";
import { radius } from "../../../packages/shared/types";
export interface Settings {
  lang: "en" | "ar";
  names: boolean;
  mass: boolean;
  skins: boolean;
  grid: boolean;
  dark: boolean;
  borders: boolean;
  animation: boolean;
  performance: boolean;
  minimap: boolean;
  bindings: {
    double: string;
    multi: string;
    mass: string;
    grid: string;
    focus: string;
    spectatorToggle: string;
    freeUp: string;
    freeDown: string;
    freeLeft: string;
    freeRight: string;
  };
}
export const defaults: Settings = {
  lang: "en",
  names: true,
  mass: true,
  skins: true,
  grid: true,
  dark: true,
  borders: true,
  animation: true,
  performance: false,
  minimap: true,
  bindings: {
    double: "KeyD",
    multi: "KeyS",
    mass: "KeyM",
    grid: "KeyG",
    focus: "KeyP",
    spectatorToggle: "KeyQ",
    freeUp: "ArrowUp",
    freeDown: "ArrowDown",
    freeLeft: "ArrowLeft",
    freeRight: "ArrowRight",
  },
};
interface Visual {
  entity: Entity;
  x: number;
  y: number;
  r: number;
  seen: number;
}
export class Arena {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  entities = new Map<string, Visual>();
  camera = { x: 3000, y: 3000, zoom: 0.44 };
  target = { x: 3000, y: 3000 };
  pointer = { x: 0, y: 0 };
  mouseActive = false;
  zoomFactor = 1;
  me = "";
  spectatorLeader = "";
  spectate = false;
  free = false;
  active = false;
  fps = 60;
  settings: Settings = defaults;
  rules: Pick<
    Rules,
    | "width"
    | "height"
    | "radiusScale"
    | "zoomMin"
    | "zoomMax"
    | "spectatorSpeed"
  > = {
    width: 6000,
    height: 6000,
    radiusScale: 4,
    zoomMin: 0.12,
    zoomMax: 1.4,
    spectatorSpeed: 700,
  };
  private frame = 0;
  private last = 0;
  private demo: Entity[] = [];
  private size = { w: innerWidth, h: innerHeight };
  private keys = new Set<string>();
  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    for (let i = 0; i < 140; i++)
      this.demo.push({
        id: "d" + i,
        kind: i < 7 ? "cell" : "food",
        x: (i * 797) % 6000,
        y: (i * 1613) % 6000,
        mass: i < 7 ? [900, 470, 230, 80, 60, 30, 600][i] : 1,
        vx: 0,
        vy: 0,
        born: 0,
        color: ["#80dfbf", "#b3a0fa", "#f1b87b", "#75bde5", "#f098b4"][i % 5],
        skin: ["orbit", "lunar", "solar"][i % 3],
      });
    this.frame = requestAnimationFrame(this.draw);
  }
  snapshot(s: Snapshot) {
    this.rules = s.rules;
    this.spectatorLeader = s.leaderboard[0]?.id || "";
    const hadOwned = [...this.entities.values()].some(
      (v) => v.entity.owner === this.me,
    );
    const now = performance.now();
    if (s.full) {
      const present = new Set(s.entities.map((e) => e.id));
      for (const id of this.entities.keys())
        if (!present.has(id)) this.entities.delete(id);
    }
    for (const id of s.removed) this.entities.delete(id);
    for (const e of s.entities) {
      const old = this.entities.get(e.id);
      if (old) {
        old.entity = { ...old.entity, ...e };
        old.seen = now;
      } else
        this.entities.set(e.id, {
          entity: e as Entity,
          x: e.x,
          y: e.y,
          r: radius(e.mass, s.rules.radiusScale),
          seen: now,
        });
    }
    if (!hadOwned) {
      const own = s.entities.filter((e) => e.owner === this.me);
      const total = own.reduce((n, e) => n + e.mass, 0);
      if (total) {
        this.camera.x = own.reduce((n, e) => n + e.x * e.mass, 0) / total;
        this.camera.y = own.reduce((n, e) => n + e.y * e.mass, 0) / total;
      }
    }
  }
  resize() {
    const dpr = Math.min(
      devicePixelRatio || 1,
      this.settings.performance ? 1 : 2,
    );
    const w = this.canvas.clientWidth,
      h = this.canvas.clientHeight;
    if (
      this.canvas.width !== Math.round(w * dpr) ||
      this.canvas.height !== Math.round(h * dpr)
    ) {
      this.canvas.width = Math.round(w * dpr);
      this.canvas.height = Math.round(h * dpr);
    }
    this.size = { w, h };
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  setPointer(x: number, y: number) {
    this.pointer = { x, y };
    this.mouseActive = true;
  }
  worldTarget() {
    return {
      x: this.camera.x + (this.pointer.x - this.size.w / 2) / this.camera.zoom,
      y: this.camera.y + (this.pointer.y - this.size.h / 2) / this.camera.zoom,
    };
  }
  setKey(key: string, down: boolean) {
    if (down) this.keys.add(key);
    else this.keys.delete(key);
  }
  clearKeys() {
    this.keys.clear();
  }
  destroy() {
    cancelAnimationFrame(this.frame);
  }
  private draw = (stamp: number) => {
    const dt = Math.min((stamp - this.last) / 1000 || 0.016, 0.05);
    this.last = stamp;
    this.fps = this.fps * 0.96 + (1 / dt) * 0.04;
    this.resize();
    const { w, h } = this.size,
      c = this.ctx;
    const dark = this.settings.dark;
    c.fillStyle = dark ? "#10171a" : "#e9efeb";
    c.fillRect(0, 0, w, h);
    const owned = [...this.entities.values()].filter(
      (v) => v.entity.owner === this.me,
    );
    let mass = 0,
      cx = 0,
      cy = 0,
      extent = 0;
    for (const v of owned) {
      mass += v.entity.mass;
      cx += v.entity.x * v.entity.mass;
      cy += v.entity.y * v.entity.mass;
    }
    if (mass) {
      cx /= mass;
      cy /= mass;
      for (const v of owned)
        extent = Math.max(
          extent,
          Math.hypot(v.entity.x - cx, v.entity.y - cy) +
            radius(v.entity.mass, this.rules.radiusScale),
        );
    } else {
      cx = this.camera.x;
      cy = this.camera.y;
    }
    if (this.active) {
      if (this.spectate && this.free) {
        const step = this.rules.spectatorSpeed * dt;
        cx +=
          ((this.keys.has(this.settings.bindings.freeRight) ? 1 : 0) -
            (this.keys.has(this.settings.bindings.freeLeft) ? 1 : 0)) *
          step;
        cy +=
          ((this.keys.has(this.settings.bindings.freeDown) ? 1 : 0) -
            (this.keys.has(this.settings.bindings.freeUp) ? 1 : 0)) *
          step;
        if (this.mouseActive) {
          cx += (this.pointer.x - w / 2) * dt;
          cy += (this.pointer.y - h / 2) * dt;
        }
      } else if (this.spectate && !owned.length) {
        const cells = [...this.entities.values()].filter(
          (v) => v.entity.kind === "cell",
        );
        let following = cells.filter(
          (v) => v.entity.owner === this.spectatorLeader,
        );
        if (!following.length) {
          const first = cells.sort((a, b) => b.entity.mass - a.entity.mass)[0];
          following = first ? [first] : [];
        }
        const total = following.reduce((n, v) => n + v.entity.mass, 0);
        if (total) {
          cx =
            following.reduce((n, v) => n + v.entity.x * v.entity.mass, 0) /
            total;
          cy =
            following.reduce((n, v) => n + v.entity.y * v.entity.mass, 0) /
            total;
          mass = total;
          for (const v of following)
            extent = Math.max(
              extent,
              Math.hypot(v.entity.x - cx, v.entity.y - cy) +
                radius(v.entity.mass, this.rules.radiusScale),
            );
        }
      }
      this.camera.x +=
        (Math.max(0, Math.min(this.rules.width, cx)) - this.camera.x) *
        (1 - Math.exp(-dt * 7));
      this.camera.y +=
        (Math.max(0, Math.min(this.rules.height, cy)) - this.camera.y) *
        (1 - Math.exp(-dt * 7));
      const zoom = Math.max(
        this.rules.zoomMin,
        Math.min(
          this.rules.zoomMax,
          Math.min(
            0.9,
            Math.min(w, h) / (Math.max(500, extent * 3) + Math.sqrt(mass) * 12),
          ) * this.zoomFactor,
        ),
      );
      this.camera.zoom += (zoom - this.camera.zoom) * (1 - Math.exp(-dt * 3));
    } else {
      this.camera.x = 2900 + Math.sin(stamp / 25000) * 600;
      this.camera.y = 3000 + Math.cos(stamp / 30000) * 400;
      this.camera.zoom = Math.max(w / 6500, h / 5700);
    }
    const z = this.camera.zoom;
    c.save();
    c.translate(w / 2, h / 2);
    c.scale(z, z);
    c.translate(-this.camera.x, -this.camera.y);
    const left = this.camera.x - w / (2 * z),
      top = this.camera.y - h / (2 * z),
      right = left + w / z,
      bottom = top + h / z;
    if (this.settings.grid) {
      c.beginPath();
      c.strokeStyle = dark ? "#ffffff09" : "#293e3910";
      c.lineWidth = 1 / z;
      for (let x = Math.floor(left / 100) * 100; x < right; x += 100) {
        c.moveTo(x, top);
        c.lineTo(x, bottom);
      }
      for (let y = Math.floor(top / 100) * 100; y < bottom; y += 100) {
        c.moveTo(left, y);
        c.lineTo(right, y);
      }
      c.stroke();
    }
    c.strokeStyle = "#80dfbf66";
    c.lineWidth = 4 / z;
    c.strokeRect(0, 0, this.rules.width, this.rules.height);
    const visuals = this.active
      ? [...this.entities.values()]
      : this.demo.map((e) => ({
          entity: e,
          x: e.x + Math.sin(stamp / 15000 + e.mass) * 80,
          y: e.y + Math.cos(stamp / 18000 + e.mass) * 80,
          r: radius(e.mass),
          seen: stamp,
        }));
    visuals.sort((a, b) => a.entity.mass - b.entity.mass);
    for (const v of visuals) {
      const e = v.entity;
      const blend = this.settings.animation ? 1 - Math.exp(-dt * 15) : 1;
      const age = Math.min(0.08, (stamp - v.seen) / 1000);
      const predict =
        this.active && e.owner === this.me ? 0.025 : Math.max(0, age - 0.035);
      v.x += (e.x + e.vx * predict - v.x) * blend;
      v.y += (e.y + e.vy * predict - v.y) * blend;
      v.r += (radius(e.mass, this.rules.radiusScale) - v.r) * blend;
      const r = v.r;
      if (
        v.x + r < left ||
        v.x - r > right ||
        v.y + r < top ||
        v.y - r > bottom
      )
        continue;
      c.save();
      c.translate(v.x, v.y);
      c.beginPath();
      if (e.kind === "virus") {
        for (let j = 0; j < 44; j++) {
          const a = (j / 44) * Math.PI * 2,
            rr = r * (j % 2 ? 0.88 : 1.08);
          if (!j) c.moveTo(Math.cos(a) * rr, Math.sin(a) * rr);
          else c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
        }
        c.closePath();
        c.fillStyle = dark ? "#568e45" : "#82c75a";
        c.strokeStyle = "#9bd770";
        c.lineWidth = 3;
        c.fill();
        c.stroke();
        c.restore();
        continue;
      }
      c.arc(0, 0, r, 0, Math.PI * 2);
      c.fillStyle = e.color;
      c.fill();
      if (e.kind === "cell") {
        c.save();
        c.clip();
        if (this.settings.skins && !this.settings.performance) {
          this.skin(c, e.skin || "orbit", r, e.color);
        }
        c.restore();
        if (this.settings.borders) {
          c.strokeStyle = e.owner === this.me ? "#e0ffeecc" : "#ffffff44";
          c.lineWidth = Math.max(2, 2 / z);
          c.stroke();
        }
        if (this.settings.names && r * z > 13) {
          c.textAlign = "center";
          c.textBaseline = "middle";
          c.font = `600 ${Math.max(13 / z, Math.min(r * 0.34, 28 / z))}px system-ui`;
          c.fillStyle = "#102024";
          c.strokeStyle = "#ffffff3a";
          c.lineWidth = 2 / z;
          const label = e.name || "";
          c.strokeText(
            label.slice(0, 18),
            0,
            this.settings.mass ? -r * 0.1 : 0,
            r * 1.7,
          );
          c.fillText(
            label.slice(0, 18),
            0,
            this.settings.mass ? -r * 0.1 : 0,
            r * 1.7,
          );
          if (this.settings.mass) {
            c.font = `500 ${Math.max(10 / z, Math.min(r * 0.2, 17 / z))}px ui-monospace, monospace`;
            c.fillText(Math.round(e.mass).toLocaleString(), 0, r * 0.27);
          }
        }
      }
      c.restore();
    }
    c.restore();
    if (this.active && this.settings.minimap && !this.settings.performance) {
      const mw = 118,
        mh = 118,
        mx = w - mw - 24,
        my = h - mh - 28;
      c.fillStyle = dark ? "#10191ed9" : "#ffffffdd";
      c.strokeStyle = "#ffffff22";
      c.lineWidth = 1;
      c.fillRect(mx, my, mw, mh);
      c.strokeRect(mx, my, mw, mh);
      for (const v of this.entities.values()) {
        if (v.entity.kind !== "cell") continue;
        c.beginPath();
        c.arc(
          mx + (v.entity.x / this.rules.width) * mw,
          my + (v.entity.y / this.rules.height) * mh,
          v.entity.owner === this.me ? 3 : 1.4,
          0,
          Math.PI * 2,
        );
        c.fillStyle = v.entity.owner === this.me ? "#8ce3bf" : "#b6c2c966";
        c.fill();
      }
      c.strokeStyle = "#8ce3bf66";
      c.strokeRect(
        mx + (left / this.rules.width) * mw,
        my + (top / this.rules.height) * mh,
        (w / z / this.rules.width) * mw,
        (h / z / this.rules.height) * mh,
      );
    }
    this.frame = requestAnimationFrame(this.draw);
  };
  private skin(
    c: CanvasRenderingContext2D,
    skin: string,
    r: number,
    color: string,
  ) {
    c.strokeStyle = "#ffffff4a";
    c.fillStyle = "#ffffff1c";
    c.lineWidth = r * 0.07;
    if (skin === "orbit") {
      c.rotate(-0.6);
      c.beginPath();
      c.ellipse(0, 0, r * 1.12, r * 0.36, 0, 0, Math.PI * 2);
      c.stroke();
      c.beginPath();
      c.arc(-r * 0.34, -r * 0.25, r * 0.15, 0, Math.PI * 2);
      c.fill();
    } else if (skin === "solar" || skin === "ember") {
      for (let i = 0; i < 10; i++) {
        c.rotate(Math.PI / 5);
        c.beginPath();
        c.moveTo(r * 0.38, 0);
        c.lineTo(r * 1.1, 0);
        c.stroke();
      }
      c.beginPath();
      c.arc(0, 0, r * 0.3, 0, Math.PI * 2);
      c.fillStyle = color;
      c.fill();
    } else if (skin === "lunar") {
      for (const [x, y, s] of [
        [-0.3, -0.3, 0.22],
        [0.4, 0.2, 0.3],
        [-0.2, 0.5, 0.14],
      ]) {
        c.beginPath();
        c.arc(x * r, y * r, s * r, 0, Math.PI * 2);
        c.fill();
      }
    } else if (skin === "nova") {
      for (let i = 0; i < 5; i++) {
        c.rotate((Math.PI * 2) / 5);
        c.beginPath();
        c.moveTo(0, -r * 0.85);
        c.lineTo(r * 0.18, -r * 0.23);
        c.lineTo(0, 0);
        c.lineTo(-r * 0.18, -r * 0.23);
        c.closePath();
        c.fill();
      }
    } else {
      for (let i = 0; i < 4; i++) {
        c.beginPath();
        c.arc(
          ((i % 2) - 0.5) * r * 0.65,
          (Math.floor(i / 2) - 0.5) * r * 0.65,
          r * 0.26,
          0,
          Math.PI * 2,
        );
        c.fill();
      }
    }
  }
}
