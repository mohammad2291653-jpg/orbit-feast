import { CUSTOM_SKIN_MAX_BYTES, CUSTOM_SKIN_SIZE } from "../../../packages/shared/types";

/** Upload only a small, re-encoded raster. Original files never leave the device. */
export async function preparePhoto(file: File): Promise<string> {
  if (!["image/png", "image/jpeg", "image/webp"].includes(file.type))
    throw new Error("type");
  if (file.size > 5 * 1024 * 1024) throw new Error("size");
  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = url;
    await image.decode();
    if (!image.naturalWidth || !image.naturalHeight ||
      image.naturalWidth * image.naturalHeight > 40_000_000)
      throw new Error("dimensions");
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = CUSTOM_SKIN_SIZE;
    const context = canvas.getContext("2d");
    if (!context) throw new Error("decode");
    const side = Math.min(image.naturalWidth, image.naturalHeight);
    context.drawImage(image,
      (image.naturalWidth - side) / 2, (image.naturalHeight - side) / 2,
      side, side, 0, 0, CUSTOM_SKIN_SIZE, CUSTOM_SKIN_SIZE);
    let result = canvas.toDataURL("image/png");
    if (atob(result.split(",")[1]).length > CUSTOM_SKIN_MAX_BYTES)
      result = canvas.toDataURL("image/jpeg", 0.88);
    return result;
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function storedPhoto(value: unknown): string {
  return typeof value === "string" && value.length < 90_000 &&
    /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(value)
    ? value : "";
}

/** Reuse a live reference; re-upload after a server restart expires it. */
export async function ensurePhoto(image: string, previous = ""): Promise<string> {
  if (/^custom:[a-f0-9]{32}$/.test(previous)) {
    const response = await fetch("/api/skins/" + previous.slice(7), {
      method: "HEAD", cache: "no-store", signal: AbortSignal.timeout(20000),
    });
    if (response.ok) return previous;
    if (response.status !== 404) throw new Error("upload");
  }
  const response = await fetch("/api/skins", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ image }),
    signal: AbortSignal.timeout(20000),
  });
  if (!response.ok) throw new Error(response.status === 429 ? "rate" : "upload");
  const result = await response.json();
  if (!/^custom:[a-f0-9]{32}$/.test(result.skin)) throw new Error("upload");
  return result.skin;
}
