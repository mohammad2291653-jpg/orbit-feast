import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";
export default defineConfig({
  root: fileURLToPath(new URL(".", import.meta.url)),
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    proxy: {
      // Preserve the browser's Host so same-origin upload checks match in dev.
      "/api": { target: "http://127.0.0.1:3001", changeOrigin: false },
      "/health": "http://127.0.0.1:3001",
      "/ws": { target: "ws://127.0.0.1:3001", ws: true },
    },
  },
  build: { outDir: "../../dist/client", emptyOutDir: true },
});
