import { createHash } from "node:crypto";
import { CUSTOM_SKIN_MAX_BYTES } from "../../../packages/shared/types";

const MAX_DIMENSION = 256;
const PNG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
const CUSTOM = /^custom:([a-f0-9]{32})$/;
export const customSkinId = (skin: string) => CUSTOM.exec(skin)?.[1];

/** Inspect raster headers before storing. SVG, URLs, oversized canvases and animations are excluded. */
export function decodeSkin(image: string): { bytes: Buffer; mime: string } {
  const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(image);
  if (!match || match[2].length % 4 !== 0)
    throw new Error("Choose a PNG, JPEG or WebP photo");
  const bytes = Buffer.from(match[2], "base64"), mime = match[1];
  if (!bytes.length || bytes.length > CUSTOM_SKIN_MAX_BYTES)
    throw new Error("Photo exceeds 64 KiB after resizing");
  let width = 0, height = 0;
  if (mime === "image/png") {
    if (bytes.length < 45 || !bytes.subarray(0, 8).equals(PNG) ||
        bytes.readUInt32BE(8) !== 13 || bytes.toString("ascii", 12, 16) !== "IHDR")
      throw new Error("Invalid PNG photo");
    width = bytes.readUInt32BE(16); height = bytes.readUInt32BE(20);
    let offset = 8, ended = false;
    while (offset + 12 <= bytes.length) {
      const length = bytes.readUInt32BE(offset), type = bytes.toString("ascii", offset + 4, offset + 8);
      if (offset + length + 12 > bytes.length || type === "acTL") throw new Error("Invalid PNG photo");
      offset += length + 12;
      if (type === "IEND") { ended = length === 0 && offset === bytes.length; break; }
    }
    if (!ended) throw new Error("Invalid PNG photo");
  } else if (mime === "image/jpeg") {
    if (bytes.length < 12 || bytes.readUInt16BE(0) !== 0xffd8 || bytes.readUInt16BE(bytes.length - 2) !== 0xffd9)
      throw new Error("Invalid JPEG photo");
    let offset = 2;
    while (offset + 4 <= bytes.length) {
      if (bytes[offset++] !== 0xff) break;
      while (bytes[offset] === 0xff) offset++;
      const marker = bytes[offset++];
      if (marker === 0xda || marker === 0xd9) break;
      if (marker === 0x01 || marker >= 0xd0 && marker <= 0xd7) continue;
      const length = bytes.readUInt16BE(offset);
      if (length < 2 || offset + length > bytes.length) break;
      if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) {
        if (length < 8) break;
        height = bytes.readUInt16BE(offset + 3); width = bytes.readUInt16BE(offset + 5); break;
      }
      offset += length;
    }
  } else {
    if (bytes.length < 30 || bytes.toString("ascii", 0, 4) !== "RIFF" ||
        bytes.readUInt32LE(4) + 8 !== bytes.length || bytes.toString("ascii", 8, 12) !== "WEBP")
      throw new Error("Invalid WebP photo");
    const type = bytes.toString("ascii", 12, 16), size = bytes.readUInt32LE(16);
    if (size + 20 > bytes.length) throw new Error("Invalid WebP photo");
    if (type === "VP8X" && size >= 10) {
      if (bytes[20] & 2) throw new Error("Choose a still photo");
      width = 1 + bytes.readUIntLE(24, 3); height = 1 + bytes.readUIntLE(27, 3);
    } else if (type === "VP8L" && size >= 5 && bytes[20] === 0x2f) {
      width = 1 + (bytes.readUInt32LE(21) & 0x3fff);
      height = 1 + ((bytes.readUInt32LE(21) >>> 14) & 0x3fff);
    } else if (type === "VP8 " && size >= 10 && bytes.subarray(23, 26).equals(Buffer.from([0x9d, 0x01, 0x2a]))) {
      width = bytes.readUInt16LE(26) & 0x3fff; height = bytes.readUInt16LE(28) & 0x3fff;
    }
  }
  if (!width || !height || width > MAX_DIMENSION || height > MAX_DIMENSION)
    throw new Error("Photo must be resized to 256 pixels or less");
  return { bytes, mime };
}

interface StoredSkin { bytes: Buffer; mime: string; references: number; used: number }
/** Fixed memory ceiling; active sessions pin photos so another upload cannot evict them. */
export class CustomSkins {
  private images = new Map<string, StoredSkin>();
  constructor(private capacity = 256, private lifetime = 30 * 60_000) {}
  put(image: string, now = Date.now(), reserve?: () => void) {
    const decoded = decodeSkin(image),
      id = createHash("sha256").update(decoded.mime).update(decoded.bytes).digest("hex").slice(0, 32);
    const previous = this.images.get(id);
    if (previous) { previous.used = now; return "custom:" + id; }
    reserve?.();
    this.cleanup(now);
    if (this.images.size >= this.capacity) {
      const available = [...this.images].filter(([, item]) => item.references === 0).sort((a, b) => a[1].used - b[1].used);
      if (!available.length) throw new Error("Photo storage is busy; try again later");
      this.images.delete(available[0][0]);
    }
    this.images.set(id, { ...decoded, references: 0, used: now });
    return "custom:" + id;
  }
  get(id: string) { return this.images.get(id); }
  has(skin: string) { const id = customSkinId(skin); return !!id && this.images.has(id); }
  retain(skin: string) { const id = customSkinId(skin), item = id ? this.images.get(id) : undefined; if (item) { item.references++; item.used = Date.now(); } }
  release(skin: string) { const id = customSkinId(skin), item = id ? this.images.get(id) : undefined; if (item) { item.references = Math.max(0, item.references - 1); item.used = Date.now(); } }
  cleanup(now = Date.now()) { for (const [id, item] of this.images) if (!item.references && now - item.used >= this.lifetime) this.images.delete(id); }
}
