import {
  COLORS,
  radius,
  type Entity,
  type Input,
  type Player,
  type Rank,
  type Rules,
} from "../../../packages/shared/types";
import { validateRules } from "../../../packages/shared/config";

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const distance = (a: Entity, b: Entity) => Math.hypot(a.x - b.x, a.y - b.y);

/** Bounding-box spatial hash. Large cells occupy all intersecting buckets. */
export class SpatialHash {
  private buckets = new Map<string, Entity[]>();
  constructor(
    private scale: number,
    private size = 180,
  ) {}
  rebuild(entities: Iterable<Entity>) {
    this.buckets.clear();
    for (const e of entities) {
      const r = radius(e.mass, this.scale);
      for (
        let x = Math.floor((e.x - r) / this.size);
        x <= Math.floor((e.x + r) / this.size);
        x++
      )
        for (
          let y = Math.floor((e.y - r) / this.size);
          y <= Math.floor((e.y + r) / this.size);
          y++
        ) {
          const key = x + "," + y;
          const bucket = this.buckets.get(key);
          if (bucket) bucket.push(e);
          else this.buckets.set(key, [e]);
        }
    }
  }
  query(x: number, y: number, r: number) {
    const found = new Set<Entity>();
    for (
      let bx = Math.floor((x - r) / this.size);
      bx <= Math.floor((x + r) / this.size);
      bx++
    )
      for (
        let by = Math.floor((y - r) / this.size);
        by <= Math.floor((y + r) / this.size);
        by++
      )
        for (const e of this.buckets.get(bx + "," + by) ?? []) found.add(e);
    return found;
  }
}

/** One isolated server-authoritative arena. All timers use simulation milliseconds. */
export class World {
  entities = new Map<string, Entity>();
  players = new Map<string, Player>();
  now = 0;
  tick = 0;
  readonly rules: Rules;
  private serial = 0;
  private impulses = new Map<string, { x: number; y: number }>();
  private hash: SpatialHash;
  private foodBudget = 0;
  private ejectOrigins = new Map<string, string>();
  private nextBotThink = 0;
  constructor(rules: Rules) {
    this.rules = validateRules({ ...rules });
    this.hash = new SpatialHash(rules.radiusScale);
    for (let n = 0; n < rules.foodCount; n++)
      this.create("food", rules.foodMass);
    for (let n = 0; n < rules.virusCount; n++)
      this.create("virus", rules.virusMass);
    this.hash.rebuild(this.entities.values());
  }
  /** Restart keeps identities/sessions and the arena seed, but replaces all player life state. */
  restart() {
    for (const entity of [...this.entities.values()])
      if (entity.kind === "cell" || entity.kind === "eject")
        this.remove(entity.id);
    this.impulses.clear();
    this.ejectOrigins.clear();
    this.foodBudget = 0;
    for (const player of this.players.values()) {
      player.lastFeed = -Infinity;
      player.lastFast = -Infinity;
      player.lastSplit = -Infinity;
      this.spawn(player);
    }
    this.hash.rebuild(this.entities.values());
  }
  /** Validate a full rule transaction before changing any live values. */
  updateRules(next: Rules) {
    const checked = validateRules({ ...next });
    const scaleChanged = checked.radiusScale !== this.rules.radiusScale;
    Object.assign(this.rules, checked);
    for (const p of this.players.values())
      if (p.bot) p.difficulty = checked.botDifficulty;
    if (scaleChanged) this.hash = new SpatialHash(checked.radiusScale);
    let food = 0,
      viruses = 0;
    for (const e of [...this.entities.values()]) {
      if (e.kind === "food" && ++food > checked.foodCount) {
        this.remove(e.id);
        continue;
      }
      if (e.kind === "virus" && ++viruses > checked.virusMax) {
        this.remove(e.id);
        continue;
      }
      // A deliberate server cap discards excess mass rather than duplicating it.
      if (e.kind === "cell" || e.kind === "virus")
        e.mass = Math.min(e.mass, checked.maxMass);
      this.bound(e);
    }
    this.hash.rebuild(this.entities.values());
  }
  private create(
    kind: Entity["kind"],
    mass: number,
    x = Math.random() * this.rules.width,
    y = Math.random() * this.rules.height,
  ): Entity {
    const e: Entity = {
      id: "e" + ++this.serial,
      kind,
      x,
      y,
      mass,
      vx: 0,
      vy: 0,
      born: this.now,
      color: kind === "virus" ? "#78d35e" : COLORS[this.serial % COLORS.length],
    };
    this.bound(e);
    this.entities.set(e.id, e);
    return e;
  }
  private bound(e: Entity) {
    const r = radius(e.mass, this.rules.radiusScale);
    e.x = clamp(
      e.x,
      Math.min(r, this.rules.width / 2),
      Math.max(this.rules.width / 2, this.rules.width - r),
    );
    e.y = clamp(
      e.y,
      Math.min(r, this.rules.height / 2),
      Math.max(this.rules.height / 2, this.rules.height - r),
    );
  }
  addPlayer(id: string, name: string, skin: string, bot = false): Player {
    const previous = this.players.get(id);
    if (previous) return previous;
    const p: Player = {
      id,
      name: name.slice(0, 24),
      skin,
      color: COLORS[this.players.size % COLORS.length],
      bot,
      cells: [],
      input: {
        x: this.rules.width / 2,
        y: this.rules.height / 2,
        fast: false,
        feed: false,
        seq: 0,
      },
      joined: this.now,
      peak: 0,
      kills: 0,
      lastFeed: -Infinity,
      lastFast: -Infinity,
      lastSplit: -Infinity,
      protectedUntil: 0,
      difficulty: this.rules.botDifficulty,
    };
    this.players.set(id, p);
    this.spawn(p);
    return p;
  }
  spawn(player: Player) {
    if (player.cells.length) return;
    let x = this.rules.width / 2,
      y = this.rules.height / 2;
    for (let i = 0; i < 30; i++) {
      x = 150 + Math.random() * (this.rules.width - 300);
      y = 150 + Math.random() * (this.rules.height - 300);
      if (
        ![...this.entities.values()].some(
          (e) =>
            (e.kind === "cell" || e.kind === "virus") &&
            Math.hypot(e.x - x, e.y - y) <
              radius(e.mass, this.rules.radiusScale) + 150,
        )
      )
        break;
    }
    const e = this.create("cell", this.rules.initialMass, x, y);
    Object.assign(e, {
      owner: player.id,
      name: player.name,
      skin: player.skin,
      color: player.color,
      mergeAt: this.now,
    });
    player.cells = [e.id];
    player.input = { x, y, fast: false, feed: false, seq: 0 };
    player.joined = this.now;
    player.peak = e.mass;
    player.kills = 0;
    player.deadAt = undefined;
    player.protectedUntil = this.now + this.rules.protection;
  }
  removePlayer(id: string) {
    const p = this.players.get(id);
    if (!p) return;
    for (const cell of [...p.cells]) this.remove(cell);
    this.players.delete(id);
  }
  setInput(id: string, input: Input) {
    const p = this.players.get(id);
    if (
      !p ||
      !Number.isFinite(input.x) ||
      !Number.isFinite(input.y) ||
      input.seq < p.input.seq
    )
      return;
    p.input = {
      ...input,
      x: clamp(input.x, 0, this.rules.width),
      y: clamp(input.y, 0, this.rules.height),
    };
  }
  mass(id: string) {
    return (this.players.get(id)?.cells ?? []).reduce(
      (sum, id) => sum + (this.entities.get(id)?.mass ?? 0),
      0,
    );
  }
  leaderboard(): Rank[] {
    return [...this.players.values()]
      .filter((p) => p.cells.length)
      .map((p) => ({
        id: p.id,
        name: p.name,
        mass: Math.round(this.mass(p.id)),
        bot: p.bot,
      }))
      .sort((a, b) => b.mass - a.mass || a.id.localeCompare(b.id));
  }
  private remove(id: string) {
    const e = this.entities.get(id);
    if (!e) return;
    this.entities.delete(id);
    this.impulses.delete(id);
    this.ejectOrigins.delete(id);
    if (e.owner) {
      const p = this.players.get(e.owner);
      if (p) {
        p.cells = p.cells.filter((c) => c !== id);
        if (!p.cells.length) {
          p.deadAt = this.now;
          p.input.fast = false;
          p.input.feed = false;
        }
      }
    }
  }
  private direction(p: Player, e: Entity) {
    const dx = p.input.x - e.x,
      dy = p.input.y - e.y,
      d = Math.hypot(dx, dy);
    return d > 0.01 ? { x: dx / d, y: dy / d } : { x: 1, y: 0 };
  }
  private mergeTime(mass: number) {
    return (
      this.now +
      (this.rules.instantMerge
        ? 0
        : this.rules.mergeDelay + this.rules.mergeMassFactor * mass)
    );
  }
  split(id: string, count = 1) {
    const p = this.players.get(id);
    if (!p || this.now - p.lastSplit < this.rules.splitCooldown) return;
    p.lastSplit = this.now;
    for (let wave = 0; wave < clamp(Math.floor(count), 1, 3); wave++) {
      const cells = p.cells
        .map((id) => this.entities.get(id)!)
        .filter(Boolean)
        .sort((a, b) => b.mass - a.mass || a.id.localeCompare(b.id));
      for (const cell of cells) {
        if (p.cells.length >= this.rules.maxCells) break;
        if (cell.mass < this.rules.splitMin) continue;
        const dir = this.direction(p, cell);
        cell.mass /= 2;
        cell.mergeAt = this.mergeTime(cell.mass);
        const child = this.create(
          "cell",
          cell.mass,
          cell.x + dir.x * radius(cell.mass, this.rules.radiusScale) * 0.7,
          cell.y + dir.y * radius(cell.mass, this.rules.radiusScale) * 0.7,
        );
        Object.assign(child, {
          owner: id,
          name: p.name,
          skin: p.skin,
          color: p.color,
          mergeAt: cell.mergeAt,
        });
        this.impulses.set(child.id, {
          x: dir.x * this.rules.splitVelocity,
          y: dir.y * this.rules.splitVelocity,
        });
        p.cells.push(child.id);
      }
    }
  }
  eject(id: string, fast = false) {
    const p = this.players.get(id);
    if (!p) return;
    // A single shared gate prevents alternating W/F from bypassing rate limits.
    const interval = fast
      ? this.rules.fastFeedInterval
      : this.rules.feedInterval;
    if (this.now - Math.max(p.lastFeed, p.lastFast) < interval) return;
    if (fast) p.lastFast = this.now;
    else p.lastFeed = this.now;
    for (const cellId of [...p.cells]) {
      const cell = this.entities.get(cellId);
      if (
        !cell ||
        cell.mass < this.rules.ejectMin ||
        cell.mass - this.rules.ejectCost < 5
      )
        continue;
      const dir = this.direction(p, cell),
        angle =
          Math.atan2(dir.y, dir.x) +
          (Math.random() - 0.5) * this.rules.ejectSpread;
      const dx = Math.cos(angle),
        dy = Math.sin(angle);
      cell.mass -= this.rules.ejectCost;
      const offset =
        radius(cell.mass, this.rules.radiusScale) +
        radius(this.rules.ejectMass, this.rules.radiusScale) +
        4;
      const particle = this.create(
        "eject",
        this.rules.ejectMass,
        cell.x + dx * offset,
        cell.y + dy * offset,
      );
      Object.assign(particle, {
        source: id,
        color: cell.color,
        vx: dx * this.rules.ejectSpeed,
        vy: dy * this.rules.ejectSpeed,
      });
      this.ejectOrigins.set(particle.id, cell.id);
    }
  }
  private move(dt: number) {
    const r = this.rules;
    for (const e of this.entities.values()) {
      if (e.kind === "cell") {
        const p = this.players.get(e.owner!);
        if (!p) continue;
        const dx = p.input.x - e.x,
          dy = p.input.y - e.y,
          d = Math.hypot(dx, dy);
        const speed =
          r.baseSpeed *
          Math.pow(Math.max(e.mass, 10) / 40, -r.speedExponent) *
          Math.min(1, d / Math.max(20, radius(e.mass, r.radiusScale)));
        const blend = 1 - Math.exp(-r.acceleration * dt);
        e.vx += ((d > 0.01 ? (dx / d) * speed : 0) - e.vx) * blend;
        e.vy += ((d > 0.01 ? (dy / d) * speed : 0) - e.vy) * blend;
        const impulse = this.impulses.get(e.id);
        e.x += (e.vx + (impulse?.x ?? 0)) * dt;
        e.y += (e.vy + (impulse?.y ?? 0)) * dt;
        if (impulse) {
          const drag = Math.exp(-r.splitDecay * dt);
          impulse.x *= drag;
          impulse.y *= drag;
          if (Math.hypot(impulse.x, impulse.y) < 1) this.impulses.delete(e.id);
        }
        if (e.mass > 20)
          e.mass = Math.max(20, e.mass * Math.exp(-r.decay * dt));
      } else if (e.kind === "eject" || e.kind === "virus") {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        const drag = Math.exp(
          -(e.kind === "eject" ? r.ejectDecay : r.splitDecay) * dt,
        );
        e.vx *= drag;
        e.vy *= drag;
      }
      this.bound(e);
    }
  }
  private ownCollisions() {
    for (const p of this.players.values()) {
      const cells = p.cells
        .map((id) => this.entities.get(id)!)
        .filter(Boolean)
        .sort((a, b) => a.id.localeCompare(b.id));
      for (let i = 0; i < cells.length; i++)
        for (let j = i + 1; j < cells.length; j++) {
          const a = cells[i],
            b = cells[j];
          if (!this.entities.has(a.id) || !this.entities.has(b.id)) continue;
          const sum =
            radius(a.mass, this.rules.radiusScale) +
            radius(b.mass, this.rules.radiusScale);
          let dx = b.x - a.x,
            dy = b.y - a.y,
            d = Math.hypot(dx, dy);
          const eligible =
            this.now >= (a.mergeAt ?? 0) && this.now >= (b.mergeAt ?? 0);
          if (
            eligible &&
            d < sum * 0.86 &&
            a.mass + b.mass <= this.rules.maxMass
          ) {
            const mass = a.mass + b.mass;
            a.x = (a.x * a.mass + b.x * b.mass) / mass;
            a.y = (a.y * a.mass + b.y * b.mass) / mass;
            a.mass = mass;
            this.remove(b.id);
            this.bound(a);
            continue;
          }
          // Brief split grace lets the impulse carry the newborn through its parent.
          if (eligible || this.now - Math.max(a.born, b.born) < 250 || d >= sum)
            continue;
          if (d < 0.001) {
            dx = 1;
            dy = 0;
            d = 1;
          }
          const overlap = sum - d,
            total = a.mass + b.mass;
          a.x -= (dx / d) * overlap * (b.mass / total);
          a.y -= (dy / d) * overlap * (b.mass / total);
          b.x += (dx / d) * overlap * (a.mass / total);
          b.y += (dy / d) * overlap * (a.mass / total);
          this.bound(a);
          this.bound(b);
        }
    }
  }
  private virusBurst(cell: Entity) {
    const p = this.players.get(cell.owner!);
    if (!p) return;
    const extra = Math.min(
      this.rules.maxCells - p.cells.length,
      Math.max(0, Math.floor(cell.mass / 18) - 1),
    );
    if (extra <= 0) return;
    const mass = cell.mass / (extra + 1);
    cell.mass = mass;
    cell.mergeAt = this.mergeTime(mass);
    for (let i = 0; i < extra; i++) {
      const angle = (2 * Math.PI * i) / extra,
        dx = Math.cos(angle),
        dy = Math.sin(angle);
      const child = this.create(
        "cell",
        mass,
        cell.x + dx * radius(mass, this.rules.radiusScale) * 0.5,
        cell.y + dy * radius(mass, this.rules.radiusScale) * 0.5,
      );
      Object.assign(child, {
        owner: p.id,
        color: p.color,
        name: p.name,
        skin: p.skin,
        mergeAt: cell.mergeAt,
      });
      p.cells.push(child.id);
      this.impulses.set(child.id, {
        x: dx * this.rules.splitVelocity * 0.75,
        y: dy * this.rules.splitVelocity * 0.75,
      });
    }
  }
  private collisions() {
    const r = this.rules;
    this.hash.rebuild(this.entities.values());
    // Ejected mass feeds viruses before player consumption. Stable IDs settle ties.
    const viruses = [...this.entities.values()]
      .filter((e) => e.kind === "virus")
      .sort((a, b) => a.id.localeCompare(b.id));
    for (const virus of viruses) {
      if (!this.entities.has(virus.id)) continue;
      for (const e of this.hash.query(
        virus.x,
        virus.y,
        radius(virus.mass, r.radiusScale),
      )) {
        if (
          e.kind !== "eject" ||
          !this.entities.has(e.id) ||
          distance(virus, e) > radius(virus.mass, r.radiusScale)
        )
          continue;
        virus.mass = Math.min(r.maxMass, virus.mass + e.mass);
        virus.feeds = (virus.feeds ?? 0) + 1;
        if (virus.feeds >= r.virusFeedCount) {
          const count = [...this.entities.values()].filter(
            (e) => e.kind === "virus",
          ).length;
          if (count < r.virusMax) {
            const v = Math.hypot(e.vx, e.vy),
              dx = v > 0.01 ? e.vx / v : 1,
              dy = v > 0.01 ? e.vy / v : 0;
            // Launch only the mass actually supplied by feeding: low custom feed
            // thresholds must never manufacture a full-size extra virus.
            const launchMass = Math.min(
              r.virusMass,
              Math.max(1, virus.mass - r.virusMass),
            );
            const child = this.create(
              "virus",
              launchMass,
              virus.x + dx * radius(virus.mass, r.radiusScale),
              virus.y + dy * radius(virus.mass, r.radiusScale),
            );
            child.vx = dx * r.virusLaunchSpeed;
            child.vy = dy * r.virusLaunchSpeed;
            virus.mass -= launchMass;
          }
          virus.feeds = 0;
        }
        this.remove(e.id);
      }
    }
    const cells = [...this.entities.values()]
      .filter((e) => e.kind === "cell")
      .sort((a, b) => b.mass - a.mass || a.id.localeCompare(b.id));
    for (const cell of cells) {
      if (!this.entities.has(cell.id)) continue;
      const nearby = [
        ...this.hash.query(cell.x, cell.y, radius(cell.mass, r.radiusScale)),
      ].sort((a, b) => a.id.localeCompare(b.id));
      for (const prey of nearby) {
        if (prey.id === cell.id || !this.entities.has(prey.id)) continue;
        const dist = distance(cell, prey),
          cr = radius(cell.mass, r.radiusScale),
          pr = radius(prey.mass, r.radiusScale);
        if (prey.kind === "cell") {
          if (prey.owner === cell.owner || cell.mass < prey.mass * r.eatRatio)
            continue;
          if (
            (this.players.get(cell.owner!)?.protectedUntil ?? 0) > this.now ||
            (this.players.get(prey.owner!)?.protectedUntil ?? 0) > this.now
          )
            continue;
          if (dist > cr - pr * r.eatOverlap) continue;
          const victim = this.players.get(prey.owner!);
          this.remove(prey.id);
          if (victim && !victim.cells.length) {
            const killer = this.players.get(cell.owner!);
            if (killer) killer.kills++;
          }
        } else if (prey.kind === "virus") {
          if (
            cell.mass < prey.mass * r.eatRatio ||
            dist > cr - pr * r.eatOverlap
          )
            continue;
          // Consuming beyond maxMass discards the surplus; it never creates another entity.
          cell.mass = Math.min(r.maxMass, cell.mass + prey.mass);
          this.remove(prey.id);
          this.virusBurst(cell);
          break;
        } else {
          if (dist > cr - pr * 0.15) continue;
          if (
            prey.kind === "eject" &&
            prey.source === cell.owner &&
            (!r.selfFeed ||
              (this.ejectOrigins.get(prey.id) === cell.id &&
                this.now - prey.born < r.selfFeedDelay))
          )
            continue;
          this.remove(prey.id);
        }
        cell.mass = Math.min(r.maxMass, cell.mass + prey.mass);
      }
    }
  }
  private bots() {
    if (this.now < this.nextBotThink) return;
    this.nextBotThink = this.now + 160;
    for (const p of this.players.values()) {
      if (!p.bot) continue;
      if (!p.cells.length) {
        if (this.now - (p.deadAt ?? 0) > 2000) this.spawn(p);
        continue;
      }
      const cell = p.cells
        .map((id) => this.entities.get(id)!)
        .filter(Boolean)
        .sort((a, b) => b.mass - a.mass)[0];
      if (!cell) continue;
      const nearby = this.hash.query(cell.x, cell.y, 850);
      let goal: Entity | undefined;
      let priority = -Infinity;
      let flee: Entity | undefined;
      for (const e of nearby) {
        if (e.owner === p.id) continue;
        const d = Math.max(1, distance(cell, e));
        if (
          e.kind === "cell" &&
          e.mass > cell.mass * this.rules.eatRatio &&
          d < radius(e.mass, this.rules.radiusScale) + 300
        ) {
          flee = e;
          break;
        }
        if (
          e.kind === "virus" &&
          cell.mass > e.mass * this.rules.eatRatio &&
          p.cells.length < this.rules.maxCells &&
          d < radius(cell.mass, this.rules.radiusScale) + 150
        ) {
          flee = e;
          break;
        }
        const score =
          (e.kind === "cell" && cell.mass > e.mass * 1.6
            ? e.mass * 8
            : e.kind === "food" || e.kind === "eject"
              ? e.mass
              : 0) / d;
        if (score > priority && score > 0) {
          priority = score;
          goal = e;
        }
      }
      if (flee) {
        const dx = cell.x - flee.x,
          dy = cell.y - flee.y,
          d = Math.hypot(dx, dy) || 1;
        p.input.x = clamp(cell.x + (dx / d) * 700, 0, this.rules.width);
        p.input.y = clamp(cell.y + (dy / d) * 700, 0, this.rules.height);
      } else if (goal) {
        p.input.x = goal.x;
        p.input.y = goal.y;
        if (
          p.difficulty !== "easy" &&
          goal.kind === "cell" &&
          cell.mass > goal.mass * 3 &&
          distance(cell, goal) < 360 &&
          Math.random() < (p.difficulty === "hard" ? 0.22 : 0.06)
        )
          this.split(p.id);
      } else if (
        Math.hypot(cell.x - p.input.x, cell.y - p.input.y) < 100 ||
        Math.random() < 0.02
      ) {
        p.input.x = 100 + Math.random() * (this.rules.width - 200);
        p.input.y = 100 + Math.random() * (this.rules.height - 200);
      }
    }
  }
  step(dtSeconds: number) {
    const dt = clamp(dtSeconds, 0, 0.1);
    this.now += dt * 1000;
    this.tick++;
    this.bots();
    for (const p of this.players.values()) {
      if (p.input.fast) this.eject(p.id, true);
      else if (p.input.feed) this.eject(p.id);
    }
    this.move(dt);
    for (const e of this.entities.values())
      if (e.kind === "eject" && this.now - e.born >= this.rules.ejectLifetime)
        this.remove(e.id);
    this.ownCollisions();
    this.collisions();
    let food = 0,
      viruses = 0;
    for (const e of this.entities.values()) {
      if (e.kind === "food") food++;
      else if (e.kind === "virus") viruses++;
    }
    this.foodBudget =
      food >= this.rules.foodCount
        ? 0
        : Math.min(
            this.foodBudget + this.rules.foodRespawnPerSecond * dt,
            this.rules.foodCount,
          );
    while (food < this.rules.foodCount && this.foodBudget >= 1) {
      this.create("food", this.rules.foodMass);
      food++;
      this.foodBudget--;
    }
    while (viruses < this.rules.virusCount) {
      this.create("virus", this.rules.virusMass);
      viruses++;
    }
    for (const p of this.players.values())
      p.peak = Math.max(p.peak, this.mass(p.id));
  }
}
