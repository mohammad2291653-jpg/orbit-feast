# Central gameplay configuration

Edit the complete JSON presets in `config/`. `new-feed-6-inspired.json` contains selected defaults, not measured reference rules. `classic.json` retains a comparison room with its slower spawn/feed/merge baseline; both published presets now include the owner-requested custom environment and positive-feed rules. Validated types live in `packages/shared/types.ts`; basic safety and no-unintended-mass-gain validation lives in `packages/shared/config.ts`.

| Fields | Meaning / units |
|---|---|
| `id`, `name` | Preset identity / displayed mode |
| `width`, `height` | Arena world units |
| `tickRate`, `snapshotRate` | Fixed physics ticks and snapshots per second |
| `maxPlayers` | Human capacity |
| `initialMass`, `maxMass` | Spawn and cell mass limit |
| `foodCount`, `foodMass`, `foodRespawnPerSecond` | Target count, particle value, replenishment rate |
| `decay` | Fractional mass decay per second |
| `radiusScale` | Radius = scale × sqrt(mass) |
| `baseSpeed`, `speedExponent`, `acceleration` | Mass-sensitive speed curve and smoothing response |
| `splitMin`, `maxCells` | Split mass requirement and owned cell limit |
| `splitVelocity`, `splitDecay`, `splitCooldown` | Burst speed, drag coefficient per second, command cooldown ms |
| `mergeDelay`, `mergeMassFactor`, `instantMerge` | Base eligibility delay ms, additional ms per mass, timer bypass. Current values are one quarter of the earlier timers. |
| `mergeSpeedMultiplier` | Eligible sibling convergence multiplier; current custom value 4, applied after merge eligibility and within the attraction distance |
| `feedInterval`, `fastFeedInterval` | Normal/held-fast feed cooldown ms |
| `ejectMass`, `ejectCost` | Particle value and source deduction per shot per eligible cell |
| `ejectSpeed`, `ejectDecay`, `ejectMin` | Launch speed, drag coefficient, minimum source mass |
| `ejectSpread`, `ejectLifetime` | Angular spread radians and particle lifetime ms (default 60000) |
| `maxEjectedParticles` | Per-room particle budget (current 2000); a new shot retires the oldest particle when the cap is reached |
| `selfFeed`, `selfFeedDelay`, `alternativeSelfFeed` | Own-particle recapture toggle, source-cell immunity ms, allow value > cost. Sibling cells can receive particles immediately. |
| `virusCount`, `virusMass`, `virusMax` | Target count, base mass, launch count cap |
| `virusFeedCount`, `virusLaunchSpeed` | Ejected-particle threshold and launched-virus speed |
| `eatRatio`, `eatOverlap` | Required mass advantage and penetration threshold |
| `protection` | Respawn protection ms |
| `leaderboardInterval` | Ranking refresh ms |
| `zoomMin`, `zoomMax`, `spectatorSpeed` | Camera limits and free-camera world units/second |
| `bots`, `botDifficulty` | Optional AI count and easy/normal/hard behavior |

Action cooldowns are checked against fixed simulation ticks, so their actual intervals are quantized by tick duration. For example, a 55 ms held-feed cooldown at 30 Hz normally fires every two ticks (about 66.7 ms). The configured cooldown remains a lower bound, not a guarantee of sub-tick scheduling. Snapshot scheduling uses a separate accumulator with floating-point tolerance to maintain the configured publication cadence.

Changing timers, ejection value/cost or instant merge can radically alter competitive balance. The owner-requested presets intentionally set `alternativeSelfFeed: true` and `ejectMass = 1.5 * ejectCost`; this is custom mass creation rather than a verified reference rule. A non-alternative configuration continues to require lossy or mass-neutral transfer. Both current presets set food count/respawn, virus count/max and decay to zero. Re-run physics tests after rule changes and validate using actual gameplay recordings before claiming reference parity.

Runtime administration validates a complete rule transaction, applies new arena boundaries and mass caps to existing objects, trims excess food/viruses, updates bot difficulty and refreshes the spatial index when needed. Lowering maxCells prevents further splitting but does not delete already-owned cells. Use the dedicated bots action to change live bot counts. Restart a room for a clean competitive reset after major changes; restart clears cells and ejected particles, resets action cooldowns and respawns players. JSON edits are bundled into the production server, so rebuild production after editing them.
