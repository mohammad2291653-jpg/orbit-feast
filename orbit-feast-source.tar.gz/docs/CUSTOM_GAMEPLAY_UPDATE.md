# Owner-requested custom gameplay and photos

Implementation date: 2026-10-28. These settings are explicit owner choices, not observations of New Feed 6. They apply to the main arena, comparison arena and new private rooms. The comparison preset keeps the `classic` identifier for existing links, but is no longer an unmodified Classic FFA ruleset.

## Gameplay

- Ambient food dots and green viruses are absent. Both presets have `foodCount`, `foodRespawnPerSecond`, `virusCount` and `virusMax` set to zero. The underlying configurable engine still supports them for future modes and physics tests.
- `decay` is zero: a cell loses no mass merely by waiting or moving. Feeding still deducts its explicit cost, and enemies can still consume it.
- `selfFeed` and `alternativeSelfFeed` are enabled. A main-arena shot deducts **14** mass and creates a **21**-mass particle. Recovering that particle adds 21 to the receiving cell: the player gains **7 net** when the whole shot returns. The comparison arena uses **16 spent / 24 received / 8 net**. Feeding does not multiply the player's entire mass by 1.5.
- The source-cell recapture delay remains 300 ms in the main arena and 400 ms in the comparison arena. Other owned cells can receive particles immediately. Particles must physically reach an eligible cell; an expelled particle is not automatic income. Minimum ejection mass, rate limits, particle expiry and the existing per-cell 20,000 mass cap still apply. Each room retains at most 2,000 ejected particles; making another shot retires the oldest particle first, preserving responsive feeding while bounding simulation work. A cap can discard overflow.
- “300% faster” is interpreted as **four times the merging rate**. Both the base merge delay and mass-dependent term are divided by four. Main eligibility is now `2000 ms + 1.25 ms × resulting cell mass` instead of `8000 + 5 × mass`; comparison eligibility is `7500 + 3.75 × mass` instead of `30000 + 15 × mass`.
- Eligible siblings also use `mergeSpeedMultiplier: 4` for smooth convergence when close enough. They still require contact and eligibility to merge; separate cells do not instantly teleport together. Repeated splits refresh eligibility as before.

All values remain centralized in `config/`. Non-alternative configurations still reject particle value above its cost, so positive transfer occurs only when deliberately configured.

## Personal cell photo

The menu accepts PNG, JPEG and WebP files up to **5 MB**. The browser crops the center to a **128 × 128** square, encodes a still PNG (JPEG fallback for an unusually large encoded result) and shows the circular preview. Selecting an original starter skin or removing the photo returns to the original artwork.

On Play, the browser uploads the compressed raster through `POST /api/skins`. The server checks the raster type/signature, dimensions of at most 256 pixels, decoded size of at most 64 KiB, upload origin and bounded rate limits. SVG and external image URLs are not accepted. Snapshots carry a short content-hash reference; clients fetch the photo once, decode/cache it and draw it clipped inside the cell. Split cells and other players see the same photo, including in performance mode when skins are enabled.

The compressed photo and selection persist in this browser's local storage. Server images are in memory, with a maximum of 256 stored images (at most 16 MiB of image payload), active-session retention and expiry/eviction for unused photos. The server also bounds unique uploads to 60 per minute; identical photos reuse the same stored image. A server restart resets server-side images and sessions; reconnect checks the image reference and uploads the locally retained image again if needed. This is guest photo selection, not a persistent account or external image catalogue.

## Verification

Executed `BOTS=0 npm run test:e2e`: **6/6 browser tests passed in 31.1 seconds** after app changes stabilized. The suite includes the four existing multiplayer/chat/keyboard/RTL/settings/touch checks and two new photo checks. The photo test generates an original raster, verifies its resized 128 × 128 preview and local persistence, uploads it, observes actual canvas image drawing in the owner and an independent spectator browser, verifies the matching short snapshot reference and raster HTTP response, checks no ambient food/virus entities are sent, switches to a starter skin and removes the stored photo. The second test verifies SVG rejection with a readable error.

The new browser test first found a real dev-proxy integration issue: Vite's shorthand HTTP proxy changed the Host and the server correctly rejected the mismatched upload Origin. Explicit Host preservation fixed local uploads without relaxing origin security. A later run overlapped live file edits and reloaded the first test page; the final stable six-test run passed.

Additional local mobile emulation at **390 × 844, DPR 3** passed with Arabic RTL, a 44 CSS-pixel circular menu preview, no horizontal overflow (`scrollWidth = viewport = 390`), actual custom-photo drawing and zero page errors. The canvas used 585 internal pixels for 390 CSS pixels, preserving the existing 1.5 mobile density cap. Screenshots: `docs/screenshots/custom-photo-mobile-menu.png` and `docs/screenshots/custom-photo-mobile.png`; raw checks: `docs/custom-photo-mobile-verification.json`. These are browser emulation checks, not a physical-phone performance benchmark.

Source changes do not by themselves publish the public Render service. The deployment record identifies which version is live.

Production build and TypeScript passed. The final unit/integration/security/performance suite passed **60/60 tests**, including 42 physics cases. Eight additional HTTP/WebSocket checks passed against the updated production bundle in a local constrained container; these were local checks, not a new public deployment.

## Performance scope

Removing environmental entities reduces arena work and snapshot contents. Image compression and per-reference decode caches keep original multi-megabyte photos out of rendering and WebSocket snapshots. The existing idle-room pause, dynamic/static indexes, delta snapshots, frame-independent interpolation and mobile pixel-density limits remain in use. These changes are not a claim of a particular frame rate on every phone, unlimited player capacity or lower Internet latency. Any measured follow-up result should include its workload and hardware limits.


## Measured local comparison

Both before/after server containers used an independently verified **0.15 CPU / 512 MiB** cgroup limit with BOTS=0. Two actual simulated WebSocket clients moved, split and fed for about 20 seconds per sample. Before: p95 server loop **1.90 ms**, loopback RTT p95 **4 ms**, **19.95 KiB/client/s**, 580 snapshots. After: loop p95 **0.91 ms**, RTT p95 **4 ms**, **16.07 KiB/client/s**, 598 snapshots. Both joined 2/2 with no errors or disconnects; the updated room advanced 600 ticks in about 20.08 measured server seconds. Environmental entities at idle changed from 2,440 baseline to zero. Different randomized positions and gameplay mean the small samples are observations, not a precise speedup guarantee. The connection remains subject to real Internet latency.

Raw final samples: `custom-gameplay-cpu-before-final.json` and `custom-gameplay-cpu-after.json`; `custom-gameplay-performance-summary.json` records the separately verified server cgroup. Earlier noisy samples are retained instead of hidden. The raw load generator environment is the outer machine, not the constrained server.

A separate **30-client stress run** on the same 0.15-CPU/512-MiB server joined 30/30 with zero protocol errors or disconnects, but exceeded the real-time budget: **100.78 ms loop p95**, **676 ms loopback RTT p95**, and about **23.57 simulation Hz** during the measured window. This free-tier-sized CPU is not verified to give smooth play at 30 simultaneous clients. The release improves the small-player case; larger crowds still require more compute and/or further networking/serialization optimization. No paid plan was enabled. Raw result: `custom-gameplay-30-clients.json`.
