# Performance fix prepared for the free deployment

Status: deployed and verified on https://orbit-feast.onrender.com. The owner uploaded the verified archive; deploy dep-dbgootegekts738gimf0 is live from commit 70e2e81285a07cd1b040f3ef1b60e727ae038db0.

## Observed cause

Render CPU metrics repeatedly reached the reported 0.15 CPU limit. The live server health sample recorded loop p50=103.81ms and p95=298.36ms with two connections. The code simulated unobserved rooms and repacked all arena entities even without connected clients. Physics also moved/bounded stationary food and rebuilt its spatial index every tick. Client camera/HUD work amplified the irregular server updates.

## Changes

- Pause arenas with no connected observer and resume without accumulating idle time.
- Keep food in a persistent static spatial index; update only moving entities.
- Track entity kinds incrementally; skip unused collision/virus checks.
- Cache entity wire data across snapshots and clients instead of repacking unchanged food.
- Keep physics authoritative. Existing split/feed/merge/mass rules are preserved.
- Follow smoothed visual cell positions and use bounded velocity extrapolation.
- Send camera views and update React HUD at 5 Hz while inputs remain 20 Hz.
- Cache render ordering, lower mobile canvas pixel density, disable blur in performance mode and report real FPS.

## Executed checks

42 unit/integration/security/performance tests passed; 4 Chromium UI tests passed. TypeScript and production Docker build passed. New tests cover idle-room pause/resume and static data reuse; physics regressions cover static-index updates/removals/rule changes. A seeded 1000-tick comparison matched human simulation state to six decimals.

The Docker comparison used an enforced 0.15 CPU/512 MiB limit and two actual WebSocket clients. Before: 11.03 seconds, loop p95=388.69ms, loopback RTT p50=384ms/p95=445ms, 43 snapshots. After warmup: 20.16 seconds, loop p95=1.54ms, loopback RTT p50=1ms/p95=8ms, 588 snapshots and 601 simulation ticks, equivalent to 29.90 Hz. These are short local constrained-container measurements, not Internet latency measurements. Public measurements are recorded below.

The first cold sample of the updated server had RTT p95=661ms; it is retained in performance-cpu-after-initial.json. The steady-state result does not establish a cold-start or large-player capacity guarantee. Full samples are performance-cpu-before.json and performance-cpu-after.json; summary is performance-fix-results.json.

Release: render-upload-v2/orbit-feast-source.tar.gz. Its SHA256 is 6cb18e6b4b37a2dafde3bae65811c8d133dca595e14047f568a20d3b29f0138f. The existing two-file Dockerfile remains compatible; only this archive needs replacing in the public repository.

## Public verification after deployment

Eight live HTTPS/WSS checks passed in 5,079 ms, covering two-player movement, chat, normal/fast feed with release, split and reconnect. Mobile touch emulation passed with zero page errors; a 390px CSS canvas rendered at 585px with device DPR 3, confirming the reduced pixel-density cap. The browser HUD showed 55 FPS in this emulation; this is not a physical-phone FPS benchmark. Browser testing used the previously documented TLS-verifying QA relay.

Live health samples improved from loop p95=298.36ms with two connections to 1.96ms with three connections. The active arena advanced at 29.98 simulation ticks/second over the observed window; the unused Classic arena remained paused. These are short before/after observations at different times, not an identical-workload benchmark. The Render plan remains free and BOTS=0.
