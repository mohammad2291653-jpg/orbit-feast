# Public deployment

Live URL: https://orbit-feast.onrender.com

Verified on 2026-10-28. Render free web service in Frankfurt, one instance, workspace My Workspace. Source repository: https://github.com/mohammad2291653-jpg/orbit-feast, commit `8c741b64432846a1abdee3a9eefc13ba2d1eeb5c`.

The repository contains the two-file Docker release: Dockerfile and orbit-feast-source.tar.gz. Both Git blob hashes matched the locally tested release before deployment. The archive contains all 45 tracked source files from commit 0bb9b264a1f0eaee912f57e90355df922f7cb976. The Render service builds and serves frontend, HTTP API and WebSocket together.

Service: `srv-dbgnve7lk1mc7392b63g`. Active verified deploy: `dep-dbgo1kvb9u1s738rdufg`, status live. Dashboard: https://dashboard.render.com/web/srv-dbgnve7lk1mc7392b63g

The active service configuration is managed directly through Render: NODE_ENV=production, HOST=0.0.0.0, PORT=10000, BOTS=0. Administration is disabled because ADMIN_TOKEN is unset. Same-origin WebSocket checks are enabled. Bots were disabled to reduce CPU demand on the free plan. No paid compute plan was enabled.

## Executed live verification

The remote verification script passed 8 checks in 7,495 ms: HTTPS frontend, health and room list; two independent players over origin-checked WSS; mutually visible authoritative movement; synchronized sanitized chat; normal feeding; repeated fast feeding and stop on release; independent split cells; reconnection identity/cell retention and old-socket eviction.

The browser verification used a 390×844 touch viewport and the live Render frontend through a temporary TLS-verifying local QA relay. It joined the actual Render server, exercised touch split and held fast-feed controls, and reported zero page errors. Screenshot: screenshots/render-mobile-live.png. This is mobile emulation, not a physical-device check.

Direct Chromium HTTPS browsing in the execution environment encountered the session proxy CA trust limitation. Automatic approval review rejected a persistent NSS trust-store change. No global certificate-store change was made and no TLS verification was disabled; the temporary relay verified upstream HTTPS/WSS using the already-configured session CA. Ordinary public users connect directly to Render's HTTPS domain.

## Limits and updates

Render's free plan has substantially fewer CPU resources than the local benchmark. Runtime health measurements showed server-loop p95 values around 200 ms under the free quota; the local 40-client benchmark is not a Render capacity claim. This deployment is a free test release for light use. Idle suspension can delay subsequent visits, and restarts reset in-memory arenas and guest sessions.

Automatic deploy is off for this public-repository deployment. Future source releases must replace the two release files and trigger a manual Render deployment. Preserve the single-instance setting unless room routing is implemented.

## Performance release

The verified performance update is live from commit 70e2e81285a07cd1b040f3ef1b60e727ae038db0, deploy dep-dbgootegekts738gimf0. Public loop p95 after this update was 1.96ms with three connections, with an observed 29.98Hz simulation rate. Earlier~200ms measurements above describe the original release and are superseded by this observation. See PERFORMANCE_FIX.md for method and limits.
