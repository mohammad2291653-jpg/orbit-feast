import inspired from "../../config/new-feed-6-inspired.json";
import classic from "../../config/classic.json";
import type { Rules } from "./types";
export const presets: Record<string, Rules> = {
  "new-feed-6-inspired": inspired as Rules,
  classic: classic as Rules,
};
/** Applied on startup and every authenticated live configuration update. */
export function validateRules(r: Rules) {
  for (const [key, value] of Object.entries(r))
    if (typeof value === "number" && (!Number.isFinite(value) || value < 0))
      throw new Error("Invalid rule " + key);
  const between = (
    key: keyof Rules,
    min: number,
    max: number,
    integer = false,
  ) => {
    const v = r[key];
    if (
      typeof v !== "number" ||
      v < min ||
      v > max ||
      (integer && !Number.isInteger(v))
    )
      throw new Error("Unsafe rule " + key);
  };
  between("width", 500, 30000);
  between("height", 500, 30000);
  between("tickRate", 10, 120, true);
  between("snapshotRate", 1, r.tickRate, true);
  between("maxPlayers", 1, 100, true);
  between("maxCells", 1, 64, true);
  between("foodCount", 0, 10000, true);
  between("foodMass", 0.1, 100);
  between("foodRespawnPerSecond", 0, 500);
  between("virusCount", 0, 200, true);
  between("virusMax", r.virusCount, 200, true);
  between("virusFeedCount", 1, 100, true);
  between("bots", 0, 50, true);
  between("maxMass", 5, 1000000);
  between("initialMass", 5, r.maxMass);
  between("virusMass", 1, r.maxMass);
  between("radiusScale", 0.1, 20);
  between("baseSpeed", 1, 2000);
  between("speedExponent", 0, 1);
  between("acceleration", 0.1, 100);
  between("splitMin", 10, r.maxMass);
  between("splitCooldown", 20, 60000);
  between("splitVelocity", 0, 5000);
  between("splitDecay", 0.1, 50);
  between("mergeDelay", 0, 600000);
  between("mergeMassFactor", 0, 1000);
  between("mergeSpeedMultiplier", 0.1, 20);
  between("feedInterval", 20, 60000);
  between("fastFeedInterval", 20, 60000);
  between("ejectMass", 0.1, r.maxMass);
  between("ejectCost", 1, r.maxMass);
  between("ejectMin", 5, r.maxMass);
  between("ejectDecay", 0.1, 50);
  between("ejectLifetime", 1000, 600000);
  between("maxEjectedParticles", 1, 10000, true);
  between("ejectSpeed", 0, 5000);
  between("ejectSpread", 0, Math.PI * 2);
  between("eatRatio", 1.01, 10);
  between("eatOverlap", 0, 1);
  between("zoomMin", 0.02, 2);
  between("zoomMax", r.zoomMin, 5);
  between("leaderboardInterval", 50, 10000);
  if (!["easy", "normal", "hard"].includes(r.botDifficulty))
    throw new Error("Invalid bot difficulty");
  if (!r.alternativeSelfFeed && r.ejectMass > r.ejectCost)
    throw new Error("Classic self-feed must not create mass");
  return r;
}
