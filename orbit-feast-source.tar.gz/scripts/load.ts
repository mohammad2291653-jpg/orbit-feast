import WebSocket from "ws";
import os from "node:os";
import { writeFile } from "node:fs/promises";
import { readFileSync } from "node:fs";
const cgroup = (name: string) => {
  try {
    return readFileSync("/sys/fs/cgroup/" + name, "utf8").trim();
  } catch {
    return "unavailable";
  }
};
const count = Number(process.env.CLIENTS || 40),
  duration = Number(process.env.DURATION || 20),
  base = process.env.SERVER_URL || "http://127.0.0.1:3001",
  resultPath = process.env.LOAD_RESULTS_PATH || "docs/load-results.json";
if (
  !Number.isInteger(count) ||
  count < 1 ||
  count > 50 ||
  !Number.isFinite(duration) ||
  duration < 5 ||
  duration > 600
)
  throw Error("Use CLIENTS 1–50 and DURATION 5–600 seconds");
const sockets: WebSocket[] = [];
let welcomes = 0,
  snapshots = 0,
  bytes = 0,
  errors = 0,
  disconnects = 0;
const rtts: number[] = [];
const start = Date.now();
const healthBefore = await (await fetch(base + "/health")).json();
const roomsBefore = await (await fetch(base + "/api/rooms")).json();
for (let i = 0; i < count; i++) {
  const ws = new WebSocket(base.replace(/^http/, "ws") + "/ws");
  sockets.push(ws);
  ws.on("open", () =>
    ws.send(
      JSON.stringify({
        type: "join",
        room: "feed-6",
        name: `Load ${i + 1}`,
        skin: "orbit",
      }),
    ),
  );
  ws.on("message", (raw) => {
    bytes += Buffer.byteLength(raw.toString());
    const m = JSON.parse(raw.toString());
    if (m.type === "welcome") welcomes++;
    if (m.type === "snapshot") {
      snapshots++;
      if (!m.me.alive) ws.send(JSON.stringify({ type: "respawn" }));
    }
    if (m.type === "pong") rtts.push(Date.now() - m.time);
    if (m.type === "error") errors++;
  });
  ws.on("error", () => errors++);
  ws.on("close", () => disconnects++);
  await new Promise((r) => setTimeout(r, 20));
}
let seq = 0;
const controls = setInterval(() => {
  seq++;
  sockets.forEach((ws, i) => {
    if (ws.readyState !== WebSocket.OPEN) return;
    const angle = seq * 0.03 + i * 0.6;
    ws.send(
      JSON.stringify({
        type: "input",
        x: 3000 + 1800 * Math.cos(angle),
        y: 3000 + 1800 * Math.sin(angle),
        fast: i % 3 === 0,
        feed: false,
        seq,
      }),
    );
    if (seq % 60 === 0) ws.send(JSON.stringify({ type: "split", count: 1 }));
    if (seq % 30 === 0)
      ws.send(JSON.stringify({ type: "ping", time: Date.now() }));
  });
}, 50);
await new Promise((r) => setTimeout(r, duration * 1000));
clearInterval(controls);
const elapsed = (Date.now() - start) / 1000;
const healthAfter = await (await fetch(base + "/health")).json();
const sorted = rtts.sort((a, b) => a - b);
const percentile = (p: number) =>
  sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * p))] ?? null;
const result = {
  timestamp: new Date().toISOString(),
  target: base,
  room: "feed-6",
  roomsBefore,
  environment: {
    platform: os.platform(),
    arch: os.arch(),
    cpu: os.cpus()[0]?.model,
    logicalCpus: os.cpus().length,
    totalMemoryGB: +(os.totalmem() / 1024 ** 3).toFixed(2),
    node: process.version,
    cpuQuota: cgroup("cpu.max"),
    memoryLimitBytes: cgroup("memory.max"),
  },
  clients: count,
  joined: welcomes,
  durationSeconds: +elapsed.toFixed(2),
  snapshots,
  errors,
  unexpectedDisconnects: disconnects,
  receivedMB: +(bytes / 1024 ** 2).toFixed(2),
  receivedKBPerClientSecond: +(bytes / 1024 / count / elapsed).toFixed(2),
  rttMs: {
    samples: rtts.length,
    p50: percentile(0.5),
    p95: percentile(0.95),
    max: sorted.at(-1) ?? null,
  },
  healthBefore,
  healthAfter,
};
for (const ws of sockets) ws.terminate();
await writeFile(
  resultPath,
  JSON.stringify(result, null, 2) + "\n",
);
console.log(JSON.stringify(result, null, 2));
if (result.joined !== count || result.errors || result.unexpectedDisconnects)
  process.exitCode = 1;
