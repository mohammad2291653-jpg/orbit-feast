import { afterEach, beforeEach, expect, it } from "vitest";
import type { FastifyInstance } from "fastify";
import WebSocket from "ws";
import { createApp } from "../apps/server/src/index";
import { CustomSkins, customSkinId, decodeSkin } from "../apps/server/src/custom-skins";
import { CUSTOM_SKIN_MAX_BYTES } from "../packages/shared/types";
import type { World } from "../apps/server/src/simulation";

const png = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=";
// PNG with an optional text chunk: valid raster dimensions, distinct content hash.
function variant(index: number) {
  const bytes = Buffer.from(png.split(",")[1], "base64"), text = Buffer.from("Note\0" + index);
  const chunk = Buffer.alloc(12 + text.length);
  chunk.writeUInt32BE(text.length); chunk.write("tEXt", 4); text.copy(chunk, 8);
  let crc = 0xffffffff;
  for (const byte of chunk.subarray(4, 8 + text.length)) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  chunk.writeUInt32BE((crc ^ 0xffffffff) >>> 0, 8 + text.length);
  return "data:image/png;base64," + Buffer.concat([bytes.subarray(0, bytes.length - 12), chunk, bytes.subarray(-12)]).toString("base64");
}
let app: FastifyInstance;
const sockets: WebSocket[] = [];
beforeEach(async () => { app = await createApp({ test: true, bots: 0 }); });
afterEach(async () => { sockets.splice(0).forEach((ws) => ws.terminate()); await app.close(); });
const upload = (image = png, headers?: Record<string, string>) => app.inject({ method: "POST", url: "/api/skins", payload: { image }, headers });

it("stores a bounded raster under an opaque reference and serves safe image bytes", async () => {
  const response = await upload();
  expect(response.statusCode).toBe(200);
  const { skin } = response.json();
  expect(skin).toMatch(/^custom:[a-f0-9]{32}$/);
  const image = await app.inject("/api/skins/" + customSkinId(skin));
  expect(image.statusCode).toBe(200);
  expect(image.headers["content-type"]).toBe("image/png");
  expect(image.headers["x-content-type-options"]).toBe("nosniff");
  expect(image.headers["content-security-policy"]).toContain("sandbox");
  expect(image.rawPayload).toEqual(Buffer.from(png.split(",")[1], "base64"));
  expect((await upload()).json().skin).toBe(skin);
  expect((await app.inject("/api/skins/unknown")).statusCode).toBe(404);
});
it("rejects SVG, remote URLs, forged raster headers, huge dimensions and oversized bodies", async () => {
  for (const image of ["data:image/svg+xml;base64,PHN2Zy8+", "https://example.com/photo.png", "data:image/png;base64,YWJjZA=="])
    expect((await upload(image)).statusCode).toBe(400);
  const oversizedDimensions = Buffer.from(png.split(",")[1], "base64");
  oversizedDimensions.writeUInt32BE(100000, 16);
  expect((await upload("data:image/png;base64," + oversizedDimensions.toString("base64"))).statusCode).toBe(400);
  expect((await upload("data:image/png;base64," + Buffer.alloc(CUSTOM_SKIN_MAX_BYTES + 2000).toString("base64"))).statusCode).toBe(413);
  expect((await upload(png, { origin: "https://untrusted.example" })).statusCode).toBe(403);
});
it("limits new photos globally while deduplicated reconnect uploads do not consume the budget", async () => {
  const original = (await upload()).json().skin;
  for (let n = 1; n <= 59; n++) expect((await upload(variant(n))).statusCode).toBe(200);
  expect((await upload(variant(60))).statusCode).toBe(429);
  expect((await upload()).json().skin).toBe(original);
});
it("pins active photos, expires unreferenced photos, and enforces a fixed storage cap", () => {
  const store = new CustomSkins(1, 100), first = store.put(png, 0);
  store.retain(first);
  expect(() => store.put(variant(1), Date.now())).toThrow("busy");
  store.cleanup(Date.now() + 1_000_000);
  expect(store.has(first)).toBe(true);
  store.release(first);
  store.cleanup(Date.now() + 101);
  expect(store.has(first)).toBe(false);
  expect(decodeSkin(png).mime).toBe("image/png");
});
function next(ws: WebSocket, type: string, predicate: (message: any) => boolean = () => true): Promise<any> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { ws.off("message", handler); reject(Error("Missing " + type)); }, 3000);
    const handler = (raw: WebSocket.RawData) => {
      const message = JSON.parse(raw.toString());
      if (message.type === type && predicate(message)) { clearTimeout(timer); ws.off("message", handler); resolve(message); }
    };
    ws.on("message", handler);
  });
}
it("shares photo references over real WebSockets and preserves them across reconnect and respawn", async () => {
  const skin = (await upload()).json().skin;
  await app.listen({ host: "127.0.0.1", port: 0 });
  const { port } = app.server.address() as { port: number };
  async function join(token?: string, selected = skin) {
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`); sockets.push(ws);
    const entities = new Map<string, any>();
    ws.on("message", (raw) => {
      const message = JSON.parse(raw.toString());
      if (message.type !== "snapshot") return;
      if (message.full) entities.clear();
      for (const id of message.removed) entities.delete(id);
      for (const entity of message.entities) entities.set(entity.id, { ...entities.get(entity.id), ...entity });
    });
    await new Promise<void>((resolve, reject) => { ws.once("open", resolve); ws.once("error", reject); });
    const welcome = next(ws, "welcome"), snapshot = next(ws, "snapshot");
    ws.send(JSON.stringify({ type: "join", room: "feed-6", name: "Photo player", skin: selected, token }));
    return { ws, entities, welcome: await welcome, snapshot: await snapshot };
  }
  const first = await join();
  expect(first.snapshot.entities.some((e: any) => e.owner === first.welcome.id && e.skin === skin)).toBe(true);
  expect(JSON.stringify(first.snapshot)).not.toContain("data:image");
  const observer = await join(undefined, "solar");
  const world = (app as any).testWorlds.get("feed-6") as World;
  const originalCell = world.entities.get(world.players.get(first.welcome.id)!.cells[0])!;
  const observerCell = world.entities.get(world.players.get(observer.welcome.id)!.cells[0])!;
  originalCell.x = observerCell.x = 3000;
  originalCell.y = 3000; observerCell.y = 3200;
  await next(observer.ws, "snapshot");
  expect(observer.entities.get(originalCell.id)?.skin).toBe(skin);
  const beforeCells = [...world.players.get(first.welcome.id)!.cells];
  const alternative = (await upload(variant(999))).json().skin;
  const observerUpdate = next(observer.ws, "snapshot", (message) => message.entities.some((e: any) => e.owner === first.welcome.id && e.skin === alternative));
  const resumed = await join(first.welcome.token, alternative);
  expect(resumed.welcome.id).toBe(first.welcome.id);
  const player = world.players.get(resumed.welcome.id)!;
  expect(player.cells).toEqual(beforeCells);
  expect(player.skin).toBe(alternative);
  expect(resumed.snapshot.entities.some((e: any) => e.owner === player.id && e.skin === alternative)).toBe(true);
  const changedPhoto = await observerUpdate;
  expect(changedPhoto.entities.some((e: any) => e.owner === player.id && e.skin === alternative)).toBe(true);
  for (const id of player.cells) world.entities.delete(id);
  player.cells = [];
  const respawned = next(resumed.ws, "snapshot");
  resumed.ws.send(JSON.stringify({ type: "respawn" }));
  await respawned;
  expect(player.cells.length).toBe(1);
  expect(world.entities.get(player.cells[0])!.skin).toBe(alternative);
  const unknown = await join(undefined, "custom:" + "f".repeat(32));
  expect(unknown.snapshot.entities.some((e: any) => e.owner === unknown.welcome.id && e.skin === "orbit")).toBe(true);
});
