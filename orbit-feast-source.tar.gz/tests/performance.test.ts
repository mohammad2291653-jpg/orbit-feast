import {afterEach,beforeEach,expect,it} from 'vitest';
import WebSocket from 'ws';
import {createApp} from '../apps/server/src/index';
import type {FastifyInstance} from 'fastify';
import type {World} from '../apps/server/src/simulation';
let app:FastifyInstance;let ws:WebSocket|undefined;let world:World;let classic:World;let port:number;
const pause=(ms:number)=>new Promise(r=>setTimeout(r,ms));
beforeEach(async()=>{app=await createApp({test:true,bots:0});await app.listen({host:'127.0.0.1',port:0});port=(app.server.address() as {port:number}).port;world=(app as any).testWorlds.get('feed-6');classic=(app as any).testWorlds.get('classic');});
afterEach(async()=>{ws?.terminate();ws=undefined;await app.close();});
async function join(){ws=new WebSocket(`ws://127.0.0.1:${port}/ws`);await new Promise<void>((resolve,reject)=>{ws!.once('open',()=>ws!.send(JSON.stringify({type:'join',room:'feed-6',name:'Performance test',skin:'orbit'})));ws!.on('message',raw=>{const m=JSON.parse(raw.toString());if(m.type==='snapshot')resolve();});ws!.once('error',reject);});}
it('pauses empty arenas and resumes one arena without simulating its idle backlog',async()=>{await pause(180);expect(world.tick).toBe(0);expect(classic.tick).toBe(0);await join();expect(world.tick).toBeGreaterThan(0);expect(classic.tick).toBe(0);await pause(120);expect(world.tick).toBeLessThan(12);ws!.terminate();await pause(60);const stopped=world.tick;await pause(160);expect(world.tick).toBe(stopped);});
it('reuses stationary entity wire data across snapshots instead of serializing the arena again',async()=>{world.rules.foodRespawnPerSecond=0;for(let n=0;n<1000;n++)world.entities.set('static-food-'+n,{id:'static-food-'+n,kind:'food',x:10+(n%50)*8,y:10+Math.floor(n/50)*8,mass:1,vx:0,vy:0,color:'#80dfbf',born:0});await join();const first=(await app.inject('/health')).json();expect(first.packedEntityUpdates).toBeGreaterThan(900);await pause(220);const after=(await app.inject('/health')).json();expect(after.roomTicks.find((r:any)=>r.id==='feed-6').tick).toBeGreaterThan(first.roomTicks.find((r:any)=>r.id==='feed-6').tick);expect(after.packedEntityUpdates-first.packedEntityUpdates).toBeLessThan(25);expect(classic.tick).toBe(0);});
