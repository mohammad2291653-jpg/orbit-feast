import { describe, expect, it } from "vitest";
import { World, SpatialHash } from "../apps/server/src/simulation";
import { presets } from "../packages/shared/config";
import { radius, type Entity, type Rules } from "../packages/shared/types";

function arena(overrides: Partial<Rules> = {}) {
  return new World({
    ...presets["new-feed-6-inspired"],
    foodCount: 0,
    virusCount: 0,
    bots: 0,
    decay: 0,
    protection: 0,
    foodRespawnPerSecond: 0,
    // Legacy mechanics below deliberately exercise the non-amplifying mode.
    alternativeSelfFeed: false,
    ejectMass: 12,
    ejectCost: 14,
    virusMax: 36,
    mergeSpeedMultiplier: 1,
    ...overrides,
  });
}
function player(w: World, id = "p", mass = 200, x = 1000, y = 1000) {
  const p = w.addPlayer(id, id, "orbit");
  const c = w.entities.get(p.cells[0])!;
  Object.assign(c, { mass, x, y });
  p.input.x = x;
  p.input.y = y;
  return { p, c };
}
function entity(
  w: World,
  kind: Entity["kind"],
  mass: number,
  x: number,
  y: number,
  id = "test",
): Entity {
  const e: Entity = {
    id,
    kind,
    mass,
    x,
    y,
    vx: 0,
    vy: 0,
    color: "#fff",
    born: w.now,
  };
  w.entities.set(id, e);
  return e;
}
function advance(w: World, seconds: number) {
  for (let i = 0; i < Math.round(seconds * 30); i++) w.step(1 / 30);
}

describe("authoritative movement and contact", () => {
  it("uses square-root area scaling", () =>
    expect(radius(400) / radius(100)).toBe(2));
  it("moves smaller cells faster with smooth acceleration", () => {
    const w = arena();
    const a = player(w, "a", 40, 1000, 1000),
      b = player(w, "b", 400, 1000, 2500);
    w.setInput("a", { x: 5000, y: 1000, seq: 1, feed: false, fast: false });
    w.setInput("b", { x: 5000, y: 2500, seq: 1, feed: false, fast: false });
    w.step(1 / 30);
    expect(a.c.vx).toBeGreaterThan(0);
    expect(a.c.vx).toBeLessThan(300);
    advance(w, 1);
    expect(a.c.x - 1000).toBeGreaterThan(b.c.x - 1000);
  });
  it("rejects non-finite and stale target inputs", () => {
    const w = arena();
    const { p } = player(w);
    w.setInput("p", { x: 1500, y: 1500, seq: 2, feed: false, fast: false });
    w.setInput("p", { x: NaN, y: 1, seq: 3, feed: true, fast: true });
    w.setInput("p", { x: 2000, y: 2000, seq: 1, feed: true, fast: true });
    expect(p.input.x).toBe(1500);
    expect(p.input.seq).toBe(2);
  });
  it("clamps cells and impulses inside map boundaries", () => {
    const w = arena();
    const { c } = player(w, "p", 200, 5990, 5990);
    w.setInput("p", { x: 1e9, y: 1e9, seq: 1, fast: false, feed: false });
    w.split("p");
    advance(w, 2);
    for (const e of w.entities.values()) {
      const r = radius(e.mass, w.rules.radiusScale);
      expect(e.x).toBeLessThanOrEqual(w.rules.width - r + 0.001);
      expect(e.y).toBeLessThanOrEqual(w.rules.height - r + 0.001);
    }
    expect(c.x).toBeGreaterThan(0);
  });
  it("requires size advantage and physical overlap for eating", () => {
    const w = arena();
    const a = player(w, "a", 200),
      b = player(w, "b", 180, 1002, 1000);
    w.step(0);
    expect(w.mass("b")).toBe(180);
    a.c.mass = 300;
    b.c.x = 1200;
    w.step(0);
    expect(w.mass("b")).toBe(180);
    b.c.x = 1010;
    w.step(0);
    expect(w.mass("b")).toBe(0);
    expect(w.mass("a")).toBe(480);
    expect(a.p.kills).toBe(1);
  });
  it("respects spawn protection and permits respawn after death", () => {
    const w = arena({ protection: 1000 });
    const a = player(w, "a", 1000),
      b = player(w, "b", 100, 1010);
    w.step(0);
    expect(b.p.cells).toHaveLength(1);
    w.now = 1001;
    w.step(0);
    expect(b.p.cells).toHaveLength(0);
    expect(b.p.deadAt).toBe(1001);
    w.spawn(b.p);
    expect(b.p.cells).toHaveLength(1);
    expect(w.mass("b")).toBe(w.rules.initialMass);
  });
  it("adds consumed food mass and respawns food at the configured rate", () => {
    const w = arena({ foodCount: 2, foodRespawnPerSecond: 30 });
    w.entities.clear();
    const { c } = player(w);
    entity(w, "food", 3, c.x, c.y);
    w.step(1 / 30);
    expect(c.mass).toBe(203);
    expect(
      [...w.entities.values()].filter((e) => e.kind === "food"),
    ).toHaveLength(1);
  });
  it("spatial hash finds a large cell spanning distant buckets", () => {
    const hash = new SpatialHash(4);
    const w = arena();
    const e = entity(w, "cell", 10000, 500, 500);
    hash.rebuild([e]);
    expect(hash.query(890, 500, 10).has(e)).toBe(true);
  });
});

describe("split, merge and feed conservation", () => {
  it("splits mass evenly and launches toward the target without teleporting", () => {
    const w = arena();
    const { p, c } = player(w);
    p.input.x = 2000;
    w.split("p");
    expect(p.cells).toHaveLength(2);
    expect(w.mass("p")).toBe(200);
    const child = w.entities.get(p.cells[1])!;
    expect(child.mass).toBe(100);
    expect(child.x - c.x).toBeLessThan(100);
    const before = child.x;
    w.step(1 / 30);
    expect(child.x).toBeGreaterThan(before + 10);
    expect(child.y).toBeCloseTo(1000);
  });
  it("enforces minimum split mass, command cooldown, and maximum cells", () => {
    const w = arena({ maxCells: 4 });
    const { p } = player(w, "p", 1600);
    p.input.x = 2000;
    w.split("p", 3);
    expect(p.cells).toHaveLength(4);
    expect(w.mass("p")).toBe(1600);
    w.split("p", 3);
    expect(p.cells).toHaveLength(4);
    const small = player(w, "s", 20, 3000);
    w.split("s");
    expect(small.p.cells).toHaveLength(1);
  });
  it("does not merge before both timers, then conserves mass on contact", () => {
    const w = arena({ mergeDelay: 1000, mergeMassFactor: 0 });
    const { p, c } = player(w);
    w.split("p");
    const child = w.entities.get(p.cells[1])!;
    child.x = c.x;
    child.y = c.y;
    w.step(0);
    expect(p.cells).toHaveLength(2);
    w.now = 999;
    child.x = c.x;
    w.step(0);
    expect(p.cells).toHaveLength(2);
    w.now = 1000;
    child.x = c.x;
    child.y = c.y;
    w.step(0);
    expect(p.cells).toHaveLength(1);
    expect(w.mass("p")).toBe(200);
  });
  it("resets merge eligibility on rapid consecutive splits", () => {
    const w = arena({ mergeDelay: 1000, mergeMassFactor: 0 });
    const { p } = player(w, "p", 800);
    w.split("p");
    w.now = 200;
    w.split("p");
    expect(p.cells).toHaveLength(4);
    for (const id of p.cells) expect(w.entities.get(id)!.mergeAt).toBe(1200);
  });
  it("deducts exact ejection cost and adds a directional moving particle", () => {
    const w = arena();
    const { p, c } = player(w);
    p.input.x = 2000;
    w.eject("p");
    expect(c.mass).toBe(200 - w.rules.ejectCost);
    const pellet = [...w.entities.values()].find((e) => e.kind === "eject")!;
    expect(pellet.mass).toBe(w.rules.ejectMass);
    expect(pellet.vx).toBeGreaterThan(600);
    expect(pellet.x).toBeGreaterThan(c.x);
    const v = pellet.vx;
    w.step(1 / 30);
    expect(pellet.vx).toBeLessThan(v);
  });
  it("enforces one shared normal/fast feed gate and stops immediately on release", () => {
    const w = arena();
    const { p } = player(w, "p", 1000);
    p.input.x = 2000;
    w.eject("p");
    w.eject("p", true);
    expect(w.mass("p")).toBe(986);
    p.input.fast = true;
    advance(w, 0.3);
    const mass = w.mass("p");
    expect(mass).toBeLessThan(986);
    p.input.fast = false;
    advance(w, 0.3);
    expect(w.mass("p")).toBe(mass);
  });
  it("classic self-feed transfers mass without creating it", () => {
    const w = arena({ selfFeedDelay: 300 });
    const a = player(w, "p", 200);
    a.p.input.x = 2000;
    w.split("p");
    const b = w.entities.get(a.p.cells[1])!;
    a.c.x = 1000;
    b.x = 1600;
    a.p.input.x = 2000;
    const original = w.mass("p");
    w.eject("p");
    const pellets = [...w.entities.values()].filter((e) => e.kind === "eject");
    for (const pellet of pellets) {
      pellet.x = b.x;
      pellet.y = b.y;
      pellet.vx = 0;
      pellet.vy = 0;
    }
    w.step(0);
    expect(w.mass("p")).toBe(
      original - 2 * w.rules.ejectCost + w.rules.ejectMass,
    );
    w.now = 301;
    w.step(0);
    expect(w.mass("p")).toBe(
      original - 2 * (w.rules.ejectCost - w.rules.ejectMass),
    );
    expect(w.mass("p")).toBeLessThanOrEqual(original);
  });
  it("disabled self-feed prevents same-owner consumption", () => {
    const w = arena({ selfFeed: false, selfFeedDelay: 0 });
    const { c } = player(w);
    const e = entity(w, "eject", 12, c.x, c.y);
    e.source = "p";
    w.step(0);
    expect(w.entities.has(e.id)).toBe(true);
    expect(w.mass("p")).toBe(200);
  });
  it("rejects positive mass classic rule configurations", () =>
    expect(() => arena({ ejectMass: 20, ejectCost: 14 })).toThrow(
      /create mass/,
    ));
});

describe("viruses and deterministic battles", () => {
  it("bursts a large cell, adds virus mass and respects max cells", () => {
    const w = arena({ maxCells: 8 });
    const { p, c } = player(w, "p", 400);
    entity(w, "virus", 100, c.x, c.y);
    w.step(0);
    expect(p.cells).toHaveLength(8);
    expect(w.mass("p")).toBeCloseTo(500);
    expect(
      [...w.entities.values()].filter((e) => e.kind === "virus"),
    ).toHaveLength(0);
  });
  it("lets small cells overlap a virus safely", () => {
    const w = arena();
    const { p, c } = player(w, "p", 70);
    entity(w, "virus", 100, c.x, c.y);
    w.step(0);
    expect(p.cells).toHaveLength(1);
    expect(w.mass("p")).toBe(70);
  });
  it("feeds and launches a virus after the configured count", () => {
    const w = arena({ virusFeedCount: 2 });
    const v = entity(w, "virus", 100, 2000, 2000, "v");
    for (let i = 0; i < 2; i++) {
      const p = entity(w, "eject", 12, 2000, 2000, "p" + i);
      p.vx = 500;
    }
    w.step(0);
    const viruses = [...w.entities.values()].filter((e) => e.kind === "virus");
    expect(viruses).toHaveLength(2);
    expect(v.mass).toBe(100);
    expect(viruses.reduce((sum, e) => sum + e.mass, 0)).toBe(124);
    expect(viruses.some((e) => e.id !== "v" && e.vx > 0)).toBe(true);
  });
  it("allows virus consumption at the cell limit without extra pieces", () => {
    const w = arena({ maxCells: 1 });
    const { p, c } = player(w, "p", 400);
    entity(w, "virus", 100, c.x, c.y);
    w.step(0);
    expect(p.cells).toHaveLength(1);
    expect(c.mass).toBe(500);
  });
  it("resolves simultaneous predators deterministically and updates rankings", () => {
    const w = arena();
    player(w, "a", 500);
    player(w, "b", 500);
    player(w, "c", 100);
    w.step(0);
    expect(w.mass("a")).toBe(600);
    expect(w.mass("b")).toBe(500);
    expect(w.mass("c")).toBe(0);
    expect(w.leaderboard()[0].id).toBe("a");
  });
  it("creates independent bot movement without counting bots as humans", () => {
    const w = arena({ foodCount: 30 });
    w.addPlayer("bot", "Scout", "mint", true);
    const p = w.players.get("bot")!,
      c = w.entities.get(p.cells[0])!,
      x = c.x,
      y = c.y;
    advance(w, 2);
    expect(Math.hypot(c.x - x, c.y - y)).toBeGreaterThan(1);
    expect(w.leaderboard()[0].bot).toBe(true);
  });
});

describe("live administration and entity lifecycle", () => {
  it("expires ejected particles at the configured simulation lifetime", () => {
    const w = arena({ ejectLifetime: 1000 });
    const { p } = player(w);
    p.input.x = 2000;
    w.eject("p");
    const pellet = [...w.entities.values()].find((e) => e.kind === "eject")!;
    expect(w.entities.has(pellet.id)).toBe(true);
    w.now = 999;
    w.step(0);
    expect(w.entities.has(pellet.id)).toBe(true);
    w.now = 1000;
    w.step(0);
    expect(w.entities.has(pellet.id)).toBe(false);
  });
  it("restarts lives without leaking cells, impulses, pellets, or player identities", () => {
    const w = arena();
    const a = player(w, "a", 800),
      b = player(w, "b", 500, 3000, 3000);
    a.p.input.x = 2000;
    w.split("a", 2);
    w.eject("a");
    const oldIds = [...w.entities.keys()];
    a.p.input.fast = true;
    a.p.kills = 5;
    a.p.peak = 900;
    w.restart();
    expect(w.players.size).toBe(2);
    expect(w.entities.size).toBe(2);
    expect(a.p.cells).toHaveLength(1);
    expect(b.p.cells).toHaveLength(1);
    for (const id of oldIds) expect(w.entities.has(id)).toBe(false);
    expect(w.mass("a")).toBe(w.rules.initialMass);
    expect(a.p.kills).toBe(0);
    expect(a.p.input.fast).toBe(false);
    const c = w.entities.get(a.p.cells[0])!,
      x = c.x,
      y = c.y;
    advance(w, 0.5);
    expect(c.x).toBeCloseTo(x);
    expect(c.y).toBeCloseTo(y);
    w.restart();
    expect(w.entities.size).toBe(2);
    expect(w.players.size).toBe(2);
  });
  it("validates rule updates atomically and respects changed map, scale and caps", () => {
    const w = arena();
    const { c } = player(w, "a", 1000, 5000, 5000);
    const before = w.rules.ejectCost;
    expect(() => w.updateRules({ ...w.rules, ejectCost: 1 })).toThrow(
      /create mass/,
    );
    expect(w.rules.ejectCost).toBe(before);
    w.updateRules({
      ...w.rules,
      width: 1000,
      height: 1000,
      radiusScale: 6,
      maxMass: 500,
    });
    expect(c.mass).toBe(500);
    expect(c.x).toBeLessThanOrEqual(1000 - radius(500, 6));
    entity(w, "food", 1, c.x, c.y);
    w.step(0);
    expect(c.mass).toBe(500);
  });
});

describe("stationary food indexing", () => {
  it("consumes replaced food at its new position and never consumes deleted ghosts", () => {
    const w = arena();
    const { c } = player(w);
    const food = entity(w, "food", 3, 4500, 4500, "relocated-food");
    w.step(0);
    expect(c.mass).toBe(200);
    w.entities.set(food.id, { ...food, x: c.x, y: c.y });
    w.step(0);
    expect(c.mass).toBe(203);
    expect(w.entities.has(food.id)).toBe(false);
    entity(w, "food", 10, c.x, c.y, "deleted-food");
    w.entities.delete("deleted-food");
    w.step(0);
    expect(c.mass).toBe(203);
  });

  it("keeps idle respawn counts correct after public Map delete and clear", () => {
    const w = arena({ foodCount: 20, virusCount: 2, foodRespawnPerSecond: 30 });
    const food = [...w.entities.values()].filter((e) => e.kind === "food");
    for (const e of food.slice(0, 5)) w.entities.delete(e.id);
    w.step(1 / 30);
    expect(
      [...w.entities.values()].filter((e) => e.kind === "food"),
    ).toHaveLength(16);
    w.entities.clear();
    w.step(1 / 30);
    expect(
      [...w.entities.values()].filter((e) => e.kind === "food"),
    ).toHaveLength(1);
    expect(
      [...w.entities.values()].filter((e) => e.kind === "virus"),
    ).toHaveLength(2);
  });

  it("reindexes stationary food after arena and radius-rule changes", () => {
    const w = arena({ foodCount: 1 });
    w.entities.clear();
    const { c } = player(w, "p", 200, 5000, 500);
    entity(w, "food", 1, 5000, 500, "food-at-old-boundary");
    w.updateRules({ ...w.rules, width: 1000, height: 1000, radiusScale: 6 });
    w.step(0);
    expect(c.mass).toBe(201);
    expect(w.entities.has("food-at-old-boundary")).toBe(false);
  });
});

describe("requested custom arena rules", () => {
  for (const preset of Object.values(presets)) {
    it(`${preset.id}: never spawns ambient food or viruses and preserves idle mass`, () => {
      const w = new World({ ...preset, bots: 0 });
      const { c } = player(w, "p", 2500);
      expect(w.rules.foodCount).toBe(0);
      expect(w.rules.foodRespawnPerSecond).toBe(0);
      expect(w.rules.virusCount).toBe(0);
      expect(w.rules.virusMax).toBe(0);
      advance(w, 60);
      expect([...w.entities.values()].map((e) => e.kind)).toEqual(["cell"]);
      expect(c.mass).toBe(2500);
      expect(w.mass("p")).toBe(2500);
    });

    it(`${preset.id}: source reabsorption returns exactly 1.5 times the deducted mass`, () => {
      const w = new World({ ...preset, bots: 0 });
      const { p, c } = player(w);
      p.input.x = 2000;
      const original = c.mass;
      w.eject("p");
      const particle = [...w.entities.values()].find((e) => e.kind === "eject")!;
      expect(w.rules.alternativeSelfFeed).toBe(true);
      expect(particle.mass).toBe(w.rules.ejectCost * 1.5);
      expect(c.mass).toBe(original - w.rules.ejectCost);
      Object.assign(particle, { x: c.x, y: c.y, vx: 0, vy: 0 });
      w.step(0);
      expect(w.entities.has(particle.id)).toBe(true);
      w.now = w.rules.selfFeedDelay;
      w.step(0);
      expect(w.entities.has(particle.id)).toBe(false);
      expect(c.mass).toBe(original + w.rules.ejectCost * 0.5);
    });

    it(`${preset.id}: sibling cells immediately consume amplified feed without duplication`, () => {
      const w = new World({ ...preset, bots: 0 });
      const { p, c } = player(w);
      p.input.x = 2000;
      w.split("p");
      const sibling = w.entities.get(p.cells[1])!;
      sibling.x = 1300;
      const original = w.mass("p");
      w.eject("p");
      const particles = [...w.entities.values()].filter((e) => e.kind === "eject");
      expect(particles).toHaveLength(2);
      Object.assign(particles[0], { x: sibling.x, y: sibling.y, vx: 0, vy: 0 });
      Object.assign(particles[1], { x: c.x, y: c.y, vx: 0, vy: 0 });
      w.step(0);
      expect(particles.every((e) => !w.entities.has(e.id))).toBe(true);
      expect(w.mass("p")).toBe(original + 2 * w.rules.ejectCost * 0.5);
      const after = w.mass("p");
      w.step(0);
      expect(w.mass("p")).toBe(after);
    });

    it(`${preset.id}: amplified feed still respects the authoritative cell mass cap`, () => {
      const w = new World({ ...preset, bots: 0 });
      const { p, c } = player(w, "p", preset.maxMass - 1, 2500, 2500);
      p.input.x = 4000;
      w.eject("p");
      const particle = [...w.entities.values()].find((e) => e.kind === "eject")!;
      Object.assign(particle, { x: c.x, y: c.y, vx: 0, vy: 0 });
      w.now = w.rules.selfFeedDelay;
      w.step(0);
      expect(c.mass).toBe(preset.maxMass);
      expect(w.entities.has(particle.id)).toBe(false);
    });

    it(`${preset.id}: the full merge delay formula is four times faster`, () => {
      const w = new World({ ...preset, bots: 0 });
      const { p, c } = player(w);
      w.split("p");
      const sibling = w.entities.get(p.cells[1])!;
      const originalDelay = preset.id === "classic" ? 30000 : 8000;
      const originalMassFactor = preset.id === "classic" ? 15 : 5;
      expect(c.mergeAt).toBe((originalDelay + originalMassFactor * 100) / 4);
      expect(sibling.mergeAt).toBe(c.mergeAt);
      sibling.x = c.x;
      sibling.y = c.y;
      w.now = c.mergeAt! - 0.001;
      w.step(0);
      expect(p.cells).toHaveLength(2);
      Object.assign(sibling, { x: c.x, y: c.y });
      w.now = c.mergeAt!;
      w.step(0);
      expect(p.cells).toHaveLength(1);
      expect(w.mass("p")).toBe(200);
    });
  }

  it("quadruples the eligible nearby sibling convergence rate while preserving center and mass", () => {
    const setup = (mergeSpeedMultiplier: number) => {
      const w = arena({
        mergeSpeedMultiplier,
        mergeDelay: 0,
        mergeMassFactor: 0,
        splitVelocity: 0,
      });
      const { p, c } = player(w);
      w.split("p");
      const sibling = w.entities.get(p.cells[1])!;
      c.x = 1000;
      sibling.x = 1100;
      c.y = sibling.y = 1000;
      p.input.x = 1050;
      p.input.y = 1000;
      // Set the movement velocity at its target, isolating merge convergence.
      w.rules.baseSpeed = 1;
      return { w, p, c, sibling };
    };
    const normal = setup(1), fast = setup(4);
    normal.w.step(1 / 120);
    fast.w.step(1 / 120);
    const normalDistance = Math.abs(normal.sibling.x - normal.c.x);
    const fastDistance = Math.abs(fast.sibling.x - fast.c.x);
    expect(fastDistance).toBeLessThan(normalDistance);
    // After removing the common movement, the exponential convergence rates
    // are exactly 6/sec and 24/sec, rather than a frame-dependent position jump.
    const normalToGoal = normalDistance - 64;
    const fastToGoal = fastDistance - 64;
    expect(fastToGoal / normalToGoal).toBeCloseTo(Math.exp(-18 / 120), 5);
    expect((fast.c.x + fast.sibling.x) / 2).toBeCloseTo(1050);
    expect(fast.w.mass("p")).toBe(200);
  });

  it("keeps held fast-feed responsive at the particle budget by retiring the oldest particles", () => {
    const w = new World({ ...presets["new-feed-6-inspired"], maxEjectedParticles: 2 });
    const { p } = player(w);
    p.input.x = 2000;
    p.input.fast = true;
    const emitted = new Set<string>();
    for (let i = 0; i < 7; i++) {
      w.step(1 / 30);
      const particles = [...w.entities.values()].filter((e) => e.kind === "eject");
      expect(particles.length).toBeLessThanOrEqual(2);
      for (const particle of particles) {
        emitted.add(particle.id);
        expect(particle.mass).toBe(w.rules.ejectCost * 1.5);
      }
    }
    const emittedIds = [...emitted];
    expect(emittedIds).toHaveLength(4);
    const remaining = [...w.entities.values()].filter((e) => e.kind === "eject");
    expect(remaining.map((e) => e.id)).toEqual(emittedIds.slice(-2));
    expect(w.entities.has(emittedIds[0])).toBe(false);
    expect(w.mass("p")).toBe(200 - 4 * w.rules.ejectCost);
    expect(remaining.reduce((sum, e) => sum + e.mass, 0)).toBe(2 * w.rules.ejectMass);
  });

  it("trims the oldest loose particles when an authenticated rules update lowers their budget", () => {
    const w = arena({ maxEjectedParticles: 5 });
    for (let i = 0; i < 5; i++)
      entity(w, "eject", 12, 3000 + i * 100, 3000, "loose-" + i);
    w.updateRules({ ...w.rules, maxEjectedParticles: 2 });
    expect([...w.entities.keys()]).toEqual(["loose-3", "loose-4"]);
    expect(() => w.updateRules({ ...w.rules, maxEjectedParticles: 0 })).toThrow(/Unsafe rule/);
    expect(() => w.updateRules({ ...w.rules, maxEjectedParticles: 1.5 })).toThrow(/Unsafe rule/);
    expect(() => w.updateRules({ ...w.rules, maxEjectedParticles: 10001 })).toThrow(/Unsafe rule/);
    expect(w.rules.maxEjectedParticles).toBe(2);
    expect([...w.entities.keys()]).toEqual(["loose-3", "loose-4"]);
  });
});
