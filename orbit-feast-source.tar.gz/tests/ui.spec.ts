import { expect, test } from "@playwright/test";

test("menu, real joining, independent browser identities and synchronized chat", async ({
  browser,
}) => {
  const a = await browser.newContext(),
    b = await browser.newContext();
  const first = await a.newPage(),
    second = await b.newPage();
  await Promise.all([first.goto("/"), second.goto("/")]);
  for (const [page, name] of [
    [first, "Browser Alpha"],
    [second, "Browser Beta"],
  ] as const) {
    await expect(page.getByTestId("server-feed-6")).toBeVisible();
    await page.getByTestId("nickname").fill(name);
    await page.getByTestId("play").click();
    await expect(page.getByTestId("player-stats")).toHaveAttribute(
      "data-player-id",
      /.+/,
    );
    await expect(page.getByText("Connected", { exact: true })).toBeVisible();
  }
  const firstId = await first
    .getByTestId("player-stats")
    .getAttribute("data-player-id");
  const secondId = await second
    .getByTestId("player-stats")
    .getAttribute("data-player-id");
  expect(firstId).not.toBe(secondId);
  await expect(first.getByTestId("arena")).toBeVisible();
  await first.keyboard.press("Enter");
  await expect(first.getByTestId("chat-input")).toBeFocused();
  await first.getByTestId("chat-input").fill("Hello from browser alpha");
  await first.keyboard.press("Enter");
  await expect(
    second.getByText("Hello from browser alpha", { exact: true }),
  ).toBeVisible();
  await a.close();
  await b.close();
});

test("Space, W and held F send distinct intended actions and stop on release", async ({
  page,
}) => {
  const frames: any[] = [];
  page.on("websocket", (ws) =>
    ws.on("framesent", (frame) => {
      try {
        frames.push(JSON.parse(String(frame.payload)));
      } catch {}
    }),
  );
  await page.goto("/");
  await page.getByTestId("nickname").fill("Keyboard test");
  await page.getByTestId("play").click();
  await expect(page.getByText("Connected", { exact: true })).toBeVisible();
  await page.mouse.move(1000, 400);
  await page.keyboard.press("Space");
  await expect
    .poll(() => frames.some((m) => m.type === "split" && m.count === 1))
    .toBeTruthy();
  await page.keyboard.down("KeyW");
  await expect
    .poll(() => frames.some((m) => m.type === "input" && m.feed))
    .toBeTruthy();
  await page.keyboard.up("KeyW");
  await page.keyboard.down("KeyF");
  await expect
    .poll(() => frames.filter((m) => m.type === "input" && m.fast).length)
    .toBeGreaterThan(2);
  await page.keyboard.up("KeyF");
  await expect
    .poll(() => frames.filter((m) => m.type === "input").at(-1)?.fast)
    .toBe(false);
  await page.keyboard.press("Enter");
  await page.getByTestId("chat-input").fill("F W Space");
  const splitCount = frames.filter((m) => m.type === "split").length;
  await page.keyboard.press("Space");
  expect(frames.filter((m) => m.type === "split").length).toBe(splitCount);
  await page.keyboard.press("Escape");
});

test("settings persist, Arabic sets RTL, and server selection changes mode", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Settings", exact: true })
    .first()
    .click();
  const dialog = page.getByRole("dialog", { name: "Settings" });
  await expect(dialog).toBeVisible();
  await page.locator("#language-setting").selectOption("ar");
  await expect(page.locator("html")).toHaveAttribute("dir", "rtl");
  await expect(
    dialog.getByText("أسماء اللاعبين", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Close dialog" }).click();
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("lang", "ar");
  await page.getByTestId("server-classic").click();
  await expect(page.getByTestId("server-classic")).toHaveAttribute(
    "aria-pressed",
    "true",
  );
  await page.getByTestId("nickname").fill("لاعب عربي");
  await page.getByTestId("play").click();
  await expect(page.getByTestId("player-stats")).toHaveAttribute(
    "data-player-id",
    /.+/,
  );
  await expect(page.getByTestId("player-stats")).toContainText("لاعب عربي");
});

test("mobile joystick and touch split/feed/fast controls emit input", async ({
  browser,
}) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    hasTouch: true,
    isMobile: true,
  });
  const page = await context.newPage();
  const frames: any[] = [];
  page.on("websocket", (ws) =>
    ws.on("framesent", (frame) => {
      try {
        frames.push(JSON.parse(String(frame.payload)));
      } catch {}
    }),
  );
  await page.goto("/");
  await page.getByTestId("nickname").fill("Touch player");
  await page.getByTestId("play").tap();
  await expect(page.getByTestId("player-stats")).toHaveAttribute(
    "data-player-id",
    /.+/,
  );
  await expect(page.getByTestId("joystick")).toBeVisible();
  await page.getByTestId("touch-split").tap();
  await expect.poll(() => frames.some((m) => m.type === "split")).toBeTruthy();
  const cdp = await context.newCDPSession(page);
  const press = async (id: string) => {
    const box = await page.getByTestId(id).boundingBox();
    if (!box) throw Error("Missing touch target");
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchStart",
      touchPoints: [{ x: box.x + box.width / 2, y: box.y + box.height / 2 }],
    });
  };
  const release = () =>
    cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  await press("touch-feed");
  await expect
    .poll(() => frames.some((m) => m.type === "input" && m.feed))
    .toBeTruthy();
  await release();
  await press("touch-fast");
  await expect
    .poll(() => frames.filter((m) => m.type === "input" && m.fast).length)
    .toBeGreaterThan(2);
  await release();
  await expect
    .poll(() => frames.filter((m) => m.type === "input").at(-1)?.fast)
    .toBe(false);
  await context.close();
});

test("custom photo persists, is drawn on the cell and is shared with a second browser", async ({ browser }) => {
  const a = await browser.newContext(), b = await browser.newContext();
  const first = await a.newPage(), second = await b.newPage();
  const sent: any[] = [], received: any[] = [];
  for (const page of [first, second]) {
    await page.addInitScript(() => {
      const original = CanvasRenderingContext2D.prototype.drawImage;
      (window as any).__photoDraws = [];
      CanvasRenderingContext2D.prototype.drawImage = function (this: CanvasRenderingContext2D, ...args: any[]) {
        const source = args[0];
        if (source instanceof HTMLImageElement && source.src.includes("/api/skins/")) {
          const draws: string[] = (window as any).__photoDraws;
          if (!draws.includes(source.src)) draws.push(source.src);
        }
        return (original as any).apply(this, args);
      } as typeof original;
    });
  }
  first.on("websocket", ws => ws.on("framesent", frame => {
    try { sent.push(JSON.parse(String(frame.payload))); } catch {}
  }));
  second.on("websocket", ws => ws.on("framereceived", frame => {
    try { received.push(JSON.parse(String(frame.payload))); } catch {}
  }));
  await first.goto("/");
  const created = await first.request.post("/api/rooms", { data: { name: "Photo verification" } });
  expect(created.ok()).toBeTruthy();
  const room = await created.json();
  await first.goto("/?room=" + room.id);
  const png = await first.evaluate(() => {
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 320;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#b13170"; ctx.fillRect(0, 0, 320, 320);
    ctx.fillStyle = "#ffd864"; ctx.fillRect(80, 80, 160, 160);
    return canvas.toDataURL("image/png").split(",")[1];
  });
  await first.getByTestId("custom-image-input").setInputFiles({ name: "my-original-photo.png", mimeType: "image/png", buffer: Buffer.from(png, "base64") });
  await expect(first.getByTestId("custom-image-preview")).toBeVisible();
  const dimensions = await first.getByTestId("custom-image-preview").evaluate((img: HTMLImageElement) => ({ w: img.naturalWidth, h: img.naturalHeight }));
  expect(dimensions).toEqual({ w: 128, h: 128 });
  await first.reload();
  await expect(first.getByTestId("custom-image-preview")).toBeVisible();
  await first.getByTestId("nickname").fill("Photo owner");
  const uploadResponse = first.waitForResponse(response => response.url().endsWith("/api/skins") && response.request().method() === "POST");
  await first.getByTestId("play").click();
  const uploaded = await uploadResponse;
  expect(uploaded.status(), await uploaded.text()).toBe(200);
  await expect(first.getByText("Connected", { exact: true })).toBeVisible();
  await expect.poll(() => sent.find(m => m.type === "join")?.skin).toMatch(/^custom:[a-f0-9]{32}$/);
  const skin = sent.find(m => m.type === "join").skin as string;
  const imagePath = "/api/skins/" + skin.slice("custom:".length);
  await expect.poll(() => first.evaluate(() => (window as any).__photoDraws)).toContain("http://127.0.0.1:5173" + imagePath);
  await second.goto("/?room=" + room.id);
  await second.getByTestId("spectate").click();
  await expect(second.getByText("Connected", { exact: true })).toBeVisible();
  await expect.poll(() => received.some(m => m.type === "snapshot" && m.entities.some((e: any) => e.skin === skin))).toBeTruthy();
  await expect.poll(() => second.evaluate(() => (window as any).__photoDraws)).toContain("http://127.0.0.1:5173" + imagePath);
  const downloaded = await second.request.get(imagePath);
  expect(downloaded.status()).toBe(200);
  expect(downloaded.headers()["content-type"]).toContain("image/png");
  const snapshots = received.filter(m => m.type === "snapshot");
  expect(snapshots.length).toBeGreaterThan(0);
  expect(snapshots.some(m => m.entities.some((e: any) => e.kind === "food" || e.kind === "virus"))).toBe(false);
  await first.getByRole("button", { name: "Return to menu", exact: true }).click();
  await first.getByRole("button", { name: "Skin solar", exact: true }).click();
  await expect(first.getByRole("button", { name: "Skin solar", exact: true })).toHaveAttribute("aria-pressed", "true");
  await first.getByTestId("custom-image-remove").click();
  await expect(first.getByTestId("custom-image-preview")).toHaveCount(0);
  expect(await first.evaluate(() => localStorage.getItem("orbit.customPhoto"))).toBeNull();
  await a.close(); await b.close();
});

test("custom photo rejects non-raster uploads with a readable error", async ({ page }) => {
  await page.goto("/");
  await page.getByTestId("custom-image-input").setInputFiles({ name: "unsafe.svg", mimeType: "image/svg+xml", buffer: Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"/>') });
  await expect(page.getByTestId("custom-image-status")).toContainText(/PNG|JPEG|WebP/i);
  await expect(page.getByTestId("custom-image-preview")).toHaveCount(0);
});
